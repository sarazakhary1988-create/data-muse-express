"""
Final Missing Pieces:
- Streaming Results (real-time output)
- Fuzzy Deduplication (smart matching)
- Cost Optimization Engine
"""

import asyncio
from typing import Dict, List, Any, Optional, AsyncIterator, Callable
from dataclasses import dataclass
from difflib import SequenceMatcher
import re
from datetime import datetime


# ============================================================================
# 1. STREAMING RESULTS
# ============================================================================

class StreamingResearchEngine:
    """
    Streams results in real-time as they're found
    Instead of waiting for all results, sends them immediately
    """
    
    def __init__(self):
        self.subscribers: List[Callable] = []
    
    def subscribe(self, callback: Callable):
        """Subscribe to result stream"""
        self.subscribers.append(callback)
    
    async def emit_lead(self, lead: Dict[str, Any]):
        """Emit a single lead to all subscribers"""
        for callback in self.subscribers:
            if asyncio.iscoroutinefunction(callback):
                await callback(lead)
            else:
                callback(lead)
    
    async def research_stream(
        self,
        query: str,
        target_leads: int = 20
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream research results in real-time
        
        Usage:
            async for lead in engine.research_stream(query):
                print(f"Found: {lead['company_name']}")
                # Process immediately
        """
        
        print(f"\n🔄 STREAMING RESEARCH")
        print(f"Query: {query}")
        print(f"Target: {target_leads} leads")
        print(f"{'='*70}\n")
        
        leads_found = 0
        
        # Simulate research process with streaming
        # In production, this would integrate with actual agents
        
        # Phase 1: Quick wins (from cache/database)
        print("📍 Phase 1: Checking cache and database...")
        cached_leads = await self._get_cached_leads(query)
        
        for lead in cached_leads:
            yield {
                'lead': lead,
                'source': 'cache',
                'confidence': 0.9,
                'phase': 'cache_lookup',
                'progress': f"{leads_found + 1}/{target_leads}"
            }
            
            await self.emit_lead(lead)
            leads_found += 1
            
            if leads_found >= target_leads:
                return
            
            await asyncio.sleep(0.1)  # Rate limiting
        
        # Phase 2: Web search (streaming)
        print(f"\n📍 Phase 2: Streaming web search results...")
        async for lead in self._streaming_web_search(query):
            yield {
                'lead': lead,
                'source': 'web_search',
                'confidence': 0.7,
                'phase': 'web_search',
                'progress': f"{leads_found + 1}/{target_leads}"
            }
            
            await self.emit_lead(lead)
            leads_found += 1
            
            if leads_found >= target_leads:
                return
            
            await asyncio.sleep(0.2)
        
        # Phase 3: Deep scraping (streaming)
        print(f"\n📍 Phase 3: Streaming deep scrape...")
        async for lead in self._streaming_deep_scrape(query):
            yield {
                'lead': lead,
                'source': 'deep_scrape',
                'confidence': 0.85,
                'phase': 'deep_scrape',
                'progress': f"{leads_found + 1}/{target_leads}"
            }
            
            await self.emit_lead(lead)
            leads_found += 1
            
            if leads_found >= target_leads:
                return
    
    async def _get_cached_leads(self, query: str) -> List[Dict]:
        """Get cached leads (instant)"""
        # Simulate cache lookup
        await asyncio.sleep(0.5)
        return [
            {'company_name': f'Cached Company {i}', 'website': f'https://cached-{i}.com'}
            for i in range(3)
        ]
    
    async def _streaming_web_search(self, query: str) -> AsyncIterator[Dict]:
        """Stream web search results"""
        for i in range(5):
            await asyncio.sleep(1.0)  # Simulate search
            yield {
                'company_name': f'Web Company {i}',
                'website': f'https://web-{i}.com',
                'emails': [f'contact@web-{i}.com']
            }
    
    async def _streaming_deep_scrape(self, query: str) -> AsyncIterator[Dict]:
        """Stream deep scrape results"""
        for i in range(10):
            await asyncio.sleep(1.5)  # Simulate scraping
            yield {
                'company_name': f'Scraped Company {i}',
                'website': f'https://scraped-{i}.com',
                'emails': [f'info@scraped-{i}.com'],
                'phone': f'+1-555-{i:04d}'
            }


# ============================================================================
# 2. FUZZY DEDUPLICATION
# ============================================================================

class FuzzyDeduplicator:
    """
    Smart deduplication using fuzzy matching
    
    Handles:
    - "Acme Corp" vs "Acme Corporation"
    - "123 Main St" vs "123 Main Street"
    - Different email formats
    - Typos and variations
    """
    
    def __init__(self, similarity_threshold: float = 0.85):
        self.similarity_threshold = similarity_threshold
        self.seen_companies: List[Dict] = []
    
    def is_duplicate(self, lead: Dict[str, Any]) -> Optional[Dict]:
        """
        Check if lead is duplicate
        
        Returns:
            Original lead if duplicate, None if unique
        """
        
        for existing in self.seen_companies:
            similarity = self._calculate_similarity(lead, existing)
            
            if similarity >= self.similarity_threshold:
                return {
                    'is_duplicate': True,
                    'matches': existing,
                    'similarity': similarity,
                    'match_reasons': self._explain_match(lead, existing)
                }
        
        # Not a duplicate - add to seen
        self.seen_companies.append(lead)
        
        return None
    
    def _calculate_similarity(self, lead1: Dict, lead2: Dict) -> float:
        """Calculate overall similarity between two leads"""
        
        scores = []
        weights = []
        
        # Company name similarity (highest weight)
        if lead1.get('company_name') and lead2.get('company_name'):
            name_sim = self._fuzzy_string_match(
                lead1['company_name'],
                lead2['company_name']
            )
            scores.append(name_sim)
            weights.append(3.0)
        
        # Website similarity
        if lead1.get('website') and lead2.get('website'):
            website_sim = self._website_similarity(
                lead1['website'],
                lead2['website']
            )
            scores.append(website_sim)
            weights.append(2.5)
        
        # Email domain similarity
        if lead1.get('emails') and lead2.get('emails'):
            email_sim = self._email_domain_similarity(
                lead1['emails'],
                lead2['emails']
            )
            scores.append(email_sim)
            weights.append(2.0)
        
        # Phone similarity
        if lead1.get('phone') and lead2.get('phone'):
            phone_sim = self._phone_similarity(
                lead1['phone'],
                lead2['phone']
            )
            scores.append(phone_sim)
            weights.append(1.5)
        
        # Location similarity
        if lead1.get('location') and lead2.get('location'):
            loc_sim = self._fuzzy_string_match(
                lead1['location'],
                lead2['location']
            )
            scores.append(loc_sim)
            weights.append(1.0)
        
        if not scores:
            return 0.0
        
        # Weighted average
        weighted_sum = sum(s * w for s, w in zip(scores, weights))
        total_weight = sum(weights)
        
        return weighted_sum / total_weight
    
    def _fuzzy_string_match(self, str1: str, str2: str) -> float:
        """Fuzzy string matching"""
        
        # Normalize
        s1 = self._normalize_string(str1)
        s2 = self._normalize_string(str2)
        
        # Exact match
        if s1 == s2:
            return 1.0
        
        # Sequence matcher
        return SequenceMatcher(None, s1, s2).ratio()
    
    def _normalize_string(self, s: str) -> str:
        """Normalize string for comparison"""
        
        s = s.lower().strip()
        
        # Remove common suffixes
        suffixes = [' inc', ' llc', ' corp', ' corporation', ' ltd', ' limited', ' co']
        for suffix in suffixes:
            if s.endswith(suffix):
                s = s[:-len(suffix)].strip()
        
        # Remove punctuation
        s = re.sub(r'[^\w\s]', '', s)
        
        # Remove extra whitespace
        s = ' '.join(s.split())
        
        return s
    
    def _website_similarity(self, url1: str, url2: str) -> float:
        """Compare websites"""
        
        # Extract domain
        domain1 = self._extract_domain(url1)
        domain2 = self._extract_domain(url2)
        
        if domain1 == domain2:
            return 1.0
        
        return self._fuzzy_string_match(domain1, domain2)
    
    def _extract_domain(self, url: str) -> str:
        """Extract domain from URL"""
        
        # Remove protocol
        url = re.sub(r'https?://', '', url)
        
        # Remove www
        url = url.replace('www.', '')
        
        # Get base domain
        domain = url.split('/')[0]
        
        return domain
    
    def _email_domain_similarity(self, emails1: List, emails2: List) -> float:
        """Compare email domains"""
        
        domains1 = set()
        for email in emails1:
            if isinstance(email, str) and '@' in email:
                domains1.add(email.split('@')[1])
        
        domains2 = set()
        for email in emails2:
            if isinstance(email, str) and '@' in email:
                domains2.add(email.split('@')[1])
        
        if not domains1 or not domains2:
            return 0.0
        
        # Jaccard similarity
        intersection = len(domains1 & domains2)
        union = len(domains1 | domains2)
        
        return intersection / union if union > 0 else 0.0
    
    def _phone_similarity(self, phone1: str, phone2: str) -> float:
        """Compare phone numbers"""
        
        # Extract digits only
        digits1 = re.sub(r'\D', '', phone1)
        digits2 = re.sub(r'\D', '', phone2)
        
        # Last 10 digits (US numbers)
        if len(digits1) >= 10:
            digits1 = digits1[-10:]
        if len(digits2) >= 10:
            digits2 = digits2[-10:]
        
        if digits1 == digits2:
            return 1.0
        
        return 0.0
    
    def _explain_match(self, lead1: Dict, lead2: Dict) -> List[str]:
        """Explain why leads match"""
        
        reasons = []
        
        if lead1.get('company_name') and lead2.get('company_name'):
            sim = self._fuzzy_string_match(lead1['company_name'], lead2['company_name'])
            if sim > 0.85:
                reasons.append(f"Company name match ({sim:.0%})")
        
        if lead1.get('website') and lead2.get('website'):
            if self._extract_domain(lead1['website']) == self._extract_domain(lead2['website']):
                reasons.append("Same website domain")
        
        return reasons
    
    def deduplicate_list(self, leads: List[Dict]) -> List[Dict]:
        """Deduplicate a list of leads"""
        
        self.seen_companies = []
        unique_leads = []
        duplicates = []
        
        for lead in leads:
            dup_check = self.is_duplicate(lead)
            
            if dup_check:
                duplicates.append({
                    'lead': lead,
                    'duplicate_of': dup_check['matches'],
                    'similarity': dup_check['similarity']
                })
            else:
                unique_leads.append(lead)
        
        return unique_leads, duplicates


# ============================================================================
# 3. COST OPTIMIZATION ENGINE
# ============================================================================

@dataclass
class CostEstimate:
    """Cost estimate for an operation"""
    operation: str
    estimated_cost: float
    estimated_time: float
    quality_impact: float
    recommendation: str


class CostOptimizer:
    """
    Intelligent cost optimization
    
    Makes smart decisions about:
    - Which APIs to call
    - When to use free vs paid sources
    - When quality is "good enough"
    - Budget allocation
    """
    
    def __init__(self, budget: float, quality_target: float = 0.7):
        self.total_budget = budget
        self.remaining_budget = budget
        self.quality_target = quality_target
        self.spent_log: List[Dict] = []
        
        # Cost per operation (in credits/dollars)
        self.operation_costs = {
            'clearbit_enrich': 1.0,
            'hunter_email_find': 0.5,
            'hunter_email_verify': 0.1,
            'apollo_enrich': 0.8,
            'crunchbase_data': 2.0,
            'web_search': 0.0,  # Free
            'web_scrape': 0.05,
            'linkedin_api': 5.0,  # Expensive
        }
        
        # Quality impact
        self.quality_impact = {
            'clearbit_enrich': 0.25,
            'hunter_email_find': 0.20,
            'apollo_enrich': 0.22,
            'crunchbase_data': 0.15,
            'web_scrape': 0.10,
        }
    
    def should_enrich(self, lead: Dict, enrichment_type: str) -> Dict[str, Any]:
        """
        Decide if we should enrich this lead
        
        Returns decision with reasoning
        """
        
        cost = self.operation_costs.get(enrichment_type, 1.0)
        quality_gain = self.quality_impact.get(enrichment_type, 0.1)
        
        current_quality = lead.get('confidence_score', 0.5)
        
        # Decision logic
        decision = {
            'should_enrich': False,
            'reason': '',
            'cost': cost,
            'quality_gain': quality_gain
        }
        
        # Can't afford it
        if self.remaining_budget < cost:
            decision['reason'] = f"Insufficient budget (${cost} needed, ${self.remaining_budget:.2f} remaining)"
            return decision
        
        # Already high quality
        if current_quality >= self.quality_target:
            decision['reason'] = f"Quality already sufficient ({current_quality:.0%} >= {self.quality_target:.0%})"
            return decision
        
        # Would significantly improve quality
        if current_quality + quality_gain >= self.quality_target:
            decision['should_enrich'] = True
            decision['reason'] = f"Would reach quality target ({current_quality + quality_gain:.0%})"
            return decision
        
        # Good ROI
        roi = quality_gain / cost
        if roi > 0.15:  # More than 15% quality per dollar
            decision['should_enrich'] = True
            decision['reason'] = f"Good ROI ({roi:.0%} quality per dollar)"
            return decision
        
        decision['reason'] = f"Poor ROI ({roi:.0%} quality per dollar)"
        return decision
    
    def choose_optimal_enrichments(
        self,
        lead: Dict,
        available_enrichments: List[str]
    ) -> List[str]:
        """
        Choose optimal set of enrichments within budget
        
        Uses dynamic programming to maximize quality gain
        """
        
        current_quality = lead.get('confidence_score', 0.5)
        
        if current_quality >= self.quality_target:
            return []  # Already good enough
        
        # Calculate cost and benefit for each
        options = []
        for enrichment in available_enrichments:
            cost = self.operation_costs.get(enrichment, 1.0)
            quality_gain = self.quality_impact.get(enrichment, 0.1)
            
            if cost <= self.remaining_budget:
                options.append({
                    'name': enrichment,
                    'cost': cost,
                    'quality_gain': quality_gain,
                    'roi': quality_gain / cost
                })
        
        # Sort by ROI
        options.sort(key=lambda x: x['roi'], reverse=True)
        
        # Greedy selection
        selected = []
        total_cost = 0
        total_quality_gain = 0
        
        for option in options:
            if total_cost + option['cost'] <= self.remaining_budget:
                if current_quality + total_quality_gain < self.quality_target:
                    selected.append(option['name'])
                    total_cost += option['cost']
                    total_quality_gain += option['quality_gain']
        
        return selected
    
    def record_spending(self, operation: str, cost: float, quality_achieved: float):
        """Record actual spending"""
        
        self.remaining_budget -= cost
        
        self.spent_log.append({
            'timestamp': datetime.now().isoformat(),
            'operation': operation,
            'cost': cost,
            'quality_achieved': quality_achieved,
            'remaining_budget': self.remaining_budget
        })
    
    def estimate_total_cost(
        self,
        num_leads: int,
        enrichment_plan: List[str]
    ) -> CostEstimate:
        """Estimate total cost for research"""
        
        total_cost = 0
        
        # Base research cost
        total_cost += num_leads * 0.05  # Scraping
        
        # Enrichment costs
        for enrichment in enrichment_plan:
            cost_per_lead = self.operation_costs.get(enrichment, 1.0)
            total_cost += num_leads * cost_per_lead
        
        # Estimate time (parallel execution)
        estimated_time = (num_leads / 10) * 2  # 10 concurrent, 2 sec each
        
        # Quality estimate
        quality_impact = sum(
            self.quality_impact.get(e, 0.1)
            for e in enrichment_plan
        )
        
        recommendation = "PROCEED"
        if total_cost > self.total_budget:
            recommendation = "REDUCE_SCOPE"
        elif quality_impact < self.quality_target:
            recommendation = "ADD_ENRICHMENTS"
        
        return CostEstimate(
            operation=f"Research {num_leads} leads",
            estimated_cost=total_cost,
            estimated_time=estimated_time,
            quality_impact=quality_impact,
            recommendation=recommendation
        )
    
    def get_spending_report(self) -> Dict[str, Any]:
        """Get spending report"""
        
        return {
            'total_budget': self.total_budget,
            'spent': self.total_budget - self.remaining_budget,
            'remaining': self.remaining_budget,
            'utilization': (self.total_budget - self.remaining_budget) / self.total_budget,
            'operations_count': len(self.spent_log),
            'avg_cost_per_operation': sum(log['cost'] for log in self.spent_log) / len(self.spent_log) if self.spent_log else 0,
            'spending_log': self.spent_log[-10:]  # Last 10
        }


# Example usage
async def example_usage():
    """Demonstrate all three systems"""
    
    print("="*70)
    print("DEMONSTRATION OF FINAL MISSING PIECES")
    print("="*70)
    
    # 1. Streaming Results
    print("\n1️⃣ STREAMING RESULTS\n")
    
    engine = StreamingResearchEngine()
    
    # Subscribe to stream
    def on_lead_found(lead):
        print(f"   ✓ Found: {lead.get('company_name', 'Unknown')}")
    
    engine.subscribe(on_lead_found)
    
    # Stream results
    async for result in engine.research_stream("Test query", target_leads=5):
        # Results arrive in real-time
        pass
    
    # 2. Fuzzy Deduplication
    print(f"\n{'='*70}")
    print("\n2️⃣ FUZZY DEDUPLICATION\n")
    
    deduplicator = FuzzyDeduplicator(similarity_threshold=0.85)
    
    test_leads = [
        {'company_name': 'Acme Corp', 'website': 'https://acme.com'},
        {'company_name': 'Acme Corporation', 'website': 'https://www.acme.com'},  # Duplicate
        {'company_name': 'Beta Inc', 'website': 'https://beta.com'},
        {'company_name': 'Beta Incorporated', 'website': 'https://beta.com'},  # Duplicate
    ]
    
    unique, duplicates = deduplicator.deduplicate_list(test_leads)
    
    print(f"Original leads: {len(test_leads)}")
    print(f"Unique leads: {len(unique)}")
    print(f"Duplicates found: {len(duplicates)}")
    
    for dup in duplicates:
        print(f"\n   Duplicate: {dup['lead']['company_name']}")
        print(f"   Matches: {dup['duplicate_of']['company_name']}")
        print(f"   Similarity: {dup['similarity']:.0%}")
    
    # 3. Cost Optimization
    print(f"\n{'='*70}")
    print("\n3️⃣ COST OPTIMIZATION\n")
    
    optimizer = CostOptimizer(budget=100.0, quality_target=0.8)
    
    test_lead = {
        'company_name': 'Test Co',
        'confidence_score': 0.6
    }
    
    # Should we enrich?
    decision = optimizer.should_enrich(test_lead, 'clearbit_enrich')
    print(f"Enrich with Clearbit? {decision['should_enrich']}")
    print(f"Reason: {decision['reason']}")
    
    # Choose optimal enrichments
    available = ['clearbit_enrich', 'hunter_email_find', 'apollo_enrich', 'crunchbase_data']
    selected = optimizer.choose_optimal_enrichments(test_lead, available)
    
    print(f"\nOptimal enrichments: {selected}")
    
    # Estimate total cost
    estimate = optimizer.estimate_total_cost(20, selected)
    print(f"\nEstimate for 20 leads:")
    print(f"  Cost: ${estimate.estimated_cost:.2f}")
    print(f"  Time: {estimate.estimated_time:.1f}s")
    print(f"  Quality: {estimate.quality_impact:.0%}")
    print(f"  Recommendation: {estimate.recommendation}")


if __name__ == "__main__":
    asyncio.run(example_usage())
