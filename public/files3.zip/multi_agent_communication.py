"""
Multi-Agent Communication System
Enables agents to negotiate, collaborate, and share knowledge
"""

import asyncio
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json


class MessageType(Enum):
    """Types of inter-agent messages"""
    REQUEST = "request"  # Request information/action
    RESPONSE = "response"  # Respond to request
    BROADCAST = "broadcast"  # Broadcast to all
    NEGOTIATE = "negotiate"  # Negotiate parameters
    COLLABORATE = "collaborate"  # Joint task
    INFORM = "inform"  # Share information
    QUERY = "query"  # Ask question
    ANSWER = "answer"  # Answer question


class MessagePriority(Enum):
    """Message priority levels"""
    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3


@dataclass
class Message:
    """Inter-agent message"""
    id: str
    from_agent: str
    to_agent: str  # or "broadcast"
    message_type: MessageType
    priority: MessagePriority
    content: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    conversation_id: Optional[str] = None
    in_reply_to: Optional[str] = None
    requires_response: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Conversation:
    """Multi-turn conversation between agents"""
    id: str
    participants: List[str]
    messages: List[Message] = field(default_factory=list)
    topic: str = ""
    status: str = "active"  # active, completed, failed
    result: Optional[Any] = None


class MessageBus:
    """
    Central message bus for agent communication
    """
    
    def __init__(self):
        self.messages: List[Message] = []
        self.conversations: Dict[str, Conversation] = {}
        self.subscribers: Dict[str, List[Callable]] = {}
        self.message_handlers: Dict[str, Dict[MessageType, Callable]] = {}
    
    def subscribe(self, agent_id: str, handler: Callable):
        """Subscribe agent to messages"""
        if agent_id not in self.subscribers:
            self.subscribers[agent_id] = []
        self.subscribers[agent_id].append(handler)
    
    def register_handler(self, agent_id: str, message_type: MessageType, handler: Callable):
        """Register handler for specific message type"""
        if agent_id not in self.message_handlers:
            self.message_handlers[agent_id] = {}
        self.message_handlers[agent_id][message_type] = handler
    
    async def send(self, message: Message) -> Optional[Message]:
        """Send message and optionally wait for response"""
        
        self.messages.append(message)
        
        # Add to conversation if applicable
        if message.conversation_id:
            if message.conversation_id in self.conversations:
                self.conversations[message.conversation_id].messages.append(message)
        
        # Route message
        if message.to_agent == "broadcast":
            # Broadcast to all subscribers
            tasks = []
            for agent_id, handlers in self.subscribers.items():
                if agent_id != message.from_agent:
                    for handler in handlers:
                        tasks.append(handler(message))
            
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
        
        else:
            # Direct message
            if message.to_agent in self.message_handlers:
                handlers = self.message_handlers[message.to_agent]
                if message.message_type in handlers:
                    response = await handlers[message.message_type](message)
                    
                    if response and message.requires_response:
                        return response
        
        # Wait for response if required
        if message.requires_response:
            return await self._wait_for_response(message.id, timeout=30.0)
        
        return None
    
    async def _wait_for_response(self, message_id: str, timeout: float) -> Optional[Message]:
        """Wait for response to a message"""
        
        start_time = asyncio.get_event_loop().time()
        
        while asyncio.get_event_loop().time() - start_time < timeout:
            # Check for response
            for msg in reversed(self.messages):
                if msg.in_reply_to == message_id:
                    return msg
            
            await asyncio.sleep(0.1)
        
        return None
    
    def start_conversation(self, participants: List[str], topic: str) -> str:
        """Start a new conversation"""
        
        conv_id = f"conv_{len(self.conversations)}_{int(datetime.now().timestamp())}"
        
        conversation = Conversation(
            id=conv_id,
            participants=participants,
            topic=topic
        )
        
        self.conversations[conv_id] = conversation
        
        return conv_id
    
    def get_conversation(self, conv_id: str) -> Optional[Conversation]:
        """Get conversation by ID"""
        return self.conversations.get(conv_id)


class CollaborativeAgent:
    """
    Base class for collaborative agents
    Enables communication with other agents
    """
    
    def __init__(self, agent_id: str, message_bus: MessageBus):
        self.agent_id = agent_id
        self.message_bus = message_bus
        self.knowledge_base: Dict[str, Any] = {}
        
        # Register with message bus
        message_bus.subscribe(agent_id, self._handle_message)
    
    async def _handle_message(self, message: Message):
        """Handle incoming message"""
        
        if message.message_type == MessageType.REQUEST:
            await self._handle_request(message)
        elif message.message_type == MessageType.QUERY:
            await self._handle_query(message)
        elif message.message_type == MessageType.NEGOTIATE:
            await self._handle_negotiation(message)
        elif message.message_type == MessageType.COLLABORATE:
            await self._handle_collaboration(message)
        elif message.message_type == MessageType.INFORM:
            await self._handle_information(message)
    
    async def _handle_request(self, message: Message):
        """Handle request from another agent"""
        # Override in subclass
        pass
    
    async def _handle_query(self, message: Message):
        """Handle query from another agent"""
        # Override in subclass
        pass
    
    async def _handle_negotiation(self, message: Message):
        """Handle negotiation"""
        # Override in subclass
        pass
    
    async def _handle_collaboration(self, message: Message):
        """Handle collaboration request"""
        # Override in subclass
        pass
    
    async def _handle_information(self, message: Message):
        """Handle information sharing"""
        # Store in knowledge base
        topic = message.content.get('topic')
        data = message.content.get('data')
        
        if topic and data:
            self.knowledge_base[topic] = data
    
    async def send_message(
        self,
        to_agent: str,
        message_type: MessageType,
        content: Dict[str, Any],
        priority: MessagePriority = MessagePriority.MEDIUM,
        requires_response: bool = False,
        conversation_id: Optional[str] = None
    ) -> Optional[Message]:
        """Send message to another agent"""
        
        message = Message(
            id=f"msg_{self.agent_id}_{int(datetime.now().timestamp() * 1000)}",
            from_agent=self.agent_id,
            to_agent=to_agent,
            message_type=message_type,
            priority=priority,
            content=content,
            requires_response=requires_response,
            conversation_id=conversation_id
        )
        
        return await self.message_bus.send(message)
    
    async def ask_for_help(self, task: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Ask other agents for help"""
        
        response = await self.send_message(
            to_agent="broadcast",
            message_type=MessageType.REQUEST,
            content={
                'task': task,
                'context': context,
                'capabilities_needed': self._identify_needed_capabilities(task)
            },
            requires_response=True
        )
        
        if response:
            return response.content
        
        return None
    
    async def share_knowledge(self, topic: str, data: Any):
        """Share knowledge with other agents"""
        
        await self.send_message(
            to_agent="broadcast",
            message_type=MessageType.INFORM,
            content={
                'topic': topic,
                'data': data,
                'source': self.agent_id
            }
        )
    
    def _identify_needed_capabilities(self, task: str) -> List[str]:
        """Identify what capabilities are needed for a task"""
        # Simple keyword matching
        capabilities = []
        
        if 'scrape' in task.lower():
            capabilities.append('web_scraping')
        if 'enrich' in task.lower():
            capabilities.append('data_enrichment')
        if 'verify' in task.lower():
            capabilities.append('verification')
        
        return capabilities


class PlannerAgent(CollaborativeAgent):
    """
    Planner that collaborates with other agents
    """
    
    def __init__(self, agent_id: str, message_bus: MessageBus):
        super().__init__(agent_id, message_bus)
        self.capabilities = ['planning', 'strategy']
    
    async def create_collaborative_plan(self, query: str, target: int) -> Dict[str, Any]:
        """
        Create plan by consulting with other agents
        """
        
        print(f"\n{self.agent_id}: Creating collaborative plan...")
        
        # Start conversation with verifier
        conv_id = self.message_bus.start_conversation(
            participants=[self.agent_id, 'verifier'],
            topic='plan_validation'
        )
        
        # Ask verifier: "Is this strategy sound?"
        initial_plan = {
            'search_queries': ['query1', 'query2'],
            'approach': 'wide'
        }
        
        response = await self.send_message(
            to_agent='verifier',
            message_type=MessageType.QUERY,
            content={
                'question': 'Is this research strategy sound?',
                'plan': initial_plan,
                'query': query
            },
            requires_response=True,
            conversation_id=conv_id
        )
        
        if response:
            feedback = response.content.get('feedback', {})
            
            # Adjust plan based on feedback
            if feedback.get('confidence', 1.0) < 0.7:
                print(f"   Received feedback: {feedback.get('issues', [])}")
                initial_plan = self._adjust_plan(initial_plan, feedback)
        
        # Ask scraper: "Can you handle these URLs?"
        scraper_response = await self.send_message(
            to_agent='scraper',
            message_type=MessageType.QUERY,
            content={
                'question': 'Can you scrape these types of sites?',
                'site_types': ['SaaS companies', 'directories']
            },
            requires_response=True
        )
        
        if scraper_response:
            capabilities = scraper_response.content.get('capabilities', {})
            initial_plan['scraper_config'] = capabilities
        
        return initial_plan
    
    def _adjust_plan(self, plan: Dict, feedback: Dict) -> Dict:
        """Adjust plan based on feedback"""
        
        if 'too_broad' in feedback.get('issues', []):
            plan['approach'] = 'focused'
        
        if 'add_filters' in feedback.get('recommendations', []):
            plan['filters'] = feedback.get('suggested_filters', {})
        
        return plan
    
    async def _handle_query(self, message: Message):
        """Answer questions about planning"""
        
        question = message.content.get('question', '')
        
        if 'difficult' in question.lower():
            # Estimate difficulty
            await self.send_message(
                to_agent=message.from_agent,
                message_type=MessageType.ANSWER,
                content={
                    'answer': 'medium',
                    'confidence': 0.7
                },
                conversation_id=message.conversation_id,
                in_reply_to=message.id
            )


class VerifierAgent(CollaborativeAgent):
    """
    Verifier that collaborates to validate data
    """
    
    def __init__(self, agent_id: str, message_bus: MessageBus):
        super().__init__(agent_id, message_bus)
        self.capabilities = ['verification', 'validation']
    
    async def collaborative_verify(self, lead: Dict) -> Dict[str, Any]:
        """
        Verify lead by consulting other agents
        """
        
        print(f"\n{self.agent_id}: Collaborative verification...")
        
        # Ask enricher: "Do you have data for this company?"
        enricher_response = await self.send_message(
            to_agent='enricher',
            message_type=MessageType.QUERY,
            content={
                'question': 'Do you have data for this company?',
                'company': lead.get('company_name'),
                'website': lead.get('website')
            },
            requires_response=True
        )
        
        external_data = {}
        if enricher_response:
            external_data = enricher_response.content.get('data', {})
        
        # Cross-reference with external data
        confidence = 0.5
        
        if external_data:
            # Check consistency
            if external_data.get('name') == lead.get('company_name'):
                confidence += 0.3
            if external_data.get('website') == lead.get('website'):
                confidence += 0.2
        
        return {
            'verified': confidence > 0.7,
            'confidence': confidence,
            'external_sources': 1 if external_data else 0
        }
    
    async def _handle_query(self, message: Message):
        """Answer verification questions"""
        
        question = message.content.get('question', '')
        plan = message.content.get('plan', {})
        
        if 'sound' in question.lower():
            # Evaluate plan
            issues = []
            recommendations = []
            
            if len(plan.get('search_queries', [])) < 3:
                issues.append('too_few_queries')
                recommendations.append('add_more_queries')
            
            if plan.get('approach') == 'wide' and 'filters' not in plan:
                issues.append('too_broad')
                recommendations.append('add_filters')
            
            await self.send_message(
                to_agent=message.from_agent,
                message_type=MessageType.ANSWER,
                content={
                    'feedback': {
                        'confidence': 0.6 if issues else 0.9,
                        'issues': issues,
                        'recommendations': recommendations
                    }
                },
                conversation_id=message.conversation_id,
                in_reply_to=message.id
            )


class ScraperAgent(CollaborativeAgent):
    """
    Scraper that negotiates with other agents
    """
    
    def __init__(self, agent_id: str, message_bus: MessageBus):
        super().__init__(agent_id, message_bus)
        self.capabilities = ['web_scraping', 'javascript_rendering']
    
    async def negotiate_scraping_strategy(self, urls: List[str]) -> Dict[str, Any]:
        """
        Negotiate scraping strategy with planner
        """
        
        print(f"\n{self.agent_id}: Negotiating scraping strategy...")
        
        # Analyze URLs
        difficult_urls = [url for url in urls if 'linkedin.com' in url or 'facebook.com' in url]
        
        if difficult_urls:
            # Negotiate with planner
            response = await self.send_message(
                to_agent='planner',
                message_type=MessageType.NEGOTIATE,
                content={
                    'issue': 'difficult_urls',
                    'difficult_urls': difficult_urls,
                    'proposal': 'skip_difficult_or_use_premium_proxies',
                    'cost_impact': '+$50 for premium proxies'
                },
                requires_response=True
            )
            
            if response:
                decision = response.content.get('decision', 'skip')
                
                if decision == 'use_premium':
                    return {
                        'strategy': 'premium_scraping',
                        'urls': urls,
                        'estimated_cost': 50
                    }
                else:
                    return {
                        'strategy': 'standard_scraping',
                        'urls': [url for url in urls if url not in difficult_urls],
                        'estimated_cost': 10
                    }
        
        return {
            'strategy': 'standard_scraping',
            'urls': urls,
            'estimated_cost': 10
        }
    
    async def _handle_query(self, message: Message):
        """Answer questions about scraping capabilities"""
        
        question = message.content.get('question', '')
        
        if 'can you scrape' in question.lower():
            await self.send_message(
                to_agent=message.from_agent,
                message_type=MessageType.ANSWER,
                content={
                    'capabilities': {
                        'javascript_rendering': True,
                        'captcha_solving': True,
                        'proxy_rotation': True,
                        'max_concurrent': 10
                    }
                },
                conversation_id=message.conversation_id,
                in_reply_to=message.id
            )


# Example usage
async def example_multi_agent_communication():
    """Example of multi-agent collaboration"""
    
    # Create message bus
    bus = MessageBus()
    
    # Create collaborative agents
    planner = PlannerAgent('planner', bus)
    verifier = VerifierAgent('verifier', bus)
    scraper = ScraperAgent('scraper', bus)
    
    # Planner creates collaborative plan
    plan = await planner.create_collaborative_plan(
        query="SaaS companies in healthcare",
        target=20
    )
    
    print(f"\n✅ Collaborative plan created: {json.dumps(plan, indent=2)}")
    
    # Verifier does collaborative verification
    test_lead = {
        'company_name': 'Acme Corp',
        'website': 'https://acme.com'
    }
    
    verification = await verifier.collaborative_verify(test_lead)
    
    print(f"\n✅ Collaborative verification: {verification}")
    
    # Scraper negotiates strategy
    test_urls = [
        'https://example.com',
        'https://linkedin.com/company/test'
    ]
    
    strategy = await scraper.negotiate_scraping_strategy(test_urls)
    
    print(f"\n✅ Negotiated strategy: {json.dumps(strategy, indent=2)}")
    
    # Check conversations
    print(f"\n📊 Total conversations: {len(bus.conversations)}")
    print(f"📨 Total messages: {len(bus.messages)}")


if __name__ == "__main__":
    asyncio.run(example_multi_agent_communication())
