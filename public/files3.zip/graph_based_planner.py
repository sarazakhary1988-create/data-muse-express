"""
Graph-Based Agent Planner
Dynamic execution graph instead of linear state machine
"""

import asyncio
from typing import Dict, List, Any, Optional, Set, Callable
from dataclasses import dataclass, field
from enum import Enum
import networkx as nx


class NodeType(Enum):
    """Types of execution nodes"""
    START = "start"
    PLAN = "plan"
    SEARCH = "search"
    SCRAPE = "scrape"
    EXTRACT = "extract"
    VERIFY = "verify"
    ENRICH = "enrich"
    SCORE = "score"
    DECIDE = "decide"
    MERGE = "merge"
    END = "end"


class EdgeCondition(Enum):
    """Conditions for edge traversal"""
    ALWAYS = "always"
    IF_SUCCESS = "if_success"
    IF_FAILURE = "if_failure"
    IF_LOW_QUALITY = "if_low_quality"
    IF_HIGH_QUALITY = "if_high_quality"
    IF_INSUFFICIENT_DATA = "if_insufficient_data"
    IF_BUDGET_REMAINING = "if_budget_remaining"


@dataclass
class ExecutionNode:
    """Node in execution graph"""
    id: str
    node_type: NodeType
    agent: Any
    priority: int = 0
    can_run_parallel: bool = True
    dependencies: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionEdge:
    """Edge in execution graph"""
    from_node: str
    to_node: str
    condition: EdgeCondition
    condition_func: Optional[Callable] = None
    weight: float = 1.0


class GraphBasedPlanner:
    """
    Graph-based execution planner
    
    Instead of linear state machine, uses directed graph for:
    - Parallel execution paths
    - Dynamic branching
    - Conditional flows
    - Smart merging
    """
    
    def __init__(self):
        self.graph = nx.DiGraph()
        self.nodes: Dict[str, ExecutionNode] = {}
        self.edges: List[ExecutionEdge] = []
        
    def add_node(self, node: ExecutionNode):
        """Add execution node to graph"""
        self.nodes[node.id] = node
        self.graph.add_node(
            node.id,
            type=node.node_type,
            priority=node.priority,
            parallel=node.can_run_parallel
        )
    
    def add_edge(self, edge: ExecutionEdge):
        """Add execution edge to graph"""
        self.edges.append(edge)
        self.graph.add_edge(
            edge.from_node,
            edge.to_node,
            condition=edge.condition,
            weight=edge.weight
        )
    
    def build_research_graph(self, agents: Dict[str, Any], config: Dict[str, Any]):
        """
        Build dynamic research execution graph
        
        Graph structure:
                     START
                       |
                    PLANNING
                   /   |   \
           SEARCH  DATABASE  API_DIRECT
              |        |        |
           SCRAPE      |        |
              |        |        |
           EXTRACT ----+--------+
                       |
                    MERGE
                       |
                  +----+----+
                  |         |
              VERIFY    BASIC_FILTER
                  |         |
                  +----+----+
                       |
                  +----+----+
                  |         |
            ENRICH_FULL  ENRICH_BASIC
                  |         |
                  +----+----+
                       |
                    SCORE
                       |
                    DECIDE
                    /    \
                STOP    CONTINUE → back to PLANNING
        """
        
        # START node
        self.add_node(ExecutionNode(
            id="start",
            node_type=NodeType.START,
            agent=None
        ))
        
        # PLANNING node
        self.add_node(ExecutionNode(
            id="planning",
            node_type=NodeType.PLAN,
            agent=agents.get('planner'),
            priority=10
        ))
        
        # Parallel search paths
        self.add_node(ExecutionNode(
            id="web_search",
            node_type=NodeType.SEARCH,
            agent=agents.get('searcher'),
            can_run_parallel=True,
            priority=5
        ))
        
        self.add_node(ExecutionNode(
            id="database_lookup",
            node_type=NodeType.SEARCH,
            agent=agents.get('database'),
            can_run_parallel=True,
            priority=5
        ))
        
        self.add_node(ExecutionNode(
            id="api_direct",
            node_type=NodeType.SEARCH,
            agent=agents.get('api_enricher'),
            can_run_parallel=True,
            priority=5
        ))
        
        # SCRAPE node (only for web search)
        self.add_node(ExecutionNode(
            id="scrape",
            node_type=NodeType.SCRAPE,
            agent=agents.get('scraper'),
            dependencies=["web_search"]
        ))
        
        # EXTRACT nodes
        self.add_node(ExecutionNode(
            id="extract_web",
            node_type=NodeType.EXTRACT,
            agent=agents.get('extractor'),
            dependencies=["scrape"]
        ))
        
        # MERGE node - combines all sources
        self.add_node(ExecutionNode(
            id="merge",
            node_type=NodeType.MERGE,
            agent=agents.get('merger'),
            dependencies=["extract_web", "database_lookup", "api_direct"]
        ))
        
        # Conditional verification paths
        self.add_node(ExecutionNode(
            id="verify_full",
            node_type=NodeType.VERIFY,
            agent=agents.get('verifier_full'),
            priority=8
        ))
        
        self.add_node(ExecutionNode(
            id="verify_basic",
            node_type=NodeType.VERIFY,
            agent=agents.get('verifier_basic'),
            priority=3
        ))
        
        # Conditional enrichment paths
        self.add_node(ExecutionNode(
            id="enrich_premium",
            node_type=NodeType.ENRICH,
            agent=agents.get('enricher_premium'),
            priority=9
        ))
        
        self.add_node(ExecutionNode(
            id="enrich_basic",
            node_type=NodeType.ENRICH,
            agent=agents.get('enricher_basic'),
            priority=5
        ))
        
        # SCORE node
        self.add_node(ExecutionNode(
            id="score",
            node_type=NodeType.SCORE,
            agent=agents.get('scorer')
        ))
        
        # DECIDE node
        self.add_node(ExecutionNode(
            id="decide",
            node_type=NodeType.DECIDE,
            agent=agents.get('decider')
        ))
        
        # END node
        self.add_node(ExecutionNode(
            id="end",
            node_type=NodeType.END,
            agent=None
        ))
        
        # Build edges
        self._build_graph_edges(config)
    
    def _build_graph_edges(self, config: Dict[str, Any]):
        """Build conditional edges"""
        
        # START → PLANNING
        self.add_edge(ExecutionEdge(
            "start", "planning",
            EdgeCondition.ALWAYS
        ))
        
        # PLANNING → Parallel searches
        self.add_edge(ExecutionEdge(
            "planning", "web_search",
            EdgeCondition.ALWAYS
        ))
        
        self.add_edge(ExecutionEdge(
            "planning", "database_lookup",
            EdgeCondition.IF_BUDGET_REMAINING,
            lambda ctx: ctx.get('budget_remaining', 0) > 50
        ))
        
        self.add_edge(ExecutionEdge(
            "planning", "api_direct",
            EdgeCondition.IF_BUDGET_REMAINING,
            lambda ctx: ctx.get('budget_remaining', 0) > 100
        ))
        
        # WEB_SEARCH → SCRAPE
        self.add_edge(ExecutionEdge(
            "web_search", "scrape",
            EdgeCondition.IF_SUCCESS
        ))
        
        # SCRAPE → EXTRACT
        self.add_edge(ExecutionEdge(
            "scrape", "extract_web",
            EdgeCondition.IF_SUCCESS
        ))
        
        # All sources → MERGE
        self.add_edge(ExecutionEdge(
            "extract_web", "merge",
            EdgeCondition.ALWAYS
        ))
        self.add_edge(ExecutionEdge(
            "database_lookup", "merge",
            EdgeCondition.ALWAYS
        ))
        self.add_edge(ExecutionEdge(
            "api_direct", "merge",
            EdgeCondition.ALWAYS
        ))
        
        # MERGE → Conditional verification
        self.add_edge(ExecutionEdge(
            "merge", "verify_full",
            EdgeCondition.IF_HIGH_QUALITY,
            lambda ctx: ctx.get('num_leads', 0) < ctx.get('target', 20)
        ))
        
        self.add_edge(ExecutionEdge(
            "merge", "verify_basic",
            EdgeCondition.IF_LOW_QUALITY,
            lambda ctx: ctx.get('num_leads', 0) >= ctx.get('target', 20)
        ))
        
        # VERIFY → Conditional enrichment
        self.add_edge(ExecutionEdge(
            "verify_full", "enrich_premium",
            EdgeCondition.IF_BUDGET_REMAINING,
            lambda ctx: ctx.get('budget_remaining', 0) > 200
        ))
        
        self.add_edge(ExecutionEdge(
            "verify_full", "enrich_basic",
            EdgeCondition.IF_BUDGET_REMAINING,
            lambda ctx: ctx.get('budget_remaining', 0) <= 200
        ))
        
        self.add_edge(ExecutionEdge(
            "verify_basic", "enrich_basic",
            EdgeCondition.ALWAYS
        ))
        
        # ENRICH → SCORE
        self.add_edge(ExecutionEdge(
            "enrich_premium", "score",
            EdgeCondition.ALWAYS
        ))
        self.add_edge(ExecutionEdge(
            "enrich_basic", "score",
            EdgeCondition.ALWAYS
        ))
        
        # SCORE → DECIDE
        self.add_edge(ExecutionEdge(
            "score", "decide",
            EdgeCondition.ALWAYS
        ))
        
        # DECIDE → END or back to PLANNING
        self.add_edge(ExecutionEdge(
            "decide", "end",
            EdgeCondition.IF_SUCCESS,
            lambda ctx: ctx.get('should_stop', False)
        ))
        
        self.add_edge(ExecutionEdge(
            "decide", "planning",
            EdgeCondition.IF_FAILURE,
            lambda ctx: not ctx.get('should_stop', False)
        ))
    
    async def execute_graph(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the graph dynamically
        
        Features:
        - Parallel execution where possible
        - Conditional branching
        - Dynamic path selection
        - Result merging
        """
        
        current_nodes = ["start"]
        executed_nodes = set()
        results = {}
        
        print("\n🔀 GRAPH-BASED EXECUTION")
        print("="*70)
        
        while current_nodes:
            # Get next executable nodes
            next_nodes = []
            parallel_nodes = []
            
            for node_id in current_nodes:
                if node_id in executed_nodes:
                    continue
                
                node = self.nodes.get(node_id)
                if not node:
                    continue
                
                # Check if dependencies are met
                if all(dep in executed_nodes for dep in node.dependencies):
                    if node.can_run_parallel:
                        parallel_nodes.append(node)
                    else:
                        next_nodes.append(node)
            
            # Execute parallel nodes concurrently
            if parallel_nodes:
                print(f"\n⚡ Executing {len(parallel_nodes)} nodes in parallel:")
                for node in parallel_nodes:
                    print(f"   - {node.id} ({node.node_type.value})")
                
                tasks = []
                for node in parallel_nodes:
                    if node.agent:
                        task = self._execute_node(node, context, results)
                        tasks.append((node.id, task))
                
                parallel_results = await asyncio.gather(
                    *[task for _, task in tasks],
                    return_exceptions=True
                )
                
                for (node_id, _), result in zip(tasks, parallel_results):
                    if not isinstance(result, Exception):
                        results[node_id] = result
                        executed_nodes.add(node_id)
            
            # Execute sequential nodes
            for node in next_nodes:
                print(f"\n🔹 Executing: {node.id} ({node.node_type.value})")
                
                if node.agent:
                    result = await self._execute_node(node, context, results)
                    results[node.id] = result
                
                executed_nodes.add(node.id)
            
            # Find next nodes based on edges
            current_nodes = []
            for executed in executed_nodes:
                outgoing_edges = [
                    e for e in self.edges
                    if e.from_node == executed
                ]
                
                for edge in outgoing_edges:
                    # Check condition
                    if self._check_edge_condition(edge, context, results):
                        if edge.to_node not in executed_nodes:
                            current_nodes.append(edge.to_node)
            
            # Remove duplicates
            current_nodes = list(set(current_nodes))
            
            # Check for end
            if "end" in current_nodes or not current_nodes:
                break
        
        print("\n" + "="*70)
        print(f"✅ Graph execution complete - {len(executed_nodes)} nodes executed")
        
        return results
    
    async def _execute_node(
        self,
        node: ExecutionNode,
        context: Dict[str, Any],
        results: Dict[str, Any]
    ) -> Any:
        """Execute a single node"""
        
        try:
            # Special node types
            if node.node_type == NodeType.START:
                return {"status": "started"}
            
            elif node.node_type == NodeType.END:
                return {"status": "completed"}
            
            elif node.node_type == NodeType.MERGE:
                # Merge results from multiple sources
                return self._merge_results(results, node.dependencies)
            
            # Execute agent
            if hasattr(node.agent, 'execute'):
                return await node.agent.execute(context, results)
            elif callable(node.agent):
                return await node.agent(context, results)
            
            return None
            
        except Exception as e:
            print(f"   ❌ Error in {node.id}: {e}")
            return {"error": str(e)}
    
    def _check_edge_condition(
        self,
        edge: ExecutionEdge,
        context: Dict[str, Any],
        results: Dict[str, Any]
    ) -> bool:
        """Check if edge condition is satisfied"""
        
        if edge.condition == EdgeCondition.ALWAYS:
            return True
        
        if edge.condition_func:
            try:
                # Merge context and results
                combined = {**context, **results.get(edge.from_node, {})}
                return edge.condition_func(combined)
            except:
                return False
        
        # Default conditions
        from_result = results.get(edge.from_node, {})
        
        if edge.condition == EdgeCondition.IF_SUCCESS:
            return not from_result.get('error')
        
        elif edge.condition == EdgeCondition.IF_FAILURE:
            return bool(from_result.get('error'))
        
        return False
    
    def _merge_results(self, results: Dict[str, Any], source_nodes: List[str]) -> Dict[str, Any]:
        """Merge results from multiple source nodes"""
        
        merged = {
            'leads': [],
            'sources': [],
            'metadata': {}
        }
        
        for node_id in source_nodes:
            if node_id not in results:
                continue
            
            node_result = results[node_id]
            
            # Merge leads
            if 'leads' in node_result:
                merged['leads'].extend(node_result['leads'])
            
            # Track sources
            merged['sources'].append(node_id)
            
            # Merge metadata
            if 'metadata' in node_result:
                merged['metadata'][node_id] = node_result['metadata']
        
        # Deduplicate leads
        seen = set()
        unique_leads = []
        for lead in merged['leads']:
            key = lead.get('website', '') or lead.get('company_name', '')
            if key and key not in seen:
                seen.add(key)
                unique_leads.append(lead)
        
        merged['leads'] = unique_leads
        
        return merged
    
    def visualize_graph(self, output_path: str = None):
        """Visualize execution graph"""
        
        import matplotlib.pyplot as plt
        
        pos = nx.spring_layout(self.graph)
        
        # Color nodes by type
        colors = {
            NodeType.START: 'lightgreen',
            NodeType.PLAN: 'lightblue',
            NodeType.SEARCH: 'yellow',
            NodeType.SCRAPE: 'orange',
            NodeType.EXTRACT: 'pink',
            NodeType.VERIFY: 'cyan',
            NodeType.ENRICH: 'magenta',
            NodeType.SCORE: 'lightcoral',
            NodeType.DECIDE: 'lightgray',
            NodeType.MERGE: 'wheat',
            NodeType.END: 'lightgreen'
        }
        
        node_colors = []
        for node_id in self.graph.nodes():
            node = self.nodes[node_id]
            node_colors.append(colors.get(node.node_type, 'white'))
        
        plt.figure(figsize=(15, 10))
        nx.draw(
            self.graph,
            pos,
            node_color=node_colors,
            with_labels=True,
            node_size=2000,
            font_size=8,
            font_weight='bold',
            arrows=True,
            edge_color='gray',
            width=2
        )
        
        if output_path:
            plt.savefig(output_path)
        else:
            plt.show()
        
        plt.close()


# Example usage
async def example_graph_execution():
    """Example of graph-based execution"""
    
    # Mock agents
    class MockAgent:
        def __init__(self, name):
            self.name = name
        
        async def execute(self, context, results):
            await asyncio.sleep(0.1)  # Simulate work
            return {
                'status': 'success',
                'agent': self.name,
                'leads': [{'company': f'{self.name}_lead_{i}'} for i in range(3)]
            }
    
    # Create agents
    agents = {
        'planner': MockAgent('planner'),
        'searcher': MockAgent('searcher'),
        'database': MockAgent('database'),
        'api_enricher': MockAgent('api_enricher'),
        'scraper': MockAgent('scraper'),
        'extractor': MockAgent('extractor'),
        'merger': None,  # Special merge logic
        'verifier_full': MockAgent('verifier_full'),
        'verifier_basic': MockAgent('verifier_basic'),
        'enricher_premium': MockAgent('enricher_premium'),
        'enricher_basic': MockAgent('enricher_basic'),
        'scorer': MockAgent('scorer'),
        'decider': MockAgent('decider')
    }
    
    # Build graph
    planner = GraphBasedPlanner()
    planner.build_research_graph(agents, {})
    
    # Execute
    context = {
        'query': 'Test query',
        'target': 20,
        'budget_remaining': 150
    }
    
    results = await planner.execute_graph(context)
    
    print(f"\nFinal results: {len(results)} nodes executed")
    for node_id, result in results.items():
        print(f"  {node_id}: {result.get('status', 'N/A')}")


if __name__ == "__main__":
    asyncio.run(example_graph_execution())
