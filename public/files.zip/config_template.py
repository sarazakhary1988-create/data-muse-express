"""
Configuration Template for Manus-Style Research Agent
Copy this to config.py and customize for your needs
"""

# API Configuration
ANTHROPIC_API_KEY = "your-api-key-here"  # Set via environment variable instead
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# Research Configuration
DEFAULT_RESEARCH_DEPTH = "wide"  # "wide" or "deep"
DEFAULT_NUM_LEADS = 20
MAX_SEARCH_QUERIES = 8
MAX_SOURCES_TO_SCRAPE = 30

# Scraping Configuration
REQUEST_TIMEOUT = 30  # seconds
MAX_CONCURRENT_REQUESTS = 10
USER_AGENT = "Mozilla/5.0 (Research Agent)"
RETRY_ATTEMPTS = 3
RETRY_DELAY = 2  # seconds

# Report Configuration
REPORT_BRANDING = {
    'primary_color': (41, 98, 255),      # RGB - Main brand color
    'secondary_color': (100, 100, 100),  # RGB - Secondary color
    'company_name': 'Research Intelligence',
    'logo_path': None,  # Optional: path to logo image
}

DEFAULT_REPORT_FORMAT = 'html'  # 'html', 'docx', 'excel', 'json', 'pdf'
OUTPUT_DIRECTORY = '/mnt/user-data/outputs'

# Lead Extraction Configuration
LEAD_FIELDS = [
    'company_name',
    'website',
    'contact_email',
    'phone',
    'industry',
    'employee_count',
    'location',
    'linkedin',
    'description',
    'technologies',
]

# Industry-Specific Keywords (for enhanced extraction)
INDUSTRY_KEYWORDS = {
    'saas': ['software as a service', 'cloud platform', 'subscription software'],
    'fintech': ['financial technology', 'payments', 'banking software'],
    'healthcare': ['medical software', 'health tech', 'telemedicine'],
    'ecommerce': ['online retail', 'marketplace', 'e-commerce platform'],
}

# Location Mapping (for standardization)
LOCATION_ALIASES = {
    'SF': 'San Francisco, CA',
    'NYC': 'New York, NY',
    'LA': 'Los Angeles, CA',
}

# Size Range Mapping
EMPLOYEE_RANGES = {
    'micro': '1-10',
    'small': '11-50',
    'medium': '51-200',
    'large': '201-1000',
    'enterprise': '1000+'
}

# Cache Configuration
ENABLE_CACHE = True
CACHE_DURATION = 3600  # seconds (1 hour)
CACHE_DIRECTORY = '/tmp/research_cache'

# Logging Configuration
LOG_LEVEL = 'INFO'  # DEBUG, INFO, WARNING, ERROR
LOG_FILE = 'research_agent.log'
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# Export Configuration
EXCEL_SHEET_NAMES = {
    'summary': 'Summary',
    'leads': 'Leads',
    'insights': 'Insights',
    'sources': 'Sources',
}

# Web Search Configuration
SEARCH_OPERATORS = {
    'exact': lambda q: f'"{q}"',
    'site': lambda domain, q: f'site:{domain} {q}',
    'exclude': lambda word, q: f'{q} -{word}',
}

# Data Quality Configuration
MIN_CONFIDENCE_SCORE = 0.7  # Minimum confidence for lead inclusion
REQUIRE_EMAIL = False  # Require email to include lead
REQUIRE_WEBSITE = True  # Require website to include lead

# Rate Limiting
REQUESTS_PER_MINUTE = 60
REQUESTS_PER_HOUR = 1000

# Custom Headers for Web Requests
CUSTOM_HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

# Proxy Configuration (if needed)
USE_PROXY = False
PROXY_URL = None  # e.g., 'http://proxy.example.com:8080'

# Error Handling
CONTINUE_ON_ERROR = True  # Continue research even if some sources fail
ERROR_THRESHOLD = 0.3  # Fail if more than 30% of requests error

# Output Options
INCLUDE_METADATA = True
INCLUDE_TIMESTAMPS = True
INCLUDE_SOURCE_URLS = True
PRETTY_PRINT_JSON = True

# Advanced Features
ENABLE_DUPLICATE_DETECTION = True
ENABLE_DATA_ENRICHMENT = True
ENABLE_SENTIMENT_ANALYSIS = False
ENABLE_COMPETITIVE_ANALYSIS = False

# Notification Configuration
ENABLE_NOTIFICATIONS = False
NOTIFICATION_EMAIL = None
NOTIFICATION_WEBHOOK = None

# Development/Testing
DEBUG_MODE = False
MOCK_API_CALLS = False  # Use mock data instead of real API calls
SAVE_RAW_RESPONSES = False  # Save raw API responses for debugging
