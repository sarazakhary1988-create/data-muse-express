# Manus-Style Research Agent 🔬

A powerful, production-ready research agent inspired by Manus 1.6 Max Wide Research capabilities. This agent performs comprehensive lead generation, web scraping, and generates professional reports in multiple formats.

## 🌟 Features

### Core Capabilities
- **Wide Research Mode**: Broad market research across multiple sources
- **Deep Research Mode**: Focused, detailed analysis of specific targets
- **Real Web Scraping**: Extract data from any publicly accessible website
- **Intelligent Lead Generation**: Automated extraction and structuring of company data
- **Multi-Format Reports**: Generate professional reports in DOCX, Excel, HTML, PDF, and JSON

### What Makes This Special
1. **Claude-Powered Intelligence**: Uses Claude Sonnet 4 for smart data extraction and analysis
2. **Async Web Scraping**: Fast, concurrent data collection
3. **Structured Data Extraction**: Converts unstructured web data into actionable leads
4. **Professional Reporting**: Beautiful, client-ready reports in multiple formats
5. **Customizable Workflows**: Easily adapt to your specific use cases

## 📋 Requirements

- Python 3.9+
- Anthropic API key
- Internet connection for web scraping

## 🚀 Quick Start

### 1. Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

### 2. Set up API Key

```bash
# Set your Anthropic API key
export ANTHROPIC_API_KEY='your-api-key-here'
```

Or create a `.env` file:
```
ANTHROPIC_API_KEY=your-api-key-here
```

### 3. Run Your First Research

```python
from manus_agent import ManusStyleAgent

# Initialize the agent
agent = ManusStyleAgent()

# Run research
results = agent.research(
    query="B2B SaaS companies in healthcare with 50-200 employees",
    num_leads=20,
    depth="wide"
)

# Generate HTML report
report_path = agent.generate_report(results, format='html')
print(f"Report saved to: {report_path}")
```

## 📚 Detailed Usage

### Basic Research

```python
from manus_agent import ManusStyleAgent

agent = ManusStyleAgent()

# Simple research
results = agent.research(
    query="AI startups in fintech",
    num_leads=15
)

print(f"Found {len(results.leads)} leads")
for lead in results.leads[:5]:
    print(f"- {lead.company_name}: {lead.website}")
```

### Advanced Research with Custom Parameters

```python
# Wide research for broad market understanding
wide_results = agent.research(
    query="E-commerce platforms using Shopify in USA",
    num_leads=50,
    depth="wide"  # Casts a wide net
)

# Deep research for focused analysis
deep_results = agent.research(
    query="Enterprise SaaS companies in NYC",
    num_leads=20,
    depth="deep"  # More thorough per-source analysis
)
```

### Accessing Lead Data

```python
results = agent.research("Cybersecurity companies in Europe")

for lead in results.leads:
    print(f"""
    Company: {lead.company_name}
    Website: {lead.website}
    Industry: {lead.industry}
    Location: {lead.location}
    Employees: {lead.employee_count}
    Email: {lead.contact_email}
    Phone: {lead.phone}
    LinkedIn: {lead.linkedin}
    Description: {lead.description}
    Technologies: {', '.join(lead.technologies)}
    """)
```

### Generating Reports

```python
from report_generator import ReportGenerator

generator = ReportGenerator(branding={
    'primary_color': (41, 98, 255),
    'secondary_color': (100, 100, 100),
    'company_name': 'Your Company Name'
})

# Generate different formats
html_report = generator.generate_report(results, format='html')
excel_report = generator.generate_report(results, format='excel')
docx_report = generator.generate_report(results, format='docx')
json_report = generator.generate_report(results, format='json')

print(f"Reports generated:")
print(f"- HTML: {html_report}")
print(f"- Excel: {excel_report}")
print(f"- DOCX: {docx_report}")
print(f"- JSON: {json_report}")
```

### Generate All Formats at Once

```python
from report_generator import generate_all_formats

# Generate reports in all formats
all_reports = generate_all_formats(results)
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│          Manus-Style Agent                  │
├─────────────────────────────────────────────┤
│                                             │
│  ┌──────────────────────────────────────┐  │
│  │   1. Research Strategy Generation    │  │
│  │      (Claude AI Planning)            │  │
│  └──────────────────────────────────────┘  │
│                   ↓                         │
│  ┌──────────────────────────────────────┐  │
│  │   2. Web Search Execution            │  │
│  │      (Anthropic Web Search)          │  │
│  └──────────────────────────────────────┘  │
│                   ↓                         │
│  ┌──────────────────────────────────────┐  │
│  │   3. Content Scraping                │  │
│  │      (BeautifulSoup + aiohttp)       │  │
│  └──────────────────────────────────────┘  │
│                   ↓                         │
│  ┌──────────────────────────────────────┐  │
│  │   4. Lead Extraction                 │  │
│  │      (Claude AI Structuring)         │  │
│  └──────────────────────────────────────┘  │
│                   ↓                         │
│  ┌──────────────────────────────────────┐  │
│  │   5. Insight Generation              │  │
│  │      (Claude AI Analysis)            │  │
│  └──────────────────────────────────────┘  │
│                   ↓                         │
│  ┌──────────────────────────────────────┐  │
│  │   6. Report Generation               │  │
│  │      (Multi-format Export)           │  │
│  └──────────────────────────────────────┘  │
│                                             │
└─────────────────────────────────────────────┘
```

## 📊 Report Formats

### HTML Report
- Beautiful, responsive design
- Interactive elements
- Print-ready
- Perfect for client presentations

### Excel Report
- Multiple sheets (Summary, Leads, Insights, Sources)
- Structured data tables
- Easy to filter and analyze
- CRM-ready format

### Word (DOCX) Report
- Professional document formatting
- Detailed lead information
- Executive summary
- Source citations

### JSON Export
- Machine-readable format
- Easy integration with other systems
- Complete data preservation
- API-friendly

## 🎯 Use Cases

### 1. Sales Prospecting
```python
# Find potential customers
results = agent.research(
    query="companies using Salesforce in financial services",
    num_leads=100
)
```

### 2. Market Research
```python
# Understand market landscape
results = agent.research(
    query="emerging fintech companies in Asia Pacific",
    depth="wide"
)
```

### 3. Competitor Analysis
```python
# Identify competitors
results = agent.research(
    query="B2B marketing automation platforms",
    num_leads=30
)
```

### 4. Partnership Opportunities
```python
# Find potential partners
results = agent.research(
    query="API-first companies in developer tools",
    num_leads=25
)
```

## 🔧 Customization

### Custom Branding

```python
from report_generator import ReportGenerator

custom_branding = {
    'primary_color': (255, 87, 34),  # Orange
    'secondary_color': (66, 66, 66),  # Dark gray
    'company_name': 'Acme Research',
    'logo_path': '/path/to/logo.png'  # Optional
}

generator = ReportGenerator(branding=custom_branding)
```

### Custom Lead Structure

Extend the `Lead` dataclass for your specific needs:

```python
from dataclasses import dataclass
from manus_agent import Lead

@dataclass
class ExtendedLead(Lead):
    crm_id: str = None
    deal_stage: str = None
    annual_revenue: str = None
    last_contact: str = None
```

### Custom Scraping Rules

```python
from research_agent import WebScraper

class CustomScraper(WebScraper):
    def _extract_custom_data(self, soup):
        # Your custom extraction logic
        pass
```

## ⚙️ Configuration

### Environment Variables

```bash
# Required
ANTHROPIC_API_KEY=your-api-key

# Optional
MAX_CONCURRENT_REQUESTS=10
REQUEST_TIMEOUT=30
USER_AGENT="CustomAgent/1.0"
```

### Agent Configuration

```python
agent = ManusStyleAgent()
agent.model = "claude-sonnet-4-20250514"  # Change model
agent.max_retries = 3  # Retry failed requests
```

## 📈 Performance Tips

1. **Batch Processing**: Process multiple queries in parallel
2. **Caching**: Cache search results to avoid redundant API calls
3. **Rate Limiting**: Respect rate limits for web scraping
4. **Async Operations**: Use async methods for better performance

## 🔒 Security & Privacy

- Never commit API keys to version control
- Use environment variables for sensitive data
- Respect robots.txt when scraping
- Follow website terms of service
- Implement rate limiting to avoid overload

## 🐛 Troubleshooting

### Common Issues

**Issue**: "No leads found"
- Solution: Try broader search queries or increase num_leads

**Issue**: "API rate limit exceeded"
- Solution: Implement exponential backoff or reduce concurrent requests

**Issue**: "Scraping timeout"
- Solution: Increase timeout value or reduce number of sources

**Issue**: "Invalid JSON response"
- Solution: Check Claude's response format or update parsing logic

## 📝 Examples

### Complete Workflow Example

```python
from manus_agent import ManusStyleAgent
from report_generator import ReportGenerator
import json

# Initialize
agent = ManusStyleAgent()
generator = ReportGenerator()

# Research
print("Starting research...")
results = agent.research(
    query="SaaS companies in HR tech with 10-100 employees",
    num_leads=30,
    depth="wide"
)

# Analyze results
print(f"\nResults Summary:")
print(f"Total Leads: {len(results.leads)}")
print(f"Industries: {set(l.industry for l in results.leads if l.industry)}")
print(f"Locations: {set(l.location for l in results.leads if l.location)}")

# Generate reports
print("\nGenerating reports...")
html_path = generator.generate_report(results, format='html')
excel_path = generator.generate_report(results, format='excel')

print(f"✓ HTML: {html_path}")
print(f"✓ Excel: {excel_path}")

# Export to JSON for further processing
with open('leads.json', 'w') as f:
    json.dump({
        'leads': [vars(lead) for lead in results.leads],
        'insights': results.insights
    }, f, indent=2)

print("✓ Complete!")
```

## 🤝 Contributing

This is a starter template. Feel free to customize and extend it for your needs!

## 📄 License

MIT License - feel free to use in your projects

## 🙏 Credits

Inspired by Manus 1.6 Max Wide Research capabilities
Powered by Claude AI from Anthropic

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the examples
3. Check Anthropic's documentation

---

**Happy Researching! 🚀**
