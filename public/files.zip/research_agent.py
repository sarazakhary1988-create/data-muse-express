"""
Advanced Research Agent for Lead Generation and Web Scraping
Inspired by Manus 1.6 Max Wide Research capabilities
"""

import asyncio
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
import aiohttp
from bs4 import BeautifulSoup
import anthropic
import os

@dataclass
class Lead:
    """Lead information structure"""
    company_name: str
    website: str
    contact_email: Optional[str] = None
    phone: Optional[str] = None
    industry: Optional[str] = None
    employee_count: Optional[str] = None
    location: Optional[str] = None
    linkedin: Optional[str] = None
    description: Optional[str] = None
    technologies: List[str] = None
    last_updated: str = None
    
    def __post_init__(self):
        if self.technologies is None:
            self.technologies = []
        if self.last_updated is None:
            self.last_updated = datetime.now().isoformat()

@dataclass
class ResearchResult:
    """Research result structure"""
    query: str
    leads: List[Lead]
    insights: List[str]
    sources: List[str]
    timestamp: str
    metadata: Dict[str, Any]

class WebScraper:
    """Advanced web scraping with multiple strategies"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    async def scrape_url(self, url: str, session: aiohttp.ClientSession) -> Dict[str, Any]:
        """Scrape a single URL"""
        try:
            async with session.get(url, headers=self.headers, timeout=15) as response:
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                return {
                    'url': url,
                    'title': soup.title.string if soup.title else '',
                    'text': self._extract_text(soup),
                    'emails': self._extract_emails(html),
                    'phones': self._extract_phones(html),
                    'links': self._extract_links(soup, url),
                    'meta': self._extract_meta(soup)
                }
        except Exception as e:
            return {'url': url, 'error': str(e)}
    
    def _extract_text(self, soup: BeautifulSoup) -> str:
        """Extract clean text from HTML"""
        # Remove script and style elements
        for script in soup(['script', 'style', 'nav', 'footer']):
            script.decompose()
        
        text = soup.get_text(separator=' ', strip=True)
        return ' '.join(text.split())[:5000]  # Limit text length
    
    def _extract_emails(self, html: str) -> List[str]:
        """Extract email addresses"""
        import re
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = list(set(re.findall(email_pattern, html)))
        # Filter out common noise
        return [e for e in emails if not any(x in e.lower() for x in ['example.com', 'placeholder', 'test'])]
    
    def _extract_phones(self, html: str) -> List[str]:
        """Extract phone numbers"""
        import re
        phone_pattern = r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
        return list(set(re.findall(phone_pattern, html)))
    
    def _extract_links(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Extract links from page"""
        from urllib.parse import urljoin, urlparse
        links = []
        for link in soup.find_all('a', href=True):
            full_url = urljoin(base_url, link['href'])
            if urlparse(full_url).netloc:
                links.append(full_url)
        return list(set(links))[:50]  # Limit to 50 links
    
    def _extract_meta(self, soup: BeautifulSoup) -> Dict[str, str]:
        """Extract meta information"""
        meta = {}
        for tag in soup.find_all('meta'):
            name = tag.get('name') or tag.get('property', '')
            content = tag.get('content', '')
            if name and content:
                meta[name] = content
        return meta

class ResearchAgent:
    """Main research agent orchestrator"""
    
    def __init__(self, api_key: str):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.scraper = WebScraper()
        self.model = "claude-sonnet-4-20250514"
    
    async def research(self, query: str, depth: str = "wide") -> ResearchResult:
        """
        Perform comprehensive research
        
        Args:
            query: Research query/topic
            depth: "wide" for broad research, "deep" for focused analysis
        """
        print(f"🔍 Starting {depth} research on: {query}")
        
        # Step 1: Generate research plan
        research_plan = await self._generate_research_plan(query, depth)
        print(f"📋 Research plan generated with {len(research_plan['search_queries'])} queries")
        
        # Step 2: Execute web searches and scraping
        scraped_data = await self._execute_research(research_plan['search_queries'])
        print(f"🌐 Collected data from {len(scraped_data)} sources")
        
        # Step 3: Extract and structure leads
        leads = await self._extract_leads(scraped_data, query)
        print(f"💼 Extracted {len(leads)} leads")
        
        # Step 4: Generate insights
        insights = await self._generate_insights(scraped_data, leads, query)
        
        return ResearchResult(
            query=query,
            leads=leads,
            insights=insights,
            sources=[d['url'] for d in scraped_data if 'url' in d],
            timestamp=datetime.now().isoformat(),
            metadata={
                'depth': depth,
                'total_sources': len(scraped_data),
                'research_plan': research_plan
            }
        )
    
    async def _generate_research_plan(self, query: str, depth: str) -> Dict[str, Any]:
        """Generate a research plan using Claude"""
        
        prompt = f"""You are a research planning expert. Create a comprehensive research plan for the following query:

Query: {query}
Depth: {depth}

Generate a research plan with:
1. 5-10 specific search queries to find relevant information
2. Key data points to look for
3. Target website types to prioritize

Respond in JSON format:
{{
    "search_queries": ["query1", "query2", ...],
    "key_data_points": ["data1", "data2", ...],
    "target_sites": ["type1", "type2", ...]
}}"""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        response_text = message.content[0].text
        # Extract JSON from response
        import re
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
        
        # Fallback
        return {
            "search_queries": [query],
            "key_data_points": ["company name", "contact info", "industry"],
            "target_sites": ["company websites", "directories"]
        }
    
    async def _execute_research(self, queries: List[str]) -> List[Dict[str, Any]]:
        """Execute research queries and scrape results"""
        all_data = []
        
        async with aiohttp.ClientSession() as session:
            # For demo purposes, simulate some URLs
            # In production, you'd integrate with search APIs or use the Anthropic web_search tool
            demo_urls = [
                "https://example.com",
                # Add actual URLs based on your research
            ]
            
            tasks = [self.scraper.scrape_url(url, session) for url in demo_urls]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, dict) and 'error' not in result:
                    all_data.append(result)
        
        return all_data
    
    async def _extract_leads(self, scraped_data: List[Dict], query: str) -> List[Lead]:
        """Extract structured lead information using Claude"""
        
        # Prepare data for Claude
        data_summary = json.dumps(scraped_data[:5], indent=2)[:4000]  # Limit size
        
        prompt = f"""Analyze the following web scraping data and extract structured lead information.

Query context: {query}

Scraped data:
{data_summary}

Extract all companies/leads found and return them in JSON array format:
[
    {{
        "company_name": "Company Name",
        "website": "url",
        "contact_email": "email or null",
        "phone": "phone or null",
        "industry": "industry or null",
        "location": "location or null",
        "description": "brief description",
        "technologies": ["tech1", "tech2"]
    }}
]

Return only valid JSON array."""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=4000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        response_text = message.content[0].text
        
        # Extract JSON array
        import re
        json_match = re.search(r'\[.*\]', response_text, re.DOTALL)
        
        leads = []
        if json_match:
            try:
                leads_data = json.loads(json_match.group())
                leads = [Lead(**lead_data) for lead_data in leads_data]
            except Exception as e:
                print(f"Error parsing leads: {e}")
        
        return leads
    
    async def _generate_insights(self, scraped_data: List[Dict], 
                                 leads: List[Lead], query: str) -> List[str]:
        """Generate insights from research"""
        
        data_summary = {
            'total_sources': len(scraped_data),
            'total_leads': len(leads),
            'industries': list(set(l.industry for l in leads if l.industry)),
            'locations': list(set(l.location for l in leads if l.location))
        }
        
        prompt = f"""Based on the research for "{query}", provide 5-7 key insights.

Data summary:
{json.dumps(data_summary, indent=2)}

Sample leads:
{json.dumps([asdict(l) for l in leads[:3]], indent=2)}

Provide insights as a JSON array of strings:
["insight 1", "insight 2", ...]"""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        response_text = message.content[0].text
        
        import re
        json_match = re.search(r'\[.*\]', response_text, re.DOTALL)
        
        if json_match:
            try:
                return json.loads(json_match.group())
            except:
                pass
        
        return ["Research completed successfully", f"Found {len(leads)} leads"]

# Example usage
async def main():
    # Replace with your Anthropic API key
    api_key = os.environ.get("ANTHROPIC_API_KEY", "your-api-key-here")
    
    agent = ResearchAgent(api_key)
    
    # Perform research
    results = await agent.research(
        query="SaaS companies in healthcare with 50-200 employees",
        depth="wide"
    )
    
    print("\n" + "="*50)
    print("RESEARCH RESULTS")
    print("="*50)
    print(f"\nQuery: {results.query}")
    print(f"Leads found: {len(results.leads)}")
    print(f"\nInsights:")
    for insight in results.insights:
        print(f"  • {insight}")

if __name__ == "__main__":
    asyncio.run(main())
