#!/usr/bin/env python3
"""
Quick Start Example for Manus-Style Research Agent
Run this to see the agent in action!
"""

import os
import sys
from datetime import datetime

# Mock implementation for demonstration
# In production, this would use the actual web search and scraping

def demo_research():
    """
    Demonstration of how the research agent works
    This creates sample data to show the workflow
    """
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║         🔬 MANUS-STYLE RESEARCH AGENT DEMO                     ║
║                                                                ║
║  This demonstrates the complete workflow from query to         ║
║  professional report generation.                               ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # Check for API key
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("⚠️  WARNING: ANTHROPIC_API_KEY not set")
        print("   For full functionality, set your API key:")
        print("   export ANTHROPIC_API_KEY='your-key-here'")
        print("\n   Continuing with demo data...\n")
    
    # Sample query
    query = "B2B SaaS companies in healthcare with 50-200 employees"
    
    print(f"📋 RESEARCH QUERY")
    print(f"   {query}")
    print(f"\n{'─'*60}\n")
    
    # Step 1: Strategy
    print("⚙️  STEP 1: Generating Research Strategy")
    search_queries = [
        "healthcare SaaS companies directory",
        "B2B healthcare software 50-200 employees",
        "medical practice management software companies",
        "healthcare technology startups",
        "EHR software vendors list"
    ]
    
    for i, q in enumerate(search_queries, 1):
        print(f"   [{i}] {q}")
    
    print(f"\n{'─'*60}\n")
    
    # Step 2: Web Search
    print("🌐 STEP 2: Executing Web Searches")
    print("   [1/5] Searching: healthcare SaaS companies directory")
    print("   [2/5] Searching: B2B healthcare software 50-200 employees")
    print("   [3/5] Searching: medical practice management software companies")
    print("   [4/5] Searching: healthcare technology startups")
    print("   [5/5] Searching: EHR software vendors list")
    print("   ✓ Found 47 search results")
    
    print(f"\n{'─'*60}\n")
    
    # Step 3: Scraping
    print("🔍 STEP 3: Scraping Website Content")
    print("   Extracting data from top results...")
    print("   [████████████████████████████████████████] 30/30")
    print("   ✓ Scraped 30 websites")
    
    print(f"\n{'─'*60}\n")
    
    # Step 4: Lead Extraction
    print("💼 STEP 4: Extracting Structured Leads")
    
    # Sample leads
    sample_leads = [
        {
            'company_name': 'HealthTech Solutions',
            'website': 'https://healthtech-demo.com',
            'industry': 'Healthcare SaaS',
            'location': 'Boston, MA',
            'employee_count': '75',
            'description': 'Cloud-based practice management platform for clinics'
        },
        {
            'company_name': 'MedFlow Systems',
            'website': 'https://medflow-demo.com',
            'industry': 'Healthcare Software',
            'location': 'Austin, TX',
            'employee_count': '120',
            'description': 'Patient engagement and workflow automation tools'
        },
        {
            'company_name': 'CareConnect Platform',
            'website': 'https://careconnect-demo.com',
            'industry': 'Digital Health',
            'location': 'San Francisco, CA',
            'employee_count': '95',
            'description': 'Integrated telehealth and EHR solution'
        },
        {
            'company_name': 'ClinicOS',
            'website': 'https://clinicos-demo.com',
            'industry': 'Healthcare IT',
            'location': 'Seattle, WA',
            'employee_count': '65',
            'description': 'Modern operating system for medical practices'
        },
        {
            'company_name': 'PatientFirst Software',
            'website': 'https://patientfirst-demo.com',
            'industry': 'Healthcare SaaS',
            'location': 'Denver, CO',
            'employee_count': '85',
            'description': 'Patient portal and communication platform'
        }
    ]
    
    print(f"   ✓ Extracted {len(sample_leads)} qualified leads\n")
    
    for i, lead in enumerate(sample_leads, 1):
        print(f"   [{i}] {lead['company_name']}")
        print(f"       Industry: {lead['industry']}")
        print(f"       Location: {lead['location']}")
        print(f"       Employees: {lead['employee_count']}")
        print()
    
    print(f"{'─'*60}\n")
    
    # Step 5: Insights
    print("💡 STEP 5: Generating Insights")
    
    insights = [
        "Healthcare SaaS market shows strong concentration in major tech hubs (Boston, SF, Austin)",
        "Average company size in this segment is 80-100 employees, indicating mature startups",
        "Practice management and patient engagement are the dominant product categories",
        "Growing trend toward integrated platforms combining EHR, telehealth, and billing",
        "Geographic distribution suggests proximity to major healthcare systems and talent pools"
    ]
    
    for i, insight in enumerate(insights, 1):
        print(f"   {i}. {insight}")
    
    print(f"\n{'─'*60}\n")
    
    # Report Generation
    print("📊 STEP 6: Generating Reports")
    print("\n   Available formats:")
    print("   • HTML  - Interactive web report")
    print("   • Excel - Spreadsheet with multiple sheets")
    print("   • DOCX  - Professional Word document")
    print("   • JSON  - Machine-readable data")
    print("   • PDF   - Print-ready document")
    
    print(f"\n{'─'*60}\n")
    
    print("✅ RESEARCH COMPLETE!")
    print(f"\n   Total Leads Found: {len(sample_leads)}")
    print(f"   Key Insights: {len(insights)}")
    print(f"   Sources Analyzed: 47")
    print(f"   Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    print(f"\n{'═'*60}\n")
    
    print("📌 NEXT STEPS:")
    print("\n   1. Set your ANTHROPIC_API_KEY to enable real research")
    print("   2. Run: python manus_agent.py")
    print("   3. Customize queries for your use case")
    print("   4. Generate reports in your preferred format")
    
    print(f"\n{'═'*60}\n")
    
    print("💡 EXAMPLE CODE:")
    print("""
    from manus_agent import ManusStyleAgent
    
    agent = ManusStyleAgent()
    results = agent.research(
        query="Your research query here",
        num_leads=20,
        depth="wide"
    )
    
    # Generate HTML report
    report = agent.generate_report(results, format='html')
    print(f"Report: {report}")
    """)
    
    print(f"\n{'═'*60}\n")

if __name__ == "__main__":
    try:
        demo_research()
    except KeyboardInterrupt:
        print("\n\n👋 Demo interrupted. Thanks for trying!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)
