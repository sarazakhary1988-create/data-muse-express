"""
Multi-Format Report Generator
Supports PDF, DOCX, Excel, HTML with professional styling
"""

from typing import List, Dict, Any
from datetime import datetime
import json
from dataclasses import asdict

# Import for document generation
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import pandas as pd
from io import BytesIO

class ReportGenerator:
    """Generate professional reports in multiple formats"""
    
    def __init__(self, branding: Dict[str, Any] = None):
        """
        Initialize report generator
        
        Args:
            branding: Dict with colors, logo_path, company_name
        """
        self.branding = branding or {
            'primary_color': (41, 98, 255),  # Blue
            'secondary_color': (100, 100, 100),  # Gray
            'company_name': 'Research Intelligence'
        }
    
    def generate_report(self, results, format: str = 'docx', 
                       output_path: str = None) -> str:
        """
        Generate report in specified format
        
        Args:
            results: ResearchResult object
            format: 'docx', 'pdf', 'excel', 'html', or 'json'
            output_path: Where to save the report
        
        Returns:
            Path to generated report
        """
        if not output_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"/mnt/user-data/outputs/research_report_{timestamp}.{format}"
        
        if format == 'docx':
            return self._generate_docx(results, output_path)
        elif format == 'excel':
            return self._generate_excel(results, output_path)
        elif format == 'html':
            return self._generate_html(results, output_path)
        elif format == 'json':
            return self._generate_json(results, output_path)
        elif format == 'pdf':
            # Generate DOCX first, then convert to PDF
            docx_path = output_path.replace('.pdf', '.docx')
            self._generate_docx(results, docx_path)
            return self._convert_to_pdf(docx_path, output_path)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _generate_docx(self, results, output_path: str) -> str:
        """Generate professional Word document"""
        doc = Document()
        
        # Set document margins
        sections = doc.sections
        for section in sections:
            section.top_margin = Inches(1)
            section.bottom_margin = Inches(1)
            section.left_margin = Inches(1)
            section.right_margin = Inches(1)
        
        # Title
        title = doc.add_heading('Lead Generation Research Report', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Subtitle with query
        subtitle = doc.add_paragraph()
        subtitle_run = subtitle.add_run(f'Research Query: {results.query}')
        subtitle_run.font.size = Pt(14)
        subtitle_run.font.color.rgb = RGBColor(*self.branding['secondary_color'])
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Metadata section
        doc.add_paragraph()
        meta_para = doc.add_paragraph()
        meta_para.add_run('Generated: ').bold = True
        meta_para.add_run(f"{datetime.fromisoformat(results.timestamp).strftime('%B %d, %Y at %I:%M %p')}\n")
        meta_para.add_run('Total Leads Found: ').bold = True
        meta_para.add_run(f"{len(results.leads)}\n")
        meta_para.add_run('Sources Analyzed: ').bold = True
        meta_para.add_run(f"{len(results.sources)}")
        
        doc.add_page_break()
        
        # Executive Summary
        doc.add_heading('Executive Summary', 1)
        
        summary_points = [
            f"Conducted {results.metadata['depth']} research analysis",
            f"Analyzed {results.metadata['total_sources']} unique sources",
            f"Identified {len(results.leads)} qualified leads",
            f"Generated {len(results.insights)} key insights"
        ]
        
        for point in summary_points:
            doc.add_paragraph(point, style='List Bullet')
        
        # Key Insights
        doc.add_heading('Key Insights', 1)
        for i, insight in enumerate(results.insights, 1):
            p = doc.add_paragraph()
            p.add_run(f'{i}. ').bold = True
            p.add_run(insight)
        
        doc.add_page_break()
        
        # Leads Detail
        doc.add_heading('Detailed Lead Information', 1)
        
        for i, lead in enumerate(results.leads, 1):
            # Lead header
            lead_heading = doc.add_heading(f'{i}. {lead.company_name}', 2)
            
            # Lead details table
            table = doc.add_table(rows=0, cols=2)
            table.style = 'Light Grid Accent 1'
            
            # Add lead information
            lead_info = [
                ('Website', lead.website or 'N/A'),
                ('Industry', lead.industry or 'N/A'),
                ('Location', lead.location or 'N/A'),
                ('Employee Count', lead.employee_count or 'N/A'),
                ('Contact Email', lead.contact_email or 'N/A'),
                ('Phone', lead.phone or 'N/A'),
                ('LinkedIn', lead.linkedin or 'N/A'),
            ]
            
            for label, value in lead_info:
                row = table.add_row()
                row.cells[0].text = label
                row.cells[0].paragraphs[0].runs[0].font.bold = True
                row.cells[1].text = str(value)
            
            # Description
            if lead.description:
                doc.add_paragraph()
                desc_para = doc.add_paragraph()
                desc_para.add_run('Description: ').bold = True
                desc_para.add_run(lead.description)
            
            # Technologies
            if lead.technologies:
                doc.add_paragraph()
                tech_para = doc.add_paragraph()
                tech_para.add_run('Technologies: ').bold = True
                tech_para.add_run(', '.join(lead.technologies))
            
            doc.add_paragraph()  # Spacing
        
        # Sources
        doc.add_page_break()
        doc.add_heading('Research Sources', 1)
        for i, source in enumerate(results.sources, 1):
            doc.add_paragraph(f'{i}. {source}', style='List Number')
        
        # Save document
        doc.save(output_path)
        return output_path
    
    def _generate_excel(self, results, output_path: str) -> str:
        """Generate Excel spreadsheet with multiple sheets"""
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Summary sheet
            summary_data = {
                'Metric': [
                    'Research Query',
                    'Date Generated',
                    'Total Leads',
                    'Total Sources',
                    'Research Depth'
                ],
                'Value': [
                    results.query,
                    datetime.fromisoformat(results.timestamp).strftime('%Y-%m-%d %H:%M'),
                    len(results.leads),
                    len(results.sources),
                    results.metadata['depth']
                ]
            }
            pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)
            
            # Leads sheet
            if results.leads:
                leads_data = [asdict(lead) for lead in results.leads]
                df_leads = pd.DataFrame(leads_data)
                
                # Convert technologies list to string
                if 'technologies' in df_leads.columns:
                    df_leads['technologies'] = df_leads['technologies'].apply(
                        lambda x: ', '.join(x) if isinstance(x, list) else ''
                    )
                
                df_leads.to_excel(writer, sheet_name='Leads', index=False)
            
            # Insights sheet
            insights_data = {
                'Insight #': range(1, len(results.insights) + 1),
                'Insight': results.insights
            }
            pd.DataFrame(insights_data).to_excel(writer, sheet_name='Insights', index=False)
            
            # Sources sheet
            sources_data = {
                'Source #': range(1, len(results.sources) + 1),
                'URL': results.sources
            }
            pd.DataFrame(sources_data).to_excel(writer, sheet_name='Sources', index=False)
        
        return output_path
    
    def _generate_html(self, results, output_path: str) -> str:
        """Generate interactive HTML report"""
        
        html_template = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Research Report - {results.query}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        header {{
            background: linear-gradient(135deg, rgb({','.join(map(str, self.branding['primary_color']))}) 0%, rgb({','.join(map(str, self.branding['secondary_color']))}) 100%);
            color: white;
            padding: 40px 20px;
            text-align: center;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        
        h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .subtitle {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .metadata {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        
        .metadata-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }}
        
        .metadata-item {{
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid rgb({','.join(map(str, self.branding['primary_color']))});
        }}
        
        .metadata-label {{
            font-weight: bold;
            color: #666;
            font-size: 0.9em;
            margin-bottom: 5px;
        }}
        
        .metadata-value {{
            font-size: 1.3em;
            color: #333;
        }}
        
        .section {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        
        h2 {{
            color: rgb({','.join(map(str, self.branding['primary_color']))});
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }}
        
        .insight {{
            padding: 15px;
            margin: 10px 0;
            background: #f8f9fa;
            border-left: 4px solid rgb({','.join(map(str, self.branding['primary_color']))});
            border-radius: 4px;
        }}
        
        .lead-card {{
            background: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        
        .lead-card:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }}
        
        .lead-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }}
        
        .lead-title {{
            font-size: 1.5em;
            color: rgb({','.join(map(str, self.branding['primary_color']))});
            font-weight: bold;
        }}
        
        .lead-details {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        
        .detail-item {{
            display: flex;
            flex-direction: column;
        }}
        
        .detail-label {{
            font-weight: bold;
            color: #666;
            font-size: 0.9em;
            margin-bottom: 5px;
        }}
        
        .detail-value {{
            color: #333;
        }}
        
        .tags {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }}
        
        .tag {{
            background: rgb({','.join(map(str, self.branding['primary_color']))});
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
        }}
        
        .sources-list {{
            list-style: none;
        }}
        
        .sources-list li {{
            padding: 10px;
            margin: 5px 0;
            background: #f8f9fa;
            border-radius: 4px;
            word-break: break-all;
        }}
        
        .sources-list a {{
            color: rgb({','.join(map(str, self.branding['primary_color']))});
            text-decoration: none;
        }}
        
        .sources-list a:hover {{
            text-decoration: underline;
        }}
        
        @media print {{
            .container {{
                max-width: 100%;
            }}
            
            .lead-card {{
                page-break-inside: avoid;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Lead Generation Research Report</h1>
            <div class="subtitle">{results.query}</div>
        </header>
        
        <div class="metadata">
            <div class="metadata-grid">
                <div class="metadata-item">
                    <div class="metadata-label">Generated</div>
                    <div class="metadata-value">{datetime.fromisoformat(results.timestamp).strftime('%b %d, %Y')}</div>
                </div>
                <div class="metadata-item">
                    <div class="metadata-label">Total Leads</div>
                    <div class="metadata-value">{len(results.leads)}</div>
                </div>
                <div class="metadata-item">
                    <div class="metadata-label">Sources</div>
                    <div class="metadata-value">{len(results.sources)}</div>
                </div>
                <div class="metadata-item">
                    <div class="metadata-label">Research Type</div>
                    <div class="metadata-value">{results.metadata['depth'].title()}</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>Key Insights</h2>
            {''.join(f'<div class="insight">{insight}</div>' for insight in results.insights)}
        </div>
        
        <div class="section">
            <h2>Lead Details ({len(results.leads)} Found)</h2>
"""
        
        # Add leads
        for i, lead in enumerate(results.leads, 1):
            html_template += f"""
            <div class="lead-card">
                <div class="lead-header">
                    <div class="lead-title">{i}. {lead.company_name}</div>
                </div>
                <div class="lead-details">
                    <div class="detail-item">
                        <span class="detail-label">Website</span>
                        <span class="detail-value">{lead.website or 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Industry</span>
                        <span class="detail-value">{lead.industry or 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Location</span>
                        <span class="detail-value">{lead.location or 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Employees</span>
                        <span class="detail-value">{lead.employee_count or 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Email</span>
                        <span class="detail-value">{lead.contact_email or 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Phone</span>
                        <span class="detail-value">{lead.phone or 'N/A'}</span>
                    </div>
                </div>
"""
            if lead.description:
                html_template += f"""
                <div style="margin-top: 15px;">
                    <div class="detail-label">Description</div>
                    <div class="detail-value">{lead.description}</div>
                </div>
"""
            if lead.technologies:
                html_template += f"""
                <div class="tags">
                    {''.join(f'<span class="tag">{tech}</span>' for tech in lead.technologies)}
                </div>
"""
            html_template += "</div>"
        
        # Add sources
        html_template += f"""
        </div>
        
        <div class="section">
            <h2>Research Sources</h2>
            <ul class="sources-list">
                {''.join(f'<li><a href="{source}" target="_blank">{source}</a></li>' for source in results.sources)}
            </ul>
        </div>
    </div>
</body>
</html>
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_template)
        
        return output_path
    
    def _generate_json(self, results, output_path: str) -> str:
        """Generate JSON export"""
        
        export_data = {
            'query': results.query,
            'timestamp': results.timestamp,
            'metadata': results.metadata,
            'leads': [asdict(lead) for lead in results.leads],
            'insights': results.insights,
            'sources': results.sources
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        return output_path
    
    def _convert_to_pdf(self, docx_path: str, pdf_path: str) -> str:
        """Convert DOCX to PDF (requires external library)"""
        try:
            from docx2pdf import convert
            convert(docx_path, pdf_path)
            return pdf_path
        except ImportError:
            print("Warning: docx2pdf not installed. Returning DOCX instead.")
            return docx_path
        except Exception as e:
            print(f"PDF conversion failed: {e}. Returning DOCX instead.")
            return docx_path

# Example usage function
def generate_all_formats(results):
    """Generate reports in all formats"""
    generator = ReportGenerator()
    
    formats = ['docx', 'excel', 'html', 'json']
    generated_files = []
    
    for fmt in formats:
        try:
            file_path = generator.generate_report(results, format=fmt)
            generated_files.append(file_path)
            print(f"✓ Generated {fmt.upper()} report: {file_path}")
        except Exception as e:
            print(f"✗ Failed to generate {fmt.upper()}: {e}")
    
    return generated_files
