"""
Complete Research Agent Integration
Combines web search, scraping, lead generation, and report generation
"""

import asyncio
import os
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime
import anthropic

@dataclass
class Lead:
    company_name: str
    website: str
    contact_email: str = None
    phone: str = None
    industry: str = None
    employee_count: str = None
    location: str = None
    linkedin: str = None
    description: str = None
    technologies: List[str] = None
    last_updated: str = None
    
    def __post_init__(self):
        if self.technologies is None:
            self.technologies = []
        if self.last_updated is None:
            self.last_updated = datetime.now().isoformat()

@dataclass
class ResearchResult:
    query: str
    leads: List[Lead]
    insights: List[str]
    sources: List[str]
    timestamp: str
    metadata: Dict[str, Any]

class ManusStyleAgent:
    """
    Complete research agent with Manus 1.6-style capabilities:
    - Wide research across multiple sources
    - Real web scraping and data extraction
    - Structured lead generation
    - Multi-format report generation
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY must be set")
        
        self.client = anthropic.Anthropic(api_key=self.api_key)
        self.model = "claude-sonnet-4-20250514"
    
    def research(self, query: str, num_leads: int = 20, depth: str = "wide") -> ResearchResult:
        """
        Main research method that orchestrates everything
        
        Args:
            query: Research query (e.g., "SaaS companies in fintech")
            num_leads: Target number of leads
            depth: "wide" for broad search, "deep" for focused
        
        Returns:
            ResearchResult with all findings
        """
        print(f"\n{'='*60}")
        print(f"🔬 MANUS-STYLE RESEARCH AGENT")
        print(f"{'='*60}")
        print(f"Query: {query}")
        print(f"Target Leads: {num_leads}")
        print(f"Depth: {depth}")
        print(f"{'='*60}\n")
        
        # Step 1: Generate search strategy
        print("📋 Step 1: Generating research strategy...")
        search_queries = self._generate_search_strategy(query, num_leads, depth)
        print(f"   Generated {len(search_queries)} search queries")
        
        # Step 2: Execute web searches
        print("\n🌐 Step 2: Executing web searches...")
        all_search_results = []
        for i, search_query in enumerate(search_queries, 1):
            print(f"   [{i}/{len(search_queries)}] Searching: {search_query}")
            results = self._web_search(search_query)
            all_search_results.extend(results)
        
        print(f"   Found {len(all_search_results)} total search results")
        
        # Step 3: Extract and scrape detailed information
        print("\n🔍 Step 3: Extracting lead information...")
        scraped_content = self._scrape_search_results(all_search_results[:30])  # Limit to top 30
        
        # Step 4: Structure leads
        print("\n💼 Step 4: Structuring leads...")
        leads = self._extract_structured_leads(scraped_content, query, num_leads)
        print(f"   Extracted {len(leads)} qualified leads")
        
        # Step 5: Generate insights
        print("\n💡 Step 5: Generating insights...")
        insights = self._generate_insights(leads, query, scraped_content)
        
        # Compile results
        sources = [r.get('url', '') for r in all_search_results[:20]]
        
        result = ResearchResult(
            query=query,
            leads=leads,
            insights=insights,
            sources=sources,
            timestamp=datetime.now().isoformat(),
            metadata={
                'depth': depth,
                'total_sources': len(all_search_results),
                'search_queries': search_queries,
                'target_leads': num_leads
            }
        )
        
        print("\n✅ Research complete!")
        return result
    
    def _generate_search_strategy(self, query: str, num_leads: int, depth: str) -> List[str]:
        """Generate strategic search queries"""
        
        prompt = f"""You are a research strategist. Generate search queries to find leads based on this request:

Query: {query}
Target: {num_leads} leads
Depth: {depth}

Generate 5-8 specific, targeted search queries that will help find relevant companies and leads.
Focus on queries that will return:
1. Company directories and listings
2. Industry-specific sites
3. Technology company databases
4. Professional networks and communities

Return as a JSON array of strings:
["query 1", "query 2", ...]

Make queries specific and actionable."""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}]
        )
        
        import re
        import json
        
        response_text = message.content[0].text
        json_match = re.search(r'\[.*?\]', response_text, re.DOTALL)
        
        if json_match:
            try:
                queries = json.loads(json_match.group())
                return queries[:8]  # Limit to 8
            except:
                pass
        
        # Fallback
        return [
            f"{query} companies list",
            f"{query} company directory",
            f"top {query} businesses",
            f"{query} company database"
        ]
    
    def _web_search(self, query: str) -> List[Dict[str, Any]]:
        """Execute web search using Claude's web_search tool"""
        
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=4000,
                tools=[{
                    "type": "web_search_20250305",
                    "name": "web_search"
                }],
                messages=[{
                    "role": "user",
                    "content": f"Search the web for: {query}\n\nReturn the search results."
                }]
            )
            
            search_results = []
            
            # Extract search results from tool use
            for block in message.content:
                if block.type == "tool_use" and block.name == "web_search":
                    # The tool was invoked
                    pass
                elif hasattr(block, 'text'):
                    # Try to extract URLs and snippets from the text response
                    text = block.text
                    
                    # Parse search results (this is simplified)
                    import re
                    urls = re.findall(r'https?://[^\s<>"]+', text)
                    
                    for url in urls:
                        search_results.append({
                            'url': url,
                            'snippet': text[:200]  # Simplified
                        })
            
            return search_results if search_results else []
            
        except Exception as e:
            print(f"   Search error: {e}")
            return []
    
    def _scrape_search_results(self, search_results: List[Dict]) -> List[Dict[str, Any]]:
        """Scrape detailed content from search results"""
        
        scraped_data = []
        
        for result in search_results[:15]:  # Limit scraping
            url = result.get('url', '')
            if not url:
                continue
            
            try:
                # Use Claude's web_fetch capability through the API
                message = self.client.messages.create(
                    model=self.model,
                    max_tokens=3000,
                    tools=[{
                        "type": "web_fetch_20250305",
                        "name": "web_fetch"
                    }],
                    messages=[{
                        "role": "user",
                        "content": f"Fetch and analyze this webpage: {url}\n\nExtract company information if present."
                    }]
                )
                
                # Extract content
                content = ""
                for block in message.content:
                    if hasattr(block, 'text'):
                        content += block.text
                
                scraped_data.append({
                    'url': url,
                    'content': content,
                    'snippet': result.get('snippet', '')
                })
                
            except Exception as e:
                # Skip failed scrapes
                continue
        
        return scraped_data
    
    def _extract_structured_leads(self, scraped_content: List[Dict], 
                                  query: str, num_leads: int) -> List[Lead]:
        """Extract structured lead information from scraped content"""
        
        # Prepare content summary
        content_text = "\n\n".join([
            f"Source: {item['url']}\nContent: {item.get('content', '')[:1000]}"
            for item in scraped_content[:10]
        ])
        
        prompt = f"""Analyze the following web content and extract structured lead/company information.

Original Query: {query}
Target: Extract up to {num_leads} unique companies/leads

Web Content:
{content_text}

Extract company information and return as a JSON array:
[
  {{
    "company_name": "Full Company Name",
    "website": "https://example.com",
    "contact_email": "email@company.com or null",
    "phone": "+1-XXX-XXX-XXXX or null",
    "industry": "Industry category",
    "employee_count": "10-50 or null",
    "location": "City, State/Country",
    "linkedin": "LinkedIn URL or null",
    "description": "Brief 1-2 sentence description",
    "technologies": ["tech1", "tech2"] or []
  }}
]

Focus on finding real, verifiable companies. Return ONLY the JSON array."""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=8000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        import re
        import json
        
        response_text = message.content[0].text
        json_match = re.search(r'\[.*?\]', response_text, re.DOTALL)
        
        leads = []
        if json_match:
            try:
                leads_data = json.loads(json_match.group())
                for lead_data in leads_data[:num_leads]:
                    try:
                        leads.append(Lead(**lead_data))
                    except:
                        continue
            except Exception as e:
                print(f"   Error parsing leads: {e}")
        
        return leads
    
    def _generate_insights(self, leads: List[Lead], query: str, 
                          scraped_content: List[Dict]) -> List[str]:
        """Generate strategic insights from research"""
        
        lead_summary = {
            'total_leads': len(leads),
            'industries': list(set(l.industry for l in leads if l.industry)),
            'locations': list(set(l.location for l in leads if l.location)),
            'sample_companies': [l.company_name for l in leads[:5]]
        }
        
        prompt = f"""Based on research for "{query}", provide 5-7 strategic insights.

Lead Summary:
{lead_summary}

Provide insights that would be valuable for sales, marketing, or business development.
Consider:
- Market trends
- Geographic distribution
- Industry patterns
- Technology adoption
- Opportunity areas

Return as JSON array: ["insight 1", "insight 2", ...]"""

        message = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        import re
        import json
        
        response_text = message.content[0].text
        json_match = re.search(r'\[.*?\]', response_text, re.DOTALL)
        
        if json_match:
            try:
                return json.loads(json_match.group())
            except:
                pass
        
        return [
            f"Identified {len(leads)} qualified leads matching criteria",
            f"Primary industries: {', '.join(lead_summary['industries'][:3])}",
            f"Geographic spread across {len(lead_summary['locations'])} locations"
        ]
    
    def generate_report(self, results: ResearchResult, format: str = 'html') -> str:
        """Generate report in specified format"""
        from report_generator import ReportGenerator
        
        generator = ReportGenerator()
        return generator.generate_report(results, format=format)

# Example usage
def main():
    """Example usage of the complete system"""
    
    # Initialize agent
    agent = ManusStyleAgent()
    
    # Example queries
    queries = [
        "B2B SaaS companies in healthcare with 50-200 employees",
        "AI startups in fintech",
        "E-commerce platforms using Shopify in USA"
    ]
    
    # Run research
    query = queries[0]  # Use first query as example
    
    results = agent.research(
        query=query,
        num_leads=15,
        depth="wide"
    )
    
    # Display results
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}")
    print(f"Leads Found: {len(results.leads)}")
    print(f"\nSample Leads:")
    for i, lead in enumerate(results.leads[:5], 1):
        print(f"  {i}. {lead.company_name}")
        print(f"     Industry: {lead.industry or 'N/A'}")
        print(f"     Location: {lead.location or 'N/A'}")
        print()
    
    print("Key Insights:")
    for i, insight in enumerate(results.insights, 1):
        print(f"  {i}. {insight}")
    
    # Generate reports
    print(f"\n{'='*60}")
    print("GENERATING REPORTS")
    print(f"{'='*60}")
    
    formats = ['html', 'json']
    for fmt in formats:
        try:
            filepath = agent.generate_report(results, format=fmt)
            print(f"✓ {fmt.upper()} report: {filepath}")
        except Exception as e:
            print(f"✗ {fmt.upper()} failed: {e}")

if __name__ == "__main__":
    main()
