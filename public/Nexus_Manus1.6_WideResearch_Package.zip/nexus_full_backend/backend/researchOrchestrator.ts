import { v4 as uuidv4 } from 'uuid';

/**
 * Evidence represents a single citation extracted from an external source.
 * Each object should contain a short quote, the source title and the URL.
 */
export interface Evidence {
  quote: string;
  source: string;
  url: string;
}

/**
 * Report defines the structure of a research report returned by runResearch.
 * All sections are required.  Arrays may contain multiple paragraphs or bullets.
 */
export interface Report {
  title: string;
  executiveSummary: string[];
  companyOverview: string;
  governance: string[];
  ownership: string[];
  marketPosition: string[];
  strategicAnalysis: string[];
  financialSignals: string[];
  risks: string[];
  outlook: string[];
  assumptions: string[];
  actionableInsights: string[];
  sources: Evidence[] | 'No external sources used';
}

/**
 * planResearch generates a high‑level plan from the user’s query.  In a real
 * system this would use an LLM to break down the task.  Here we simply
 * capitalise the query and list the expected sections.
 */
export async function planResearch(query: string, mode: 'fast' | 'deep') {
  const title = query.charAt(0).toUpperCase() + query.slice(1);
  return {
    title,
    sections: [
      'Executive Summary',
      'Company Overview',
      'Governance & Leadership',
      'Ownership & Shareholding Structure',
      'Market Position',
      'Strategic Analysis',
      'Financial & Operational Signals',
      'Risks & Constraints',
      'Forward‑Looking Outlook',
      'Assumptions & Methodology',
      'Actionable Insights',
      'Sources'
    ]
  };
}

/**
 * fetchEvidence is a placeholder for real‑time evidence collection.  When
 * connectors such as Firecrawl or Perplexity are available, implement API
 * calls here.  If useWeb is false or connectors fail, return an empty array.
 */
export async function fetchEvidence(
  query: string,
  mode: 'fast' | 'deep',
  useWeb: boolean
): Promise<Evidence[]> {
  if (!useWeb) {
    return [];
  }
  // TODO: implement real‑time API calls to Firecrawl/Perplexity and return citations.
  return [];
}

/**
 * generateReport synthesises a complete report from the plan, evidence and
 * original query.  Replace the body of this function with calls to your LLM
 * provider and parse its output into the Report interface.
 */
export async function generateReport(
  plan: any,
  evidence: Evidence[],
  query: string
): Promise<Report> {
  const usedWeb = evidence.length > 0;
  const sourcesField: Evidence[] | 'No external sources used' = usedWeb ? evidence : 'No external sources used';
  return {
    title: plan.title,
    executiveSummary: [
      `This is a high‑level summary for ${query}. Replace with actual AI synthesis.`
    ],
    companyOverview: `Overview of ${query}. Replace with AI‑generated content.`,
    governance: [`List board members here for ${query}.`],
    ownership: [`Describe shareholding structure here for ${query}.`],
    marketPosition: [`Describe market position for ${query}.`],
    strategicAnalysis: [`Add strategic analysis here.`],
    financialSignals: [`Provide financial signals here.`],
    risks: [`Outline risks and constraints here.`],
    outlook: [`Provide outlook here.`],
    assumptions: [`List any assumptions made.`],
    actionableInsights: [`Provide actionable insights here.`],
    sources: sourcesField
  };
}

/**
 * runResearch orchestrates the entire research process: planning, evidence
 * collection, synthesis and assembly of the response object.
 */
export async function runResearch({
  query,
  mode,
  useWeb,
  taskId
}: {
  query: string;
  mode: 'fast' | 'deep';
  useWeb: boolean;
  taskId?: string;
}) {
  if (!query) {
    throw new Error('Query is required');
  }
  const plan = await planResearch(query, mode);
  const evidence = await fetchEvidence(query, mode, useWeb);
  const report = await generateReport(plan, evidence, query);
  const reportId = uuidv4();
  return {
    reportId,
    status: 'complete',
    report,
    usedWeb: evidence.length > 0,
    warnings: evidence.length === 0 && useWeb ? ['External sources unavailable'] : []
  };
}