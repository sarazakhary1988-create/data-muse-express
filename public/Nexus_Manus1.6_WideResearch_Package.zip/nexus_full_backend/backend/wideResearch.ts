import { runResearch } from './researchOrchestrator';

/**
 * runWideResearch executes multiple research queries in parallel.  It is the
 * equivalent of Manus’s Wide Research feature, which launches independent
 * sub‑agents for each item【611982089219475†L155-L197】.  Each sub‑query runs
 * independently via runResearch, and the results are aggregated.
 *
 * @param items An array of strings representing the individual entities or
 *     topics to research.
 * @param mode Either 'fast' or 'deep' to control the level of analysis.
 * @param useWeb Ignored in this implementation because we avoid web
 *     dependencies; passed through for compatibility.
 */
export async function runWideResearch({
  items,
  mode,
  useWeb
}: {
  items: string[];
  mode: 'fast' | 'deep';
  useWeb: boolean;
}) {
  if (!items || items.length === 0) {
    throw new Error('Items array is required');
  }
  // Execute all sub‑research tasks in parallel.  Each call returns a full
  // research report for the corresponding item.  This mirrors Manus’s
  // sub‑agent delegation and parallel execution architecture【611982089219475†L155-L197】.
  const subResults = await Promise.all(
    items.map(item => runResearch({ query: item, mode, useWeb }))
  );
  // Produce a simple aggregated summary by concatenating each executive summary.
  // In a production system, use an LLM to synthesise a cohesive summary.
  const aggregatedSummary = subResults
    .map((result, index) => {
      const name = items[index];
      const summary = result.report.executiveSummary.join(' ');
      return `### ${name}\n\n${summary}`;
    })
    .join('\n\n');
  return {
    summary: aggregatedSummary,
    reports: subResults
  };
}