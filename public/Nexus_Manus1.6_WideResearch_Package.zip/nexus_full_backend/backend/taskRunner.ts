import { runResearch } from './researchOrchestrator';
import { v4 as uuidv4 } from 'uuid';
import cron from 'node-cron';
import { db } from './database';

export interface Task {
  id: string;
  title: string;
  query: string;
  mode: 'fast' | 'deep';
  useWeb: boolean;
  schedule?: string;
  isEnabled: boolean;
  lastRunAt?: Date;
}

// In‑memory list of tasks for demonstration purposes.  Replace with DB.
export const tasks: Task[] = [];

/**
 * createTask registers a new task and schedules it if a schedule is provided.
 */
export function createTask({
  title,
  query,
  mode,
  useWeb,
  schedule
}: Omit<Task, 'id' | 'isEnabled' | 'lastRunAt'>) {
  const id = uuidv4();
  const task: Task = { id, title, query, mode, useWeb, schedule, isEnabled: true };
  tasks.push(task);
  if (schedule) {
    cron.schedule(schedule, async () => {
      await runTask(task.id);
    });
  }
  return task;
}

/**
 * runTask executes a scheduled task immediately and stores the report.
 */
export async function runTask(taskId: string) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) {
    throw new Error('Task not found');
  }
  const result = await runResearch({ query: task.query, mode: task.mode, useWeb: task.useWeb, taskId: task.id });
  db.reports.push({
    id: result.reportId,
    taskId: task.id,
    report: result.report,
    createdAt: new Date()
  });
  task.lastRunAt = new Date();
  return result;
}