/**
 * database.ts provides a simple in‑memory store for tasks and reports.  In a
 * production system you should replace this with a real database and use an
 * ORM such as Prisma or Sequelize.  See `db/schema.sql` for the intended
 * relational structure.
 */

export interface ReportRecord {
  id: string;
  taskId?: string;
  report: any;
  createdAt: Date;
}

export const db = {
  tasks: [] as any[],
  reports: [] as ReportRecord[]
};