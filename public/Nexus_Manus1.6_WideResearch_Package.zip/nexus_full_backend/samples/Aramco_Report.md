# Saudi Aramco: Board and Shareholding Analysis in Saudi Arabia

## Executive Summary

- Aramco is the world’s largest integrated oil and gas company and a cornerstone of the Saudi economy.
- The Government of Saudi Arabia holds approximately 90% of Aramco’s shares; the remaining free float is listed on the Tadawul stock exchange.
- The board comprises a mix of government ministers, independent directors and company executives; **Yasir Al‑Rumayyan** serves as chairman.
- Aramco maintains a cost leadership advantage and vast reserves, positioning it well despite energy transition pressures.
- Dividend policy is geared toward predictable payouts, stabilising government revenue.

## Company Overview

Saudi Aramco, officially the **Saudi Arabian Oil Company**, is headquartered in Dhahran.  It plays a pivotal role in Saudi Arabia’s Vision 2030 by generating revenues that fund diversification initiatives and by driving localisation programmes such as **iktva**.

## Governance & Leadership

- **Board of Directors**: *Yasir Al‑Rumayyan* (Chairman), *Amin Nasser* (President & CEO), *Mohammed Al‑Jadaan* (Minister of Finance), *Khalid Al‑Dabbagh* and other independent directors.
- **Executive Management**: *Amin Nasser* leads the executive team; *Ziad Al‑Murshed* serves as CFO.

## Ownership & Shareholding Structure

- **Government Ownership**: Approximately **90%** of shares are held by the Kingdom of Saudi Arabia via the **Public Investment Fund**.
- **Public Float**: Around **10%** of shares are publicly traded on the Tadawul exchange.
- **Strategic Implications**: The high level of state ownership aligns Aramco’s strategy with national economic objectives and provides long‑term stability.

## Market Position

- Aramco is the dominant producer in the Saudi market and a major contributor to GDP.
- The company’s upstream and downstream operations ensure control across the value chain.
- National employment and localisation initiatives create societal benefits.

## Strategic Analysis

Aramco’s competitive advantage stems from its unparalleled proven reserves, low production costs and integration across value chains.  The company faces long‑term challenges from decarbonisation but is investing in gas development and low‑carbon technologies.

## Financial & Operational Signals

Revenue and net income have remained robust; the company declared dividends of over **SAR 360 billion** in 2025.  Capital expenditure is rising as the company expands gas projects.

## Risks & Constraints

- Volatility in global oil prices and demand.
- Geopolitical tensions in the Middle East.
- Long‑term energy transition trends could reduce hydrocarbon demand.
- Regulatory or environmental constraints.

## Forward‑Looking Outlook

In the short term, Aramco is expected to sustain high production levels and dividends.  In the medium term, diversification into gas and chemicals along with investments in renewables and carbon capture may mitigate transition risks.

## Assumptions & Methodology

This report synthesises publicly available information up to **2025** and uses reasonable assumptions for future outlooks.  No real‑time data was retrieved for this sample.

## Actionable Insights

- Investors should assess Aramco’s transition investments and dividend sustainability.
- Policymakers can leverage Aramco’s cash flows to accelerate economic diversification.
- Partners should explore joint ventures in low‑carbon technologies.

## Sources

No external sources used (AI synthesis).