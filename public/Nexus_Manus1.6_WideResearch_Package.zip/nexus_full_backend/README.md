# Nexus Full Backend Package

This package provides a complete set of documentation, code scaffolding, and templates to build a fully functional research and task management backend for the **Nexus** project.  It emphasises an AI‑first reasoning approach with optional real‑time data enrichment via connectors, in line with the reasoning engine concepts described by Clarifai’s overview of AI reasoning engines【54565398735920†L162-L176】【54565398735920†L205-L213】.

## Directory Structure

- `backend/` – contains TypeScript modules that implement the core research orchestrator, evidence enrichment hooks, task scheduler and in‑memory persistence.  Replace these with your preferred frameworks and database integration.
  - `researchOrchestrator.ts` – AI‑first single‑item research engine.
  - `wideResearch.ts` – Implements Manus‑style wide research by breaking a list of items into parallel sub‑tasks【611982089219475†L155-L197】.
  - `taskRunner.ts` – Schedules recurring research tasks.
  - `database.ts` – In‑memory persistence layer.
- `db/` – SQL schema for tasks and reports tables.  Use this to bootstrap a real database.
- `docs/` – high‑level architecture description, API specification, implementation guide, quality guidelines, report template and a dedicated wide‑research guide.
- `samples/` – a sample report illustrating the level of specificity and structure expected from your AI system.
- `tests/` – acceptance tests that describe scenarios the backend must handle.

The provided code and documentation are meant to serve as a starting point.  They must be adapted to your stack (e.g., Express.js, NestJS, FastAPI) and integrated with actual AI providers and data sources.  See `docs/ImplementationGuide.md` for guidance on deploying and extending the system.