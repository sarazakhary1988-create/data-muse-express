# Wide Research

Wide Research is a powerful feature inspired by Manus 1.6 Max that allows the system to handle large sets of similar research items without degrading quality.  When you ask the engine to research dozens or hundreds of entities, a single large language model can falter: context windows fill up, causing the model to fabricate or summarise excessively【611982089219475†L46-L96】.  Wide Research overcomes this by decomposing the task and running each item in a separate sub‑agent before synthesising the results【611982089219475†L155-L197】.

## Why Not Bigger Context Windows?

Expanding the context window alone cannot solve the fabrication problem.  Studies show that retrieval accuracy degrades with distance from the current position, and processing very long contexts becomes prohibitively expensive【611982089219475†L106-L122】.  The fundamental issue is cognitive load: a single model struggles to maintain consistent quality across many independent research tasks【611982089219475†L124-L127】.

## Architecture

Wide Research uses a parallel architecture reminiscent of the Manus design:

1. **Intelligent Decomposition** – The main controller analyses the request and breaks it into independent, parallelisable sub‑tasks【611982089219475†L155-L163】.
2. **Sub‑Agent Delegation** – For each sub‑task, the system launches a dedicated sub‑agent with its own context and tool access【611982089219475†L167-L176】.
3. **Parallel Execution** – All sub‑agents run simultaneously, each focusing exclusively on its assigned item【611982089219475†L179-L183】.
4. **Centralised Coordination** – The main controller collects results from all sub‑agents, ensuring independence and avoiding context pollution【611982089219475†L185-L190】.
5. **Synthesis and Integration** – Once all sub‑agents complete, the controller synthesises their outputs into a cohesive report【611982089219475†L192-L197】.

### Manus 1.6 Max Improvements

The Manus 1.6 Max architecture upgrades Wide Research by ensuring every sub‑agent runs at the highest level for deeper, more accurate insights【421897143498253†L45-L59】.  This release also improves task success rates and user satisfaction【421897143498253†L45-L54】, making Wide Research smarter and more reliable.

## Our Implementation

The file `backend/wideResearch.ts` provides a simplified implementation of Wide Research:

- **Input:** An array of items to research, the analysis mode (`fast` or `deep`), and a `useWeb` flag (ignored in this engine, as web dependencies are removed).
- **Execution:** The engine runs `runResearch` on each item in parallel using `Promise.all`.  Each call returns a complete report for the item.
- **Aggregation:** After all sub‑tasks finish, the engine concatenates their executive summaries into an aggregated summary and returns both the summary and the array of individual reports.

In a production system, you would replace the simple concatenation with an AI synthesis step to produce a cohesive narrative across all items.

## When to Use

Use Wide Research for tasks involving many similar items that require consistent analysis—such as competitor matrices, literature reviews, product comparisons or bulk data processing【611982089219475†L246-L248】.  Do not use it for deeply sequential tasks where each step depends on the previous one【611982089219475†L250-L252】.

## API Endpoint

See `docs/API_Spec.md` for details on the `POST /api/wide-research/run` endpoint.