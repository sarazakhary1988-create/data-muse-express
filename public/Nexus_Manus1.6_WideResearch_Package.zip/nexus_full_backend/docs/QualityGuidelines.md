# Quality Guidelines

To ensure that the **Nexus** backend produces high‑quality, actionable research, adhere to the following guidelines:

1. **Adhere to the report template** – The report must include all sections defined in `docs/ReportTemplate.md`.  If any section would be empty, fill it with assumptions or explain why information is unavailable.

2. **AI‑first synthesis** – Always run the AI Planner and Synthesiser.  Do not depend on web scraping or search to produce core content.  This reflects the distinction between reasoning engines and search engines【54565398735920†L162-L176】【54565398735920†L205-L213】.

3. **Transparency** – Include an **Assumptions & Methodology** section listing any assumptions made and limitations encountered.  Return a `warnings` field in the API response whenever external data could not be retrieved.

4. **Accuracy and Specificity** – Ensure that the report references the user’s query explicitly and includes concrete details (e.g., names of board members, shareholding percentages).  Avoid generic or boilerplate language.

5. **Citability** – When real‑time data is used, attach citations with `quote`, `source` and `url`.  Do not expose raw scraping logs or validation metrics to the end user.

6. **Non‑blocking Web Failure** – Real‑time data enrichers must never block the pipeline.  The AI planner should still produce a complete report even if connectors fail.

7. **Testing** – Use the acceptance tests in `tests/AcceptanceTests.md` to validate functionality.  Add additional tests to cover edge cases and error conditions.

## Wide Research Quality Considerations

When running Wide Research tasks:

1. **Per‑Item Consistency** – Ensure that each sub‑report meets the same quality standards as a single‑item report.  The 50th item should be as detailed and accurate as the first【611982089219475†L203-L207】.
2. **Parallel Isolation** – Each sub‑task should run independently with its own context to avoid cross‑contamination of information【611982089219475†L167-L177】.
3. **Aggregation Clarity** – When synthesising results, clearly separate each item’s findings and provide an overall summary.  Do not merge unrelated facts.
4. **Scalability** – The system should handle tens or hundreds of items by scaling the number of sub‑tasks linearly【611982089219475†L210-L214】.

Following these guidelines ensures that research outputs are reliable, decision‑ready and aligned with the principles of reasoning engines, which emphasise structured knowledge and logical conclusions【54565398735920†L162-L176】.