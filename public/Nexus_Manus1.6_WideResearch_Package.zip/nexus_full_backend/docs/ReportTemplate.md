# Report Template

This template defines the structure that all research reports must follow.  The AI Planner should generate content for each section.  If information is unavailable, provide assumptions or context rather than leaving sections blank.

## Title

A concise title derived from the user’s query (e.g., “Saudi Aramco: Board and Shareholding Analysis in Saudi Arabia”).

## Executive Summary

Provide 3–6 bullet points summarising the most important insights and their implications.  Focus on key findings that decision‑makers need to know.

## Company Overview

- Legal name, incorporation and headquarters.
- Role within the local economy and industry.
- Key recent milestones.

## Governance & Leadership

List board members (chair, vice chair, independent directors and government appointees) and executive management (CEO, CFO, etc.).  Provide names and roles.

## Ownership & Shareholding Structure

Detail government ownership percentages, public float, major institutional shareholders and stock exchange listings.  Describe strategic implications.

## Market Position

Describe the entity’s position within its local market (e.g., domestic production capacity, contribution to GDP, employment).  Highlight strengths and weaknesses.

## Strategic Analysis

Discuss competitive advantages, cost structures, reserves, energy transition positioning or other domain‑specific factors.  Use evidence when available.

## Financial & Operational Signals

Provide trends in revenue, profit, capital expenditure and dividends.  Identify key sensitivities (e.g., oil price, geopolitical factors).  Use real data where available; otherwise, state assumptions.

## Risks & Constraints

Identify major risks (e.g., market volatility, regulatory changes) and constraints.  Describe potential mitigation strategies.

## Forward‑Looking Outlook

Present short‑term (1–2 year) and medium‑term (3–5 year) outlooks, highlighting opportunities and challenges.  Link these to strategic objectives.

## Assumptions & Methodology

List assumptions made due to missing data.  Explain the methodology used and note any data limitations.  This section enhances transparency and trust.

## Actionable Insights

Offer recommendations for decision‑makers (e.g., investors, policymakers, partners).  Prioritise actions by importance or urgency.

## Sources

List external sources used.  If no external sources were available or `useWeb` was `false`, state “No external sources used.”  Do not include raw scraping logs or diagnostic information.