# API Specification

This document defines the REST endpoints exposed by the **Nexus** backend.  All endpoints should return JSON responses and use appropriate HTTP status codes.

## `POST /api/research/run`

Runs a research task immediately.

### Request Body

- `query` (`string`, required) – the user’s research question.
- `mode` (`"fast" | "deep"`, required) – controls the depth of analysis.
- `useWeb` (`boolean`, required) – whether to attempt real‑time evidence enrichment.
- `taskId` (`string`, optional) – if invoked by a scheduled task, include the task ID.

### Response Body

- `reportId` (`string`) – unique identifier for the generated report.
- `status` (`string`) – should always be `"complete"` when the report is ready.
- `report` (`object`) – structured report (see `docs/ReportTemplate.md` for fields).
- `usedWeb` (`boolean`) – whether external sources were used.
- `warnings` (`string[]`) – any issues encountered (e.g., `"External sources unavailable"`).

### Errors

Return HTTP 400 if required fields are missing.  Return HTTP 500 only on unhandled exceptions.

## `POST /api/tasks`

Creates a scheduled research task.

### Request Body

- `title` (`string`, required) – short name for the task.
- `query` (`string`, required) – research question to run on schedule.
- `mode` (`"fast" | "deep"`, required).
- `useWeb` (`boolean`, required).
- `schedule` (`string`, optional) – iCal `RRULE` or cron expression describing when to run.

### Response Body

- `taskId` (`string`) – unique identifier for the task.

## `GET /api/tasks`

Returns a list of all tasks and their statuses.

## `POST /api/tasks/:id/run`

Runs a scheduled task immediately.

## `GET /api/reports?taskId=<id>`

Returns all reports generated for the given task ID.

## `GET /api/reports/:id`

Returns the full report for the given report ID.

### Error Handling

Endpoints must validate required fields and return clear error messages.  Use HTTP 400 for user errors (missing parameters) and 404 for not found resources.  The API should never return scraped logs or intermediate data to the client.

## `POST /api/wide-research/run`

Runs a Wide Research task.  This endpoint supports parallel execution of multiple research items and returns an aggregated summary and individual reports.

### Request Body

- `items` (`string[]`, required) – an array of items to research (e.g., company names, product SKUs).
- `mode` (`"fast" | "deep"`, required) – controls the depth of analysis.
- `useWeb` (`boolean`, required) – preserved for compatibility; web enrichers are disabled in this implementation.

### Response Body

- `summary` (`string`) – aggregated summary of all items, built from the executive summaries of each sub‑report.
- `reports` (`object[]`) – an array of results returned from `runResearch`; each object contains the same fields as `/api/research/run` (`reportId`, `status`, `report`, `usedWeb`, `warnings`).

### Errors

Return HTTP 400 if `items` is missing or empty.  Return HTTP 500 only on unhandled exceptions.