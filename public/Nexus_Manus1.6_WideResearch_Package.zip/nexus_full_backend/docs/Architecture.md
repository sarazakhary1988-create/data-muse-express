# Architecture

## Rationale

Traditional data engines rely heavily on web scraping and search pipelines.  They attempt to scrape websites first and only use AI as a fallback.  This approach fails when scraping is blocked or API keys are missing, leading to empty or generic outputs.  Instead, the **Nexus** backend follows an AI‑first architecture inspired by reasoning engines.  A reasoning engine is software that applies logical rules and structured knowledge to derive conclusions and plan actions【54565398735920†L162-L176】.  It differs from search engines, which only locate information, and inference engines, which apply learned patterns without logical reasoning【54565398735920†L205-L213】.

## Components

1. **AI Planner and Synthesiser** – Accepts a user query and produces a structured research plan, using templates (see `docs/ReportTemplate.md`) and domain rules.  This stage always runs, ensuring the system generates a complete report even without external data.

2. **Evidence Enricher (Optional)** – If real‑time sources are available (e.g., Firecrawl, Perplexity), the planner generates search queries to gather external evidence.  The system integrates citations into the report.  This layer is optional and should never block report generation.

3. **Report Generator** – Combines the plan, user context and any gathered evidence to produce a structured report with sections: Title, Executive Summary, Company Overview, Governance & Leadership, Ownership & Shareholding Structure, Market Position, Strategic Analysis, Financial & Operational Signals, Risks & Constraints, Forward‑Looking Outlook, Assumptions & Methodology, Actionable Insights, and Sources.

4. **Task Runner** – Handles scheduled or on‑demand tasks.  Each task uses the same AI‑first pipeline to produce results, stores them in the database, and provides downloadable outputs.

5. **Database Layer** – Stores tasks and reports in persistent storage.  A SQL schema is provided in `db/schema.sql`.

6. **API Layer** – Exposes endpoints for research runs and task management (see `docs/API_Spec.md`).

7. **Wide Research Engine** – Implements parallelised research over multiple items.  It decomposes large research tasks into independent sub‑queries, launches each as an isolated sub‑agent and synthesises results【611982089219475†L155-L197】.  See `docs/WideResearch.md` for details.

## Orchestration Flow

1. The client sends a `POST` request to `/api/research/run` with `query`, `mode`, and `useWeb` flags.
2. The AI Planner builds a plan and determines whether to call the Evidence Enricher.
3. The Evidence Enricher fetches data if `useWeb` is `true` and connectors are configured.
4. The Report Generator synthesises the final report, ensuring all required sections are present.
5. The report is persisted in the database and returned to the client.
6. For tasks, the Task Runner uses a scheduler to call the research API at specified intervals and stores results.

## Real‑Time Connectors

Real‑time connectors (e.g., Firecrawl for web scraping, Perplexity for search) can be integrated via the Evidence Enricher.  See `docs/ImplementationGuide.md` for instructions on configuring connectors and adding environment variables.  The system must always fall back to AI‑only synthesis if external data is unavailable; do not throw errors or return empty content.  This design ensures reliability and aligns with the reasoning‑engine philosophy【54565398735920†L162-L176】.