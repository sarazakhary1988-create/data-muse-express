# Implementation Guide

This guide describes how to deploy and extend the **Nexus** backend.  It assumes familiarity with Node.js/TypeScript but can be adapted to any stack.

## 1. Environment Setup

1. Clone this repository and install dependencies:
   ```bash
   npm install
   ```
2. Create a `.env` file at the project root and define the following variables:
   - `AI_PROVIDER_API_KEY` – your LLM API key (e.g., OpenAI, Gemini).
   - `USE_FIRECRAWL` (`true` or `false`) – whether to enable the Firecrawl connector.
   - `FIRECRAWL_API_KEY` – API key for Firecrawl (required if `USE_FIRECRAWL` is `true`).
   - `USE_PERPLEXITY` (`true` or `false`) – whether to enable the Perplexity connector.
   - `PERPLEXITY_API_KEY` – API key for Perplexity (required if `USE_PERPLEXITY` is `true`).

3. Run database migrations using the schema in `db/schema.sql`.  The provided code uses an in‑memory store; replace it with your chosen ORM (e.g., Prisma, Sequelize) connected to a relational database (PostgreSQL, MySQL or SQLite).

## 2. Integrating an AI Provider

The module `backend/researchOrchestrator.ts` demonstrates how to orchestrate research using placeholder functions.  To integrate a real LLM:

1. Replace `generateReport` in `researchOrchestrator.ts` with a call to your provider’s API.  Construct a prompt that includes the user’s query, the plan sections from `planResearch`, any evidence from `fetchEvidence`, and explicit instructions to follow the report template (see `docs/ReportTemplate.md`).
2. Extract the structured sections from the LLM output into the `Report` interface.  You can use JSON mode (if supported) or parse the text manually.
3. Add safeguards to re‑invoke the model if any required sections are missing.

## 3. Implementing Evidence Enrichment

The function `fetchEvidence` in `researchOrchestrator.ts` returns an empty array by default.  Implement it as follows:

1. If `useWeb` is `false`, immediately return an empty array.
2. If `useWeb` is `true`, call your configured connectors: for example, use Firecrawl to scrape official websites or Perplexity to perform AI‑grounded web searches.  Each connector should return a list of citations containing `quote`, `source` (e.g., article title) and `url` fields.
3. Handle any errors gracefully by returning an empty array and logging warnings.  Do not throw exceptions to the caller.

By abstracting connectors behind `fetchEvidence`, you ensure the system remains functional even when connectors are unavailable.  This aligns with the AI‑first philosophy: the reasoning engine always produces a report【54565398735920†L162-L176】.

## 4. Implementing Wide Research

The module `backend/wideResearch.ts` illustrates how to implement Manus‑style Wide Research without web dependencies.  To integrate this in your server:

1. Add a new route handler for `POST /api/wide-research/run` that accepts an `items` array, `mode` and `useWeb` flag.  Validate that `items` is a non‑empty array of strings.
2. Call `runWideResearch({ items, mode, useWeb })` from `wideResearch.ts`.  This function executes each item via `runResearch` in parallel and aggregates the results.
3. Return the aggregated summary and individual reports to the client.
4. For scheduled wide research tasks, iterate over the `items` list and store each sub‑report separately or in a combined record as appropriate.

You can extend the aggregation step by invoking your LLM provider to synthesise a cohesive narrative across all items.  For real Manus‑like behaviour, each sub‑task could run on its own worker or process to fully isolate contexts.

## 5. Task Scheduling

The provided `backend/taskRunner.ts` uses [`node-cron`](https://www.npmjs.com/package/node-cron) to schedule tasks.  Install it via `npm install node-cron`.  Each task created with a schedule will run automatically according to the cron expression.  You can replace cron scheduling with platform‑specific mechanisms (e.g., Supabase Edge functions, AWS EventBridge or Google Cloud Scheduler).

Each run of a scheduled task calls the same `runResearch` function used for immediate requests and stores the resulting report.  Persist the `lastRunAt` timestamp and report records in your database.

## 6. Frontend Integration

The frontend should call the endpoints defined in `docs/API_Spec.md`.  Provide controls for `mode`, `useWeb` and scheduling.  When rendering reports, follow the structure defined in `docs/ReportTemplate.md`.  Avoid displaying internal metadata or debug logs.

## 7. Extending the System

To support additional connectors or reasoning features:

1. Add new functions in `backend/researchOrchestrator.ts` or separate modules.  For example, integrate a knowledge graph or symbolic reasoning library.
2. Update `fetchEvidence` to merge results from multiple sources.  Use ranking to prioritise high‑quality evidence.
3. Add additional fields to the `Report` interface if you introduce new sections.

## 8. Testing

Use the acceptance tests in `tests/AcceptanceTests.md` to verify that your implementation behaves correctly.  Write automated unit tests for functions such as `runResearch` and `createTask` to ensure proper error handling and data persistence.