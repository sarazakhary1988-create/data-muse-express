-- Schema for Nexus backend.

-- Tasks table holds scheduled research tasks.
CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  query TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('fast','deep')),
  use_web BOOLEAN NOT NULL,
  schedule TEXT,
  is_enabled BOOLEAN NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_run_at TIMESTAMP
);

-- Reports table stores generated reports.  Each report may be associated with
-- a task or be ad‑hoc (task_id is nullable).
CREATE TABLE reports (
  id TEXT PRIMARY KEY,
  task_id TEXT REFERENCES tasks(id),
  report_json TEXT NOT NULL,
  used_web BOOLEAN NOT NULL,
  warnings_json TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);