# Acceptance Tests

Use the following scenarios to validate that the **Nexus** backend functions correctly.  Each test should be automated or manually executed after implementation.

## Test 1 – Immediate Research

**Input:**

- Request: `POST /api/research/run`
- Body: `{ "query": "Saudi Aramco board and shareholders in Saudi Arabia", "mode": "fast", "useWeb": false }`

**Expected:**

- The API responds with HTTP 200 and a JSON body containing:
  - `status` equal to `"complete"`.
  - A `report` object with all sections defined in `docs/ReportTemplate.md`.
  - The `usedWeb` field is `false`.
  - No sections are empty; if information is unavailable, the **Assumptions & Methodology** section explains the limitation.

## Test 2 – Research with Web Enrichment

**Prerequisite:** Real‑time connectors (Firecrawl or Perplexity) are configured.

**Input:** Same as Test 1 but with `"useWeb": true`.

**Expected:**

- The `usedWeb` field is `true` if evidence was successfully fetched; otherwise it is `false` with a warning explaining that external sources were unavailable.
- The `Sources` section lists citations obtained from connectors.
- All other fields are complete and specific.

## Test 3 – Task Scheduling

**Input:**

- Request: `POST /api/tasks`
- Body: `{ "title": "Weekly IPO Monitor", "query": "Monitor Saudi IPO news", "mode": "fast", "useWeb": true, "schedule": "RRULE:FREQ=WEEKLY;BYHOUR=10;BYMINUTE=0;BYSECOND=0" }`

**Expected:**

- The API responds with a `taskId`.
- The task is stored in the database with the correct schedule.
- When `POST /api/tasks/:id/run` is called, a report is generated and persisted.  The `lastRunAt` timestamp is updated.

## Test 4 – Failure Handling

**Simulate:** Disable connectors or provide invalid API keys, then run Test 2.

**Expected:** The system still returns a complete report with `usedWeb` set to `false` and includes a warning (e.g., `"External sources unavailable"`).  No unhandled exceptions are thrown.

## Test 5 – API Validation

**Input:** `POST /api/research/run` with an empty body or missing the `query` field.

**Expected:** The API returns HTTP 400 with a clear error message indicating that the `query` parameter is required.

## Test 6 – Wide Research

**Input:**

- Request: `POST /api/wide-research/run`
- Body: `{ "items": ["Saudi Aramco", "QatarEnergy", "ADNOC"], "mode": "fast", "useWeb": false }`

**Expected:**

- The API responds with HTTP 200 and a JSON body containing `summary` and `reports` fields.
- `reports` is an array of length equal to the number of items.  Each element includes `reportId`, `status` ("complete"), a `report` with all sections populated, `usedWeb` equal to `false` and empty `warnings`.
- The `summary` concatenates or synthesises the executive summaries of each sub‑report.

These additional tests verify that the Wide Research functionality works as expected, executing multiple independent research tasks in parallel and aggregating the results.

These tests ensure that the system meets functional requirements, handles errors gracefully and produces decision‑ready research.