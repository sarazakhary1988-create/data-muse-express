"""
Data Enrichment Hub
Integrates multiple data providers for comprehensive lead enrichment

Supported Providers:
- Clearbit: Company enrichment
- Hunter.io: Email finding & verification
- LinkedIn Sales Navigator API: Profile data
- Crunchbase: Funding & investors
- Apollo.io: Contact data
- ZoomInfo: Company intelligence
"""

import os
import asyncio
import aiohttp
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import json


@dataclass
class EnrichmentResult:
    """Result from data enrichment"""
    provider: str
    success: bool
    data: Dict[str, Any]
    confidence: float
    cost_credits: float = 0.0
    error: Optional[str] = None


class ClearbitEnrichment:
    """
    Clearbit Company & Person Enrichment
    https://clearbit.com/docs
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://company.clearbit.com/v2"
    
    async def enrich_company(self, domain: str) -> EnrichmentResult:
        """
        Enrich company by domain
        
        Returns:
            - Company name
            - Description
            - Industry/category
            - Employee count
            - Funding data
            - Technologies
            - Social profiles
        """
        url = f"{self.base_url}/companies/find"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params={'domain': domain},
                    headers={'Authorization': f'Bearer {self.api_key}'}
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Extract relevant fields
                        enriched = {
                            'company_name': data.get('name'),
                            'description': data.get('description'),
                            'industry': data.get('category', {}).get('industry'),
                            'sector': data.get('category', {}).get('sector'),
                            'employee_count': data.get('metrics', {}).get('employees'),
                            'employee_range': data.get('metrics', {}).get('employeesRange'),
                            'founded_year': data.get('foundedYear'),
                            'location': {
                                'city': data.get('geo', {}).get('city'),
                                'state': data.get('geo', {}).get('state'),
                                'country': data.get('geo', {}).get('country'),
                            },
                            'technologies': data.get('tech', []),
                            'linkedin': data.get('linkedin', {}).get('handle'),
                            'twitter': data.get('twitter', {}).get('handle'),
                            'facebook': data.get('facebook', {}).get('handle'),
                            'crunchbase': data.get('crunchbase', {}).get('handle'),
                            'revenue_estimate': data.get('metrics', {}).get('estimatedAnnualRevenue'),
                            'ticker': data.get('ticker'),
                            'phone': data.get('phone'),
                            'tags': data.get('tags', []),
                        }
                        
                        return EnrichmentResult(
                            provider='clearbit',
                            success=True,
                            data=enriched,
                            confidence=0.95,
                            cost_credits=1.0
                        )
                    else:
                        return EnrichmentResult(
                            provider='clearbit',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='clearbit',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )


class HunterEnrichment:
    """
    Hunter.io Email Finder & Verification
    https://hunter.io/api-documentation
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.hunter.io/v2"
    
    async def find_emails(self, domain: str, limit: int = 10) -> EnrichmentResult:
        """Find email addresses for a domain"""
        
        url = f"{self.base_url}/domain-search"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params={
                        'domain': domain,
                        'api_key': self.api_key,
                        'limit': limit
                    }
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        emails = []
                        for email_data in data.get('data', {}).get('emails', []):
                            emails.append({
                                'email': email_data.get('value'),
                                'type': email_data.get('type'),
                                'confidence': email_data.get('confidence'),
                                'first_name': email_data.get('first_name'),
                                'last_name': email_data.get('last_name'),
                                'position': email_data.get('position'),
                                'department': email_data.get('department'),
                                'seniority': email_data.get('seniority'),
                                'linkedin': email_data.get('linkedin'),
                                'twitter': email_data.get('twitter'),
                            })
                        
                        return EnrichmentResult(
                            provider='hunter',
                            success=True,
                            data={
                                'emails': emails,
                                'domain': domain,
                                'organization': data.get('data', {}).get('organization'),
                                'pattern': data.get('data', {}).get('pattern'),
                            },
                            confidence=0.85,
                            cost_credits=0.5
                        )
                    else:
                        return EnrichmentResult(
                            provider='hunter',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='hunter',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )
    
    async def verify_email(self, email: str) -> EnrichmentResult:
        """Verify if an email is valid and deliverable"""
        
        url = f"{self.base_url}/email-verifier"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params={
                        'email': email,
                        'api_key': self.api_key
                    }
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        result = data.get('data', {})
                        
                        return EnrichmentResult(
                            provider='hunter',
                            success=True,
                            data={
                                'email': result.get('email'),
                                'status': result.get('status'),  # valid, invalid, accept_all, unknown
                                'result': result.get('result'),  # deliverable, undeliverable, risky
                                'score': result.get('score'),  # 0-100
                                'regexp': result.get('regexp'),
                                'gibberish': result.get('gibberish'),
                                'disposable': result.get('disposable'),
                                'webmail': result.get('webmail'),
                                'mx_records': result.get('mx_records'),
                                'smtp_server': result.get('smtp_server'),
                                'smtp_check': result.get('smtp_check'),
                            },
                            confidence=result.get('score', 0) / 100,
                            cost_credits=0.1
                        )
                    else:
                        return EnrichmentResult(
                            provider='hunter',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='hunter',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )


class CrunchbaseEnrichment:
    """
    Crunchbase Funding & Company Data
    https://data.crunchbase.com/docs
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.crunchbase.com/api/v4"
    
    async def get_company_data(self, domain: str) -> EnrichmentResult:
        """Get funding and company data from Crunchbase"""
        
        # Note: Crunchbase API requires organization permalink, not domain
        # You'd need to search first, then get details
        
        url = f"{self.base_url}/entities/organizations/{domain}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers={'X-cb-user-key': self.api_key}
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        props = data.get('properties', {})
                        
                        # Extract funding rounds
                        funding_rounds = []
                        for round_data in props.get('funding_rounds', []):
                            funding_rounds.append({
                                'round_type': round_data.get('funding_type'),
                                'amount': round_data.get('money_raised', {}).get('value'),
                                'currency': round_data.get('money_raised', {}).get('currency'),
                                'announced_on': round_data.get('announced_on'),
                                'investors': round_data.get('investors', [])
                            })
                        
                        enriched = {
                            'company_name': props.get('name'),
                            'description': props.get('short_description'),
                            'founded_on': props.get('founded_on'),
                            'num_employees_enum': props.get('num_employees_enum'),
                            'num_funding_rounds': props.get('num_funding_rounds'),
                            'total_funding': props.get('total_funding_usd'),
                            'last_funding_type': props.get('last_funding_type'),
                            'funding_rounds': funding_rounds,
                            'ipo_status': props.get('ipo_status'),
                            'categories': props.get('categories', []),
                            'website': props.get('website_url'),
                            'linkedin': props.get('linkedin_url'),
                            'twitter': props.get('twitter_url'),
                            'facebook': props.get('facebook_url'),
                        }
                        
                        return EnrichmentResult(
                            provider='crunchbase',
                            success=True,
                            data=enriched,
                            confidence=0.90,
                            cost_credits=2.0
                        )
                    else:
                        return EnrichmentResult(
                            provider='crunchbase',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='crunchbase',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )


class ApolloEnrichment:
    """
    Apollo.io Contact & Company Data
    https://apolloio.github.io/apollo-api-docs
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.apollo.io/v1"
    
    async def enrich_company(self, domain: str) -> EnrichmentResult:
        """Enrich company via Apollo"""
        
        url = f"{self.base_url}/organizations/enrich"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json={'domain': domain},
                    headers={'X-Api-Key': self.api_key}
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        org = data.get('organization', {})
                        
                        enriched = {
                            'company_name': org.get('name'),
                            'website': org.get('website_url'),
                            'industry': org.get('industry'),
                            'employee_count': org.get('estimated_num_employees'),
                            'revenue': org.get('annual_revenue'),
                            'founded_year': org.get('founded_year'),
                            'location': {
                                'city': org.get('city'),
                                'state': org.get('state'),
                                'country': org.get('country'),
                            },
                            'phone': org.get('phone'),
                            'linkedin': org.get('linkedin_url'),
                            'facebook': org.get('facebook_url'),
                            'twitter': org.get('twitter_url'),
                            'technologies': org.get('technologies', []),
                            'seo_description': org.get('seo_description'),
                        }
                        
                        return EnrichmentResult(
                            provider='apollo',
                            success=True,
                            data=enriched,
                            confidence=0.88,
                            cost_credits=1.0
                        )
                    else:
                        return EnrichmentResult(
                            provider='apollo',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='apollo',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )
    
    async def find_contacts(self, domain: str, titles: List[str] = None) -> EnrichmentResult:
        """Find contacts at a company"""
        
        url = f"{self.base_url}/mixed_people/search"
        
        payload = {
            'organization_domains': [domain],
            'page': 1,
            'per_page': 25
        }
        
        if titles:
            payload['person_titles'] = titles
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json=payload,
                    headers={'X-Api-Key': self.api_key}
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        contacts = []
                        for person in data.get('people', []):
                            contacts.append({
                                'name': person.get('name'),
                                'title': person.get('title'),
                                'email': person.get('email'),
                                'linkedin': person.get('linkedin_url'),
                                'phone': person.get('phone_numbers', []),
                                'department': person.get('departments', []),
                                'seniority': person.get('seniority'),
                            })
                        
                        return EnrichmentResult(
                            provider='apollo',
                            success=True,
                            data={'contacts': contacts},
                            confidence=0.85,
                            cost_credits=0.5
                        )
                    else:
                        return EnrichmentResult(
                            provider='apollo',
                            success=False,
                            data={},
                            confidence=0.0,
                            error=f"HTTP {response.status}"
                        )
        
        except Exception as e:
            return EnrichmentResult(
                provider='apollo',
                success=False,
                data={},
                confidence=0.0,
                error=str(e)
            )


class DataEnrichmentHub:
    """
    Central hub for all data enrichment
    Manages multiple providers and aggregates results
    """
    
    def __init__(self, config: Dict[str, str]):
        """
        Initialize with API keys
        
        Args:
            config: Dict with keys like:
                - clearbit_api_key
                - hunter_api_key
                - crunchbase_api_key
                - apollo_api_key
        """
        self.providers = {}
        
        if config.get('clearbit_api_key'):
            self.providers['clearbit'] = ClearbitEnrichment(config['clearbit_api_key'])
        
        if config.get('hunter_api_key'):
            self.providers['hunter'] = HunterEnrichment(config['hunter_api_key'])
        
        if config.get('crunchbase_api_key'):
            self.providers['crunchbase'] = CrunchbaseEnrichment(config['crunchbase_api_key'])
        
        if config.get('apollo_api_key'):
            self.providers['apollo'] = ApolloEnrichment(config['apollo_api_key'])
    
    async def enrich_company_full(self, domain: str) -> Dict[str, Any]:
        """
        Enrich company using ALL available providers
        Merges results intelligently
        """
        
        results = {}
        
        # Run all enrichments in parallel
        tasks = []
        
        if 'clearbit' in self.providers:
            tasks.append(('clearbit', self.providers['clearbit'].enrich_company(domain)))
        
        if 'apollo' in self.providers:
            tasks.append(('apollo', self.providers['apollo'].enrich_company(domain)))
        
        if 'crunchbase' in self.providers:
            tasks.append(('crunchbase', self.providers['crunchbase'].get_company_data(domain)))
        
        if 'hunter' in self.providers:
            tasks.append(('hunter', self.providers['hunter'].find_emails(domain)))
        
        # Execute all tasks
        for provider_name, task in tasks:
            try:
                result = await task
                results[provider_name] = result
            except Exception as e:
                print(f"Error with {provider_name}: {e}")
        
        # Merge results
        merged = self._merge_enrichment_results(results)
        
        return merged
    
    def _merge_enrichment_results(self, results: Dict[str, EnrichmentResult]) -> Dict[str, Any]:
        """Intelligently merge data from multiple providers"""
        
        merged = {
            'company_name': None,
            'description': None,
            'industry': None,
            'employee_count': None,
            'founded_year': None,
            'location': {},
            'emails': [],
            'phones': [],
            'technologies': [],
            'linkedin': None,
            'twitter': None,
            'funding_total': None,
            'funding_rounds': [],
            'revenue': None,
            'confidence_scores': {},
            'providers_used': [],
            'total_cost': 0.0
        }
        
        for provider, result in results.items():
            if not result.success:
                continue
            
            merged['providers_used'].append(provider)
            merged['confidence_scores'][provider] = result.confidence
            merged['total_cost'] += result.cost_credits
            
            data = result.data
            
            # Merge fields (prefer higher confidence providers)
            if data.get('company_name') and not merged['company_name']:
                merged['company_name'] = data['company_name']
            
            if data.get('description') and not merged['description']:
                merged['description'] = data['description']
            
            if data.get('industry') and not merged['industry']:
                merged['industry'] = data['industry']
            
            if data.get('employee_count') and not merged['employee_count']:
                merged['employee_count'] = data['employee_count']
            
            if data.get('founded_year') and not merged['founded_year']:
                merged['founded_year'] = data['founded_year']
            
            # Merge location
            if data.get('location'):
                merged['location'].update(data['location'])
            
            # Merge lists (deduplicate)
            if data.get('emails'):
                if isinstance(data['emails'], list):
                    for email_data in data['emails']:
                        if isinstance(email_data, dict):
                            merged['emails'].append(email_data)
                        else:
                            merged['emails'].append({'email': email_data})
            
            if data.get('technologies'):
                merged['technologies'].extend(data['technologies'])
            
            if data.get('linkedin') and not merged['linkedin']:
                merged['linkedin'] = data['linkedin']
            
            if data.get('twitter') and not merged['twitter']:
                merged['twitter'] = data['twitter']
            
            if data.get('total_funding') and not merged['funding_total']:
                merged['funding_total'] = data['total_funding']
            
            if data.get('funding_rounds'):
                merged['funding_rounds'].extend(data['funding_rounds'])
        
        # Deduplicate lists
        merged['technologies'] = list(set(merged['technologies']))
        
        # Deduplicate emails
        seen_emails = set()
        unique_emails = []
        for email_data in merged['emails']:
            email = email_data.get('email') if isinstance(email_data, dict) else email_data
            if email and email not in seen_emails:
                seen_emails.add(email)
                unique_emails.append(email_data)
        merged['emails'] = unique_emails
        
        # Calculate overall confidence
        if merged['confidence_scores']:
            merged['overall_confidence'] = sum(merged['confidence_scores'].values()) / len(merged['confidence_scores'])
        else:
            merged['overall_confidence'] = 0.0
        
        return merged
    
    async def verify_email_batch(self, emails: List[str]) -> List[Dict[str, Any]]:
        """Verify multiple emails"""
        
        if 'hunter' not in self.providers:
            return []
        
        results = []
        for email in emails:
            result = await self.providers['hunter'].verify_email(email)
            if result.success:
                results.append(result.data)
        
        return results


# Example usage
async def example_usage():
    """Example of using the enrichment hub"""
    
    config = {
        'clearbit_api_key': os.environ.get('CLEARBIT_API_KEY'),
        'hunter_api_key': os.environ.get('HUNTER_API_KEY'),
        'crunchbase_api_key': os.environ.get('CRUNCHBASE_API_KEY'),
        'apollo_api_key': os.environ.get('APOLLO_API_KEY'),
    }
    
    hub = DataEnrichmentHub(config)
    
    # Enrich a company
    result = await hub.enrich_company_full('stripe.com')
    
    print(json.dumps(result, indent=2))
    
    # Verify emails
    emails_to_verify = ['test@stripe.com', 'support@stripe.com']
    verified = await hub.verify_email_batch(emails_to_verify)
    
    for email_result in verified:
        print(f"{email_result['email']}: {email_result['status']} (score: {email_result['score']})")


if __name__ == "__main__":
    asyncio.run(example_usage())
