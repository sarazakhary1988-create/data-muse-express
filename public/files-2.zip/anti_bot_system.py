"""
Advanced Proxy Rotation & Anti-Bot System
Handles IP rotation, browser fingerprinting, and CAPTCHA solving
"""

import random
import asyncio
from typing import List, Optional, Dict
from dataclasses import dataclass
import time
from playwright.async_api import Browser, BrowserContext, Page


@dataclass
class ProxyConfig:
    """Proxy configuration"""
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    protocol: str = "http"  # http, https, socks5
    
    def to_url(self) -> str:
        """Convert to proxy URL"""
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"


class ProxyRotator:
    """
    Intelligent proxy rotation system
    - Tracks proxy health
    - Automatic failover
    - Rate limiting per proxy
    """
    
    def __init__(self, proxies: List[ProxyConfig]):
        self.proxies = proxies
        self.proxy_stats = {
            i: {
                'success_count': 0,
                'fail_count': 0,
                'last_used': 0,
                'avg_response_time': 0,
                'banned': False
            }
            for i in range(len(proxies))
        }
        self.current_index = 0
    
    def get_next_proxy(self) -> ProxyConfig:
        """Get next available proxy"""
        
        # Find healthy proxies
        healthy_proxies = [
            i for i, stats in self.proxy_stats.items()
            if not stats['banned'] and stats['fail_count'] < 5
        ]
        
        if not healthy_proxies:
            # Reset all proxies if none healthy
            for stats in self.proxy_stats.values():
                stats['banned'] = False
                stats['fail_count'] = 0
            healthy_proxies = list(range(len(self.proxies)))
        
        # Get least recently used proxy
        proxy_index = min(
            healthy_proxies,
            key=lambda i: self.proxy_stats[i]['last_used']
        )
        
        self.proxy_stats[proxy_index]['last_used'] = time.time()
        return self.proxies[proxy_index]
    
    def mark_success(self, proxy: ProxyConfig, response_time: float):
        """Mark proxy as successful"""
        proxy_index = self.proxies.index(proxy)
        stats = self.proxy_stats[proxy_index]
        
        stats['success_count'] += 1
        
        # Update average response time
        if stats['avg_response_time'] == 0:
            stats['avg_response_time'] = response_time
        else:
            stats['avg_response_time'] = (stats['avg_response_time'] + response_time) / 2
    
    def mark_failure(self, proxy: ProxyConfig):
        """Mark proxy as failed"""
        proxy_index = self.proxies.index(proxy)
        stats = self.proxy_stats[proxy_index]
        
        stats['fail_count'] += 1
        
        # Ban proxy if too many failures
        if stats['fail_count'] >= 5:
            stats['banned'] = True
            print(f"⚠️ Proxy {proxy.host}:{proxy.port} banned (too many failures)")
    
    def get_stats(self) -> Dict:
        """Get proxy statistics"""
        return {
            'total_proxies': len(self.proxies),
            'healthy_proxies': sum(1 for s in self.proxy_stats.values() if not s['banned']),
            'banned_proxies': sum(1 for s in self.proxy_stats.values() if s['banned']),
            'stats': self.proxy_stats
        }


class BrowserFingerprinting:
    """
    Randomize browser fingerprints to avoid detection
    """
    
    USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ]
    
    VIEWPORTS = [
        {'width': 1920, 'height': 1080},
        {'width': 1366, 'height': 768},
        {'width': 1536, 'height': 864},
        {'width': 1440, 'height': 900},
        {'width': 2560, 'height': 1440},
    ]
    
    TIMEZONES = [
        'America/New_York',
        'America/Chicago',
        'America/Los_Angeles',
        'America/Denver',
        'Europe/London',
        'Europe/Paris',
        'Asia/Tokyo',
    ]
    
    LOCALES = [
        'en-US',
        'en-GB',
        'fr-FR',
        'de-DE',
        'es-ES',
    ]
    
    @staticmethod
    def get_random_fingerprint() -> Dict:
        """Generate random browser fingerprint"""
        return {
            'user_agent': random.choice(BrowserFingerprinting.USER_AGENTS),
            'viewport': random.choice(BrowserFingerprinting.VIEWPORTS),
            'timezone': random.choice(BrowserFingerprinting.TIMEZONES),
            'locale': random.choice(BrowserFingerprinting.LOCALES),
            'device_scale_factor': random.choice([1, 1.5, 2]),
            'is_mobile': False,
            'has_touch': random.choice([True, False]),
        }


class HumanBehaviorSimulator:
    """
    Simulate human-like browsing behavior
    """
    
    @staticmethod
    async def random_mouse_movement(page: Page):
        """Simulate random mouse movements"""
        for _ in range(random.randint(2, 5)):
            x = random.randint(100, 800)
            y = random.randint(100, 600)
            await page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.1, 0.3))
    
    @staticmethod
    async def random_scroll(page: Page):
        """Simulate human-like scrolling"""
        # Scroll down in increments
        total_scroll = random.randint(500, 2000)
        scrolled = 0
        
        while scrolled < total_scroll:
            scroll_amount = random.randint(50, 200)
            await page.evaluate(f'window.scrollBy(0, {scroll_amount})')
            scrolled += scroll_amount
            await asyncio.sleep(random.uniform(0.2, 0.5))
        
        # Sometimes scroll back up
        if random.random() > 0.7:
            await page.evaluate(f'window.scrollBy(0, -{scrolled // 2})')
            await asyncio.sleep(random.uniform(0.3, 0.6))
    
    @staticmethod
    async def random_delay():
        """Random human-like delay"""
        await asyncio.sleep(random.uniform(1.0, 3.0))


class CaptchaSolver:
    """
    CAPTCHA solving integration
    Supports multiple CAPTCHA solving services
    """
    
    def __init__(self, service: str, api_key: str):
        """
        Initialize CAPTCHA solver
        
        Args:
            service: '2captcha', 'anticaptcha', 'deathbycaptcha'
            api_key: API key for the service
        """
        self.service = service
        self.api_key = api_key
        self.base_urls = {
            '2captcha': 'https://2captcha.com/in.php',
            'anticaptcha': 'https://api.anti-captcha.com',
            'deathbycaptcha': 'http://deathbycaptcha.com/api',
        }
    
    async def solve_recaptcha_v2(self, site_key: str, page_url: str) -> Optional[str]:
        """
        Solve reCAPTCHA v2
        
        Args:
            site_key: The site key from the CAPTCHA
            page_url: URL where CAPTCHA appears
            
        Returns:
            CAPTCHA solution token
        """
        if self.service == '2captcha':
            return await self._solve_with_2captcha(site_key, page_url)
        elif self.service == 'anticaptcha':
            return await self._solve_with_anticaptcha(site_key, page_url)
        else:
            print(f"Service {self.service} not implemented")
            return None
    
    async def _solve_with_2captcha(self, site_key: str, page_url: str) -> Optional[str]:
        """Solve using 2captcha service"""
        import aiohttp
        
        # Submit CAPTCHA
        async with aiohttp.ClientSession() as session:
            submit_url = f"{self.base_urls['2captcha']}"
            params = {
                'key': self.api_key,
                'method': 'userrecaptcha',
                'googlekey': site_key,
                'pageurl': page_url,
                'json': 1
            }
            
            async with session.get(submit_url, params=params) as response:
                result = await response.json()
                
                if result.get('status') != 1:
                    print(f"2captcha error: {result}")
                    return None
                
                captcha_id = result.get('request')
            
            # Poll for result
            for _ in range(30):  # Try for 2 minutes
                await asyncio.sleep(5)
                
                result_url = f"https://2captcha.com/res.php"
                params = {
                    'key': self.api_key,
                    'action': 'get',
                    'id': captcha_id,
                    'json': 1
                }
                
                async with session.get(result_url, params=params) as response:
                    result = await response.json()
                    
                    if result.get('status') == 1:
                        return result.get('request')
                    elif result.get('request') != 'CAPCHA_NOT_READY':
                        print(f"2captcha error: {result}")
                        return None
            
            print("2captcha timeout")
            return None
    
    async def _solve_with_anticaptcha(self, site_key: str, page_url: str) -> Optional[str]:
        """Solve using AntiCaptcha service"""
        # Implementation would be similar to 2captcha
        # Left as exercise - API docs at https://anti-captcha.com/apidoc
        pass


class AdvancedScraper:
    """
    Advanced scraper with anti-bot capabilities
    """
    
    def __init__(
        self,
        proxies: List[ProxyConfig] = None,
        use_fingerprinting: bool = True,
        use_human_behavior: bool = True,
        captcha_service: str = None,
        captcha_api_key: str = None
    ):
        self.proxy_rotator = ProxyRotator(proxies) if proxies else None
        self.use_fingerprinting = use_fingerprinting
        self.use_human_behavior = use_human_behavior
        self.captcha_solver = None
        
        if captcha_service and captcha_api_key:
            self.captcha_solver = CaptchaSolver(captcha_service, captcha_api_key)
    
    async def create_browser_context(self, browser: Browser, proxy: ProxyConfig = None) -> BrowserContext:
        """Create browser context with anti-detection measures"""
        
        context_options = {}
        
        # Add proxy if available
        if proxy:
            context_options['proxy'] = {
                'server': f"{proxy.protocol}://{proxy.host}:{proxy.port}",
            }
            if proxy.username and proxy.password:
                context_options['proxy']['username'] = proxy.username
                context_options['proxy']['password'] = proxy.password
        
        # Add fingerprinting
        if self.use_fingerprinting:
            fingerprint = BrowserFingerprinting.get_random_fingerprint()
            
            context_options.update({
                'user_agent': fingerprint['user_agent'],
                'viewport': fingerprint['viewport'],
                'timezone_id': fingerprint['timezone'],
                'locale': fingerprint['locale'],
                'device_scale_factor': fingerprint['device_scale_factor'],
                'is_mobile': fingerprint['is_mobile'],
                'has_touch': fingerprint['has_touch'],
            })
        
        # Create context
        context = await browser.new_context(**context_options)
        
        # Add stealth scripts
        await context.add_init_script("""
            // Override the navigator.webdriver flag
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
            
            // Override plugins length
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
            
            // Override languages
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US', 'en']
            });
            
            // Override permissions
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                    Promise.resolve({ state: Notification.permission }) :
                    originalQuery(parameters)
            );
        """)
        
        return context
    
    async def scrape_with_anti_bot(self, url: str, browser: Browser) -> Dict:
        """Scrape URL with full anti-bot protection"""
        
        # Get proxy if available
        proxy = self.proxy_rotator.get_next_proxy() if self.proxy_rotator else None
        
        start_time = time.time()
        
        try:
            # Create context with anti-detection
            context = await self.create_browser_context(browser, proxy)
            page = await context.new_page()
            
            # Navigate to page
            await page.goto(url, timeout=30000, wait_until='networkidle')
            
            # Simulate human behavior
            if self.use_human_behavior:
                await HumanBehaviorSimulator.random_delay()
                await HumanBehaviorSimulator.random_mouse_movement(page)
                await HumanBehaviorSimulator.random_scroll(page)
            
            # Check for CAPTCHA
            captcha_detected = await page.locator('.g-recaptcha, .h-captcha').count() > 0
            
            if captcha_detected and self.captcha_solver:
                print("🤖 CAPTCHA detected, solving...")
                # Get CAPTCHA details
                site_key = await page.get_attribute('.g-recaptcha', 'data-sitekey')
                
                if site_key:
                    solution = await self.captcha_solver.solve_recaptcha_v2(site_key, url)
                    
                    if solution:
                        # Inject solution
                        await page.evaluate(f'''
                            document.getElementById('g-recaptcha-response').innerHTML = '{solution}';
                        ''')
                        
                        # Submit form
                        await page.click('button[type="submit"]')
                        await page.wait_for_load_state('networkidle')
            
            # Extract content
            content = await page.content()
            title = await page.title()
            
            # Mark proxy as successful
            if proxy:
                response_time = time.time() - start_time
                self.proxy_rotator.mark_success(proxy, response_time)
            
            await context.close()
            
            return {
                'success': True,
                'html': content,
                'title': title,
                'url': url,
                'proxy_used': f"{proxy.host}:{proxy.port}" if proxy else None,
                'response_time': time.time() - start_time
            }
        
        except Exception as e:
            # Mark proxy as failed
            if proxy:
                self.proxy_rotator.mark_failure(proxy)
            
            return {
                'success': False,
                'error': str(e),
                'url': url,
                'proxy_used': f"{proxy.host}:{proxy.port}" if proxy else None
            }


# Example usage
async def example_usage():
    """Example of advanced anti-bot scraping"""
    from playwright.async_api import async_playwright
    
    # Configure proxies (you'd use real proxies here)
    proxies = [
        ProxyConfig(host='proxy1.example.com', port=8080, username='user', password='pass'),
        ProxyConfig(host='proxy2.example.com', port=8080, username='user', password='pass'),
        ProxyConfig(host='proxy3.example.com', port=8080, username='user', password='pass'),
    ]
    
    # Create scraper
    scraper = AdvancedScraper(
        proxies=proxies,
        use_fingerprinting=True,
        use_human_behavior=True,
        captcha_service='2captcha',
        captcha_api_key='your-2captcha-api-key'
    )
    
    # Scrape with Playwright
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        
        # Scrape multiple URLs
        urls = [
            'https://example.com',
            'https://another-site.com',
        ]
        
        for url in urls:
            result = await scraper.scrape_with_anti_bot(url, browser)
            
            if result['success']:
                print(f"✅ Scraped {url} successfully")
                print(f"   Proxy: {result['proxy_used']}")
                print(f"   Time: {result['response_time']:.2f}s")
            else:
                print(f"❌ Failed to scrape {url}: {result['error']}")
        
        # Get proxy stats
        if scraper.proxy_rotator:
            stats = scraper.proxy_rotator.get_stats()
            print(f"\n📊 Proxy Stats:")
            print(f"   Total: {stats['total_proxies']}")
            print(f"   Healthy: {stats['healthy_proxies']}")
            print(f"   Banned: {stats['banned_proxies']}")
        
        await browser.close()


if __name__ == "__main__":
    asyncio.run(example_usage())
