#!/usr/bin/env python3
"""
MANUS 1.6 MAX - Validation & Cross-Reference Engine
Comprehensive data verification with authority hierarchy and fuzzy matching
"""

import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from difflib import SequenceMatcher
from datetime import datetime
import json

# ============================================================================
# SETUP
# ============================================================================

logger = logging.getLogger(__name__)

# ============================================================================
# DATA MODELS
# ============================================================================

@dataclass
class FieldValidation:
    """Validation result for a single field"""
    field_name: str
    verified: bool
    value: Any
    confidence: float  # 0-100
    method: str  # 'exact_match', 'fuzzy_match', 'authority_based'
    sources_count: int
    sources_matched: List[str]
    warning: Optional[str] = None


@dataclass
class CompanyValidationResult:
    """Complete validation result for a company"""
    success: bool
    company_name: str
    symbol: Optional[str]
    timestamp: datetime
    sources_verified: List[str]
    data_points_verified: Dict[str, FieldValidation]
    overall_confidence: float
    issues: List[str]
    warnings: List[str]
    consolidated_data: Dict[str, Any]


# ============================================================================
# VALIDATION RULES
# ============================================================================

VALIDATION_RULES = {
    'name': {
        'type': 'string',
        'required': True,
        'min_length': 3,
        'max_length': 200
    },
    'symbol': {
        'type': 'string',
        'required': False,
        'pattern': r'^[A-Z0-9]{3,10}$'
    },
    'price': {
        'type': 'float',
        'required': False,
        'min_value': 0.01,
        'max_value': 1000000
    },
    'market_cap': {
        'type': 'float',
        'required': False,
        'min_value': 1,
        'max_value': 1000000  # Million SAR
    },
    'percentage': {
        'type': 'float',
        'required': False,
        'min_value': 0,
        'max_value': 100
    },
    'shares': {
        'type': 'integer',
        'required': False,
        'min_value': 1000000
    }
}

# Authority hierarchy (higher = more authoritative)
AUTHORITY_HIERARCHY = {
    'cma': 1.0,
    'tadawul': 0.95,
    'company_ir': 0.85,
    'argaam': 0.80,
    'google': 0.60,
    'linkedin': 0.50
}

# ============================================================================
# FUZZY MATCHER
# ============================================================================

class FuzzyMatcher:
    """Fuzzy string matching for name and text comparison"""
    
    def __init__(self, threshold: float = 0.85):
        """
        Initialize fuzzy matcher
        
        Args:
            threshold: Similarity threshold (0-1)
        """
        self.threshold = threshold
    
    def match(self, str1: str, str2: str) -> float:
        """
        Calculate similarity between two strings
        
        Args:
            str1: First string
            str2: Second string
            
        Returns:
            Similarity ratio (0-1)
        """
        # Normalize strings
        str1_normalized = self._normalize(str1)
        str2_normalized = self._normalize(str2)
        
        # Calculate similarity using SequenceMatcher
        matcher = SequenceMatcher(None, str1_normalized, str2_normalized)
        ratio = matcher.ratio()
        
        return ratio
    
    def is_match(self, str1: str, str2: str) -> bool:
        """
        Check if strings are similar enough to be considered a match
        
        Args:
            str1: First string
            str2: Second string
            
        Returns:
            True if similarity >= threshold
        """
        return self.match(str1, str2) >= self.threshold
    
    def _normalize(self, text: str) -> str:
        """
        Normalize string for comparison
        
        Args:
            text: Text to normalize
            
        Returns:
            Normalized text
        """
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters (keep alphanumeric and spaces)
        text = ''.join(c for c in text if c.isalnum() or c.isspace())
        
        return text.strip()
    
    def group_by_similarity(self, items: List[str]) -> List[List[str]]:
        """
        Group similar items together
        
        Args:
            items: List of strings to group
            
        Returns:
            List of groups containing similar items
        """
        groups = []
        used = set()
        
        for i, item1 in enumerate(items):
            if i in used:
                continue
            
            group = [item1]
            used.add(i)
            
            for j, item2 in enumerate(items[i+1:], start=i+1):
                if j in used:
                    continue
                
                if self.match(item1, item2) >= self.threshold:
                    group.append(item2)
                    used.add(j)
            
            groups.append(group)
        
        return groups


# ============================================================================
# DATA VALIDATOR
# ============================================================================

class DataValidator:
    """Validates individual data points against rules"""
    
    def __init__(self, rules: Dict = None):
        """
        Initialize validator
        
        Args:
            rules: Validation rules (uses defaults if None)
        """
        self.rules = rules or VALIDATION_RULES
        self.logger = logging.getLogger("DataValidator")
    
    def validate_field(self, field_name: str, value: Any) -> Tuple[bool, Optional[str]]:
        """
        Validate a single field
        
        Args:
            field_name: Name of field to validate
            value: Value to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if field_name not in self.rules:
            # No specific rule, accept any value
            return True, None
        
        rule = self.rules[field_name]
        
        # Check required
        if rule.get('required', False) and (value is None or value == ''):
            return False, f"Required field '{field_name}' is empty"
        
        # Skip further validation if value is empty and not required
        if value is None or value == '':
            return True, None
        
        # Type checking
        expected_type = rule.get('type')
        if expected_type:
            valid, error = self._validate_type(value, expected_type)
            if not valid:
                return False, f"Invalid type for '{field_name}': {error}"
        
        # Length validation (for strings)
        if rule.get('min_length') is not None and isinstance(value, str):
            if len(value) < rule['min_length']:
                return False, f"'{field_name}' too short (min: {rule['min_length']})"
        
        if rule.get('max_length') is not None and isinstance(value, str):
            if len(value) > rule['max_length']:
                return False, f"'{field_name}' too long (max: {rule['max_length']})"
        
        # Range validation (for numbers)
        if rule.get('min_value') is not None and isinstance(value, (int, float)):
            if value < rule['min_value']:
                return False, f"'{field_name}' below minimum ({rule['min_value']})"
        
        if rule.get('max_value') is not None and isinstance(value, (int, float)):
            if value > rule['max_value']:
                return False, f"'{field_name}' exceeds maximum ({rule['max_value']})"
        
        return True, None
    
    def _validate_type(self, value: Any, expected_type: str) -> Tuple[bool, Optional[str]]:
        """Validate value type"""
        type_mapping = {
            'string': str,
            'integer': int,
            'float': (int, float),
            'boolean': bool,
            'list': list,
            'dict': dict
        }
        
        expected = type_mapping.get(expected_type)
        if expected is None:
            return True, None
        
        if isinstance(value, expected):
            return True, None
        
        return False, f"Expected {expected_type}, got {type(value).__name__}"


# ============================================================================
# CROSS-REFERENCE VALIDATOR
# ============================================================================

class CrossReferenceValidator:
    """Cross-references data from multiple sources"""
    
    def __init__(self, authority_hierarchy: Dict = None, fuzzy_threshold: float = 0.85):
        """
        Initialize cross-reference validator
        
        Args:
            authority_hierarchy: Source authority weights
            fuzzy_threshold: Fuzzy matching threshold
        """
        self.authority_hierarchy = authority_hierarchy or AUTHORITY_HIERARCHY
        self.fuzzy_matcher = FuzzyMatcher(threshold=fuzzy_threshold)
        self.logger = logging.getLogger("CrossReferenceValidator")
    
    def verify_field(self, field_name: str, values_by_source: Dict[str, Any]) -> FieldValidation:
        """
        Verify a field across multiple sources
        
        Args:
            field_name: Name of field
            values_by_source: Dict mapping source names to values
                Example: {
                    'tadawul': 179.50,
                    'argaam': 179.45,
                    'cma': None
                }
        
        Returns:
            FieldValidation result
        """
        # Remove None values
        valid_values = {
            source: value
            for source, value in values_by_source.items()
            if value is not None and value != ''
        }
        
        if not valid_values:
            return FieldValidation(
                field_name=field_name,
                verified=False,
                value=None,
                confidence=0,
                method='no_data',
                sources_count=0,
                sources_matched=[],
                warning=f"No data available for '{field_name}'"
            )
        
        # Check for exact match
        unique_values = set(valid_values.values())
        if len(unique_values) == 1:
            return FieldValidation(
                field_name=field_name,
                verified=True,
                value=list(unique_values)[0],
                confidence=100,
                method='exact_match',
                sources_count=len(valid_values),
                sources_matched=list(valid_values.keys()),
                warning=None
            )
        
        # Handle text fields with fuzzy matching
        if all(isinstance(v, str) for v in unique_values):
            return self._verify_text_field(field_name, valid_values)
        
        # Handle numeric fields with tolerance
        if all(isinstance(v, (int, float)) for v in unique_values):
            return self._verify_numeric_field(field_name, valid_values)
        
        # Default: fuzzy or best match
        return self._select_best_value(field_name, valid_values)
    
    def _verify_text_field(self, field_name: str, values_by_source: Dict[str, str]) -> FieldValidation:
        """Verify text field with fuzzy matching"""
        # Group similar values
        unique_values = list(values_by_source.values())
        groups = self.fuzzy_matcher.group_by_similarity(unique_values)
        
        if len(groups) == 1:
            # All values are similar enough
            selected_value = groups[0][0]  # Use first variant
            confidence = 95  # Slightly less than exact match
            method = 'fuzzy_match'
        else:
            # Multiple different values - select best by authority
            selected_value, matched_sources = self._select_by_authority(
                field_name, values_by_source
            )
            confidence = 75
            method = 'authority_based'
            
            matched_sources = list(matched_sources)
            return FieldValidation(
                field_name=field_name,
                verified=True,
                value=selected_value,
                confidence=confidence,
                method=method,
                sources_count=len(values_by_source),
                sources_matched=matched_sources,
                warning=f"Multiple different values found for '{field_name}'"
            )
        
        return FieldValidation(
            field_name=field_name,
            verified=True,
            value=selected_value,
            confidence=confidence,
            method=method,
            sources_count=len(values_by_source),
            sources_matched=list(values_by_source.keys()),
            warning=None
        )
    
    def _verify_numeric_field(self, field_name: str, values_by_source: Dict[str, float]) -> FieldValidation:
        """Verify numeric field with tolerance"""
        values = list(values_by_source.values())
        avg_value = sum(values) / len(values)
        
        # Calculate variance
        max_value = max(values)
        min_value = min(values)
        variance_percent = ((max_value - min_value) / avg_value * 100) if avg_value != 0 else 0
        
        # Determine tolerance based on field type
        tolerance = self._get_numeric_tolerance(field_name)
        
        if variance_percent <= tolerance:
            # Within tolerance
            confidence = 90
            method = 'fuzzy_match'
        else:
            # Exceeds tolerance - select by authority
            confidence = 70
            method = 'authority_based'
        
        selected_value, matched_sources = self._select_by_authority(
            field_name, values_by_source
        )
        
        return FieldValidation(
            field_name=field_name,
            verified=(variance_percent <= tolerance),
            value=selected_value,
            confidence=confidence,
            method=method,
            sources_count=len(values_by_source),
            sources_matched=list(matched_sources),
            warning=(
                f"Variance {variance_percent:.2f}% for '{field_name}'"
                if variance_percent > tolerance else None
            )
        )
    
    def _get_numeric_tolerance(self, field_name: str) -> float:
        """Get acceptable variance tolerance for numeric field"""
        tolerances = {
            'price': 2.0,  # 2%
            'market_cap': 5.0,  # 5%
            'shares': 2.0,  # 2%
            'volume': 10.0,  # 10%
            'percentage': 0.5  # 0.5%
        }
        return tolerances.get(field_name, 5.0)  # Default 5%
    
    def _select_by_authority(self, field_name: str, values_by_source: Dict[str, Any]) -> Tuple[Any, List[str]]:
        """Select value based on source authority"""
        best_value = None
        best_authority = -1
        matched_sources = []
        
        for source, value in values_by_source.items():
            authority = self.authority_hierarchy.get(source, 0)
            if authority >= best_authority:
                best_authority = authority
                best_value = value
        
        # Find all sources with best authority
        for source, value in values_by_source.items():
            authority = self.authority_hierarchy.get(source, 0)
            if authority == best_authority:
                matched_sources.append(source)
        
        return best_value, matched_sources
    
    def _select_best_value(self, field_name: str, values_by_source: Dict[str, Any]) -> FieldValidation:
        """Select best value when types are mixed"""
        selected_value, matched_sources = self._select_by_authority(
            field_name, values_by_source
        )
        
        return FieldValidation(
            field_name=field_name,
            verified=False,
            value=selected_value,
            confidence=60,
            method='authority_based',
            sources_count=len(values_by_source),
            sources_matched=list(matched_sources),
            warning=f"Mixed data types for '{field_name}' - selected by authority"
        )


# ============================================================================
# DATA CONSOLIDATOR
# ============================================================================

class DataConsolidator:
    """Consolidates validated data from multiple sources"""
    
    def __init__(self, cross_ref_validator: CrossReferenceValidator):
        """
        Initialize consolidator
        
        Args:
            cross_ref_validator: Cross-reference validator instance
        """
        self.cross_ref_validator = cross_ref_validator
        self.logger = logging.getLogger("DataConsolidator")
    
    def consolidate(self, collected_data: Dict[str, Dict], 
                   verification_results: Dict[str, FieldValidation]) -> Dict[str, Any]:
        """
        Consolidate data from multiple sources
        
        Args:
            collected_data: Data from each source
                {
                    'tadawul': {...},
                    'argaam': {...},
                    'cma': {...}
                }
            verification_results: Verification results for each field
                {
                    'price': FieldValidation(...),
                    'ceo': FieldValidation(...),
                    ...
                }
        
        Returns:
            Consolidated data dictionary with source attribution
        """
        consolidated = {
            'data': {},
            'sources': {}  # Track which source was used for each field
        }
        
        for field_name, validation in verification_results.items():
            if validation.value is not None:
                consolidated['data'][field_name] = validation.value
                
                # Record source attribution
                if validation.sources_matched:
                    # Use first source (already selected by authority)
                    source = validation.sources_matched[0]
                else:
                    source = 'unknown'
                
                consolidated['sources'][field_name] = {
                    'source': source,
                    'confidence': validation.confidence,
                    'verified': validation.verified,
                    'method': validation.method
                }
        
        return consolidated


# ============================================================================
# VALIDATION MANAGER
# ============================================================================

class ValidationManager:
    """Main validation orchestrator"""
    
    def __init__(self, config: Dict):
        """
        Initialize validation manager
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.logger = logging.getLogger("ValidationManager")
        
        # Initialize validators
        self.data_validator = DataValidator()
        self.cross_ref_validator = CrossReferenceValidator()
        self.data_consolidator = DataConsolidator(self.cross_ref_validator)
    
    def validate_company(self, collection_result: Dict) -> CompanyValidationResult:
        """
        Validate complete company data
        
        Args:
            collection_result: Result from DataCollectionManager
        
        Returns:
            CompanyValidationResult
        """
        company_name = collection_result.get('company_name')
        symbol = collection_result.get('symbol')
        sources_data = collection_result.get('sources', {})
        
        # Fields to validate
        fields_to_validate = [
            'current_price',
            'market_cap',
            'trading_volume',
            'shares_outstanding',
            'sector',
            'listing_date',
            'ceo',
            'chairman',
            'vice_chairman',
            'company_name'
        ]
        
        # Verify each field
        verification_results = {}
        issues = []
        warnings = []
        confidence_scores = []
        
        for field_name in fields_to_validate:
            # Collect values from all sources
            values_by_source = {}
            for source_name, source_data in sources_data.items():
                if isinstance(source_data, dict):
                    values_by_source[source_name] = source_data.get(field_name)
            
            # Verify field
            validation = self.cross_ref_validator.verify_field(field_name, values_by_source)
            verification_results[field_name] = validation
            
            # Track issues and warnings
            if not validation.verified:
                issues.append(f"{field_name}: {validation.warning}")
            
            if validation.warning and validation.verified:
                warnings.append(validation.warning)
            
            confidence_scores.append(validation.confidence)
        
        # Calculate overall confidence
        overall_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0
        
        # Consolidate data
        consolidated = self.data_consolidator.consolidate(sources_data, verification_results)
        
        # Build result
        result = CompanyValidationResult(
            success=len(issues) == 0,
            company_name=company_name,
            symbol=symbol,
            timestamp=datetime.now(),
            sources_verified=list(sources_data.keys()),
            data_points_verified={
                field: asdict(validation)
                for field, validation in verification_results.items()
            },
            overall_confidence=overall_confidence,
            issues=issues,
            warnings=warnings,
            consolidated_data=consolidated['data']
        )
        
        return result
