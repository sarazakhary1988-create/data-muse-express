#!/usr/bin/env python3
"""
MANUS 1.6 MAX - Main Research Engine Orchestrator
Production-ready implementation with full error handling, logging, and monitoring
"""

import sys
import logging
import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback

# ============================================================================
# IMPORTS (Assuming all modules are available)
# ============================================================================

# Configuration & Setup
from config.config import ConfigManager, SOURCES, MAX_WORKERS
from core.logger import setup_logging
from core.error_handler import ResearchEngineException, handle_error
from core.progress_tracker import ProgressTracker

# Data Collection
from collectors.collection_manager import DataCollectionManager
from models.company import Company

# Validation
from validation.validation_manager import ValidationManager

# Storage
from storage.storage_manager import StorageManager

# Reporting
from reports.report_generator import ReportGenerator

# Utils
from utils.helpers import validate_environment, load_company_list

# ============================================================================
# SETUP
# ============================================================================

# Initialize logging
logger = setup_logging()

# ============================================================================
# CONSTANTS
# ============================================================================

# 2025 TASI & NOMU Listed Companies
COMPANIES_2025 = [
    "Almoosa Health Co.",
    "Nice One Beauty Digital Marketing Co.",
    "Derayah Financial Co.",
    "Al-Mouj Real Estate",
    "Arabian Petrochemical Company",
    "United International Insurance Group",
    "Fanatech Limited",
    "Waha Capital Public Joint Stock Company",
    "Saudi Steel Pipes Company",
    "Arabian Recycling Metals Co.",
    "Tamimi Technologies Company",
    "Almakawi Development Co.",
    "Abyaar Development Company",
    "Alinma Bank",
    "Amwal Al Khaleej Trading Company",
    "Ar Rayan for Trading Co.",
    "Arabian Industrial Gases Co.",
    "Al-Khaleej Insurance & Reinsurance Co.",
    "Arabian Insurance Co.",
    "Al Rajhi Banking and Investment Corporation",
    "Al Jouf Development Company",
    "Al Kharji Holding Company",
    "Al-Mansahar Company",
    "Al-Mutakallim Co.",
    "Almotahed",
    "Al-Rifai Trading Company",
    "Al-Safa Islamic Financial Company",
    "AlKhubar Real Estate",
    "Almadina Insurance & Reinsurance Co.",
    "Almohannadi Digital Marketing",
    "AlRajhan Industrialization Company",
    "Arabian Engineering & Technology",
    "AAERJ Holding Company",
    "Arabian Digital Solutions",
    "ADA Real Estate Company",
    "Ayana Holding and Investment",
    "Badger Digital Marketing Company"
]

# ============================================================================
# ORCHESTRATOR CLASS
# ============================================================================

class ResearchEngineOrchestrator:
    """
    Main orchestrator controlling the complete wide research engine pipeline
    
    Responsibilities:
    - Coordinate all collection, validation, and reporting phases
    - Manage parallel execution and error handling
    - Track progress and generate statistics
    - Ensure data quality and consistency
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the orchestrator
        
        Args:
            config_path: Optional path to config file
        """
        self.logger = logger
        self.start_time = datetime.now()
        self.end_time = None
        
        # Initialize components
        try:
            self.logger.info("Initializing Research Engine Orchestrator...")
            self.config = ConfigManager(config_path)
            self.progress = ProgressTracker()
            self.storage = StorageManager(self.config)
            self.collection_manager = DataCollectionManager(self.config)
            self.validation_manager = ValidationManager(self.config)
            self.report_generator = ReportGenerator(self.config)
            
            self.logger.info("Orchestrator initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize orchestrator: {str(e)}")
            raise ResearchEngineException(f"Initialization failed: {str(e)}")
        
        # State tracking
        self.execution_stats = {
            'companies_requested': 0,
            'companies_processed': 0,
            'companies_successful': 0,
            'companies_failed': 0,
            'total_data_points': 0,
            'validated_data_points': 0,
            'conflicting_data_points': 0,
            'reports_generated': 0,
            'execution_duration': 0
        }
    
    # ========================================================================
    # MAIN EXECUTION PIPELINE
    # ========================================================================
    
    def execute(self, companies: Optional[List[str]] = None) -> Dict:
        """
        Execute the complete research engine pipeline
        
        Args:
            companies: List of company names to research (uses defaults if None)
            
        Returns:
            Dictionary with execution results and statistics
        """
        try:
            # Use provided companies or default list
            companies_to_process = companies or COMPANIES_2025
            self.execution_stats['companies_requested'] = len(companies_to_process)
            
            self.logger.info("=" * 80)
            self.logger.info("MANUS 1.6 MAX - WIDE RESEARCH ENGINE")
            self.logger.info("=" * 80)
            self.logger.info(f"Starting research for {len(companies_to_process)} companies")
            self.logger.info(f"Start time: {self.start_time}")
            
            # Phase 1: Data Collection
            self.logger.info("\n" + "=" * 80)
            self.logger.info("PHASE 1: DATA COLLECTION")
            self.logger.info("=" * 80)
            collected_data = self._phase_collection(companies_to_process)
            
            # Phase 2: Validation
            self.logger.info("\n" + "=" * 80)
            self.logger.info("PHASE 2: DATA VALIDATION & VERIFICATION")
            self.logger.info("=" * 80)
            validated_data = self._phase_validation(collected_data)
            
            # Phase 3: Report Generation
            self.logger.info("\n" + "=" * 80)
            self.logger.info("PHASE 3: REPORT GENERATION")
            self.logger.info("=" * 80)
            reports = self._phase_reporting(validated_data)
            
            # Phase 4: Completion
            self.logger.info("\n" + "=" * 80)
            self.logger.info("PHASE 4: COMPLETION & STATISTICS")
            self.logger.info("=" * 80)
            completion_result = self._phase_completion(reports)
            
            self.logger.info("\n" + "=" * 80)
            self.logger.info("EXECUTION COMPLETED SUCCESSFULLY")
            self.logger.info("=" * 80)
            
            return completion_result
            
        except Exception as e:
            self.logger.error(f"\nCRITICAL ERROR: {str(e)}")
            self.logger.error(traceback.format_exc())
            return self._handle_execution_error(e)
    
    # ========================================================================
    # PHASE 1: DATA COLLECTION
    # ========================================================================
    
    def _phase_collection(self, companies: List[str]) -> List[Dict]:
        """
        Phase 1: Collect data from all sources in parallel
        
        Args:
            companies: List of companies to collect data for
            
        Returns:
            List of collected data dictionaries
        """
        self.logger.info(f"Initializing parallel collection with {MAX_WORKERS} workers...")
        
        collected_data = []
        failed_companies = []
        
        # Use ThreadPoolExecutor for parallel collection
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            # Submit all collection tasks
            future_to_company = {
                executor.submit(self.collection_manager.collect_company, company): company
                for company in companies
            }
            
            # Process completed tasks
            completed = 0
            for future in as_completed(future_to_company):
                company = future_to_company[future]
                completed += 1
                
                try:
                    result = future.result(timeout=60)
                    
                    if result['success']:
                        collected_data.append(result)
                        self.execution_stats['companies_successful'] += 1
                        self.logger.info(
                            f"[{completed}/{len(companies)}] ✓ {company} - "
                            f"Collected from {len(result['sources_available'])} sources"
                        )
                    else:
                        failed_companies.append((company, result.get('error')))
                        self.execution_stats['companies_failed'] += 1
                        self.logger.warning(
                            f"[{completed}/{len(companies)}] ✗ {company} - "
                            f"Failed: {result.get('error')}"
                        )
                    
                    self.execution_stats['companies_processed'] += 1
                    self.progress.update(completed / len(companies))
                    
                except Exception as e:
                    failed_companies.append((company, str(e)))
                    self.execution_stats['companies_failed'] += 1
                    self.logger.error(f"[{completed}/{len(companies)}] ✗ {company} - Exception: {str(e)}")
        
        # Log collection summary
        self.logger.info(f"\nCollection Summary:")
        self.logger.info(f"  Total companies: {len(companies)}")
        self.logger.info(f"  Successfully collected: {self.execution_stats['companies_successful']}")
        self.logger.info(f"  Failed: {self.execution_stats['companies_failed']}")
        self.logger.info(f"  Data points collected: {self._count_data_points(collected_data)}")
        
        if failed_companies:
            self.logger.warning(f"\nFailed companies:")
            for company, error in failed_companies:
                self.logger.warning(f"  - {company}: {error}")
        
        return collected_data
    
    # ========================================================================
    # PHASE 2: VALIDATION & VERIFICATION
    # ========================================================================
    
    def _phase_validation(self, collected_data: List[Dict]) -> List[Dict]:
        """
        Phase 2: Validate and cross-reference collected data
        
        Args:
            collected_data: List of collected data to validate
            
        Returns:
            List of validated data dictionaries
        """
        self.logger.info(f"Validating {len(collected_data)} companies...")
        
        validated_data = []
        validation_issues = []
        
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_to_company = {
                executor.submit(self.validation_manager.validate_company, data): data['company_name']
                for data in collected_data
            }
            
            completed = 0
            for future in as_completed(future_to_company):
                company_name = future_to_company[future]
                completed += 1
                
                try:
                    result = future.result(timeout=30)
                    validated_data.append(result)
                    
                    # Log confidence score
                    confidence = result.get('verification', {}).get('overall_confidence', 0)
                    self.logger.info(
                        f"[{completed}/{len(collected_data)}] ✓ {company_name} - "
                        f"Confidence: {confidence:.1f}%"
                    )
                    
                    # Track data points
                    self.execution_stats['validated_data_points'] += \
                        self._count_validated_points(result)
                    
                    # Track conflicts
                    data_points_verified = result.get('verification', {}).get(
                        'data_points_verified', {}
                    )
                    for field, status in data_points_verified.items():
                        if not status.get('verified', True):
                            validation_issues.append((company_name, field, status))
                    
                except Exception as e:
                    self.logger.error(f"Validation error for {company_name}: {str(e)}")
        
        # Log validation summary
        self.logger.info(f"\nValidation Summary:")
        self.logger.info(f"  Total companies validated: {len(validated_data)}")
        self.logger.info(f"  Data points validated: {self.execution_stats['validated_data_points']}")
        self.logger.info(f"  Conflicts detected: {len(validation_issues)}")
        
        if validation_issues:
            self.logger.warning(f"\nValidation Issues (first 10):")
            for company, field, status in validation_issues[:10]:
                self.logger.warning(f"  - {company} ({field}): {status.get('warning')}")
        
        self.execution_stats['conflicting_data_points'] = len(validation_issues)
        
        return validated_data
    
    # ========================================================================
    # PHASE 3: REPORT GENERATION
    # ========================================================================
    
    def _phase_reporting(self, validated_data: List[Dict]) -> Dict:
        """
        Phase 3: Generate comprehensive reports
        
        Args:
            validated_data: List of validated data to report on
            
        Returns:
            Dictionary with generated report paths
        """
        self.logger.info(f"Generating reports for {len(validated_data)} companies...")
        
        reports = {}
        
        try:
            # Generate Excel report
            self.logger.info("Generating Excel report...")
            excel_path = self.report_generator.generate_excel_report(validated_data)
            reports['excel'] = excel_path
            self.logger.info(f"  ✓ Excel report: {excel_path}")
            
            # Generate JSON export
            self.logger.info("Generating JSON export...")
            json_path = self.report_generator.generate_json_export(validated_data)
            reports['json'] = json_path
            self.logger.info(f"  ✓ JSON export: {json_path}")
            
            # Generate summary report
            self.logger.info("Generating summary report...")
            summary_path = self.report_generator.generate_summary_report(validated_data)
            reports['summary'] = summary_path
            self.logger.info(f"  ✓ Summary report: {summary_path}")
            
            # Generate data quality report
            self.logger.info("Generating data quality report...")
            quality_path = self.report_generator.generate_quality_report(validated_data)
            reports['quality'] = quality_path
            self.logger.info(f"  ✓ Quality report: {quality_path}")
            
            self.execution_stats['reports_generated'] = len(reports)
            
        except Exception as e:
            self.logger.error(f"Error generating reports: {str(e)}")
            raise ResearchEngineException(f"Report generation failed: {str(e)}")
        
        return reports
    
    # ========================================================================
    # PHASE 4: COMPLETION & STATISTICS
    # ========================================================================
    
    def _phase_completion(self, reports: Dict) -> Dict:
        """
        Phase 4: Finalize execution and generate statistics
        
        Args:
            reports: Dictionary of generated reports
            
        Returns:
            Completion result with all statistics
        """
        self.end_time = datetime.now()
        duration = (self.end_time - self.start_time).total_seconds()
        self.execution_stats['execution_duration'] = duration
        
        # Log final statistics
        self.logger.info(f"\nExecution Statistics:")
        self.logger.info(f"  Total companies requested: {self.execution_stats['companies_requested']}")
        self.logger.info(f"  Companies successfully processed: {self.execution_stats['companies_successful']}")
        self.logger.info(f"  Companies failed: {self.execution_stats['companies_failed']}")
        self.logger.info(f"  Success rate: {self._calculate_success_rate():.1f}%")
        self.logger.info(f"  Data points validated: {self.execution_stats['validated_data_points']}")
        self.logger.info(f"  Conflicting data points: {self.execution_stats['conflicting_data_points']}")
        self.logger.info(f"  Reports generated: {self.execution_stats['reports_generated']}")
        self.logger.info(f"  Total execution time: {duration:.2f} seconds ({duration/60:.2f} minutes)")
        self.logger.info(f"  Average time per company: {duration/self.execution_stats['companies_processed']:.2f} seconds")
        
        # Archive raw data
        self.logger.info("\nArchiving collected data...")
        try:
            archive_path = self.storage.archive_raw_data()
            self.logger.info(f"  ✓ Data archived to: {archive_path}")
        except Exception as e:
            self.logger.warning(f"  Warning: Could not archive data: {str(e)}")
        
        # Create execution report
        execution_report = {
            'status': 'SUCCESS',
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'duration_seconds': duration,
            'statistics': self.execution_stats,
            'reports': reports,
            'version': '1.6 Max'
        }
        
        # Save execution report
        report_path = Path('output') / 'execution_report.json'
        report_path.parent.mkdir(parents=True, exist_ok=True)
        with open(report_path, 'w') as f:
            json.dump(execution_report, f, indent=2)
        self.logger.info(f"  ✓ Execution report saved to: {report_path}")
        
        return execution_report
    
    # ========================================================================
    # ERROR HANDLING
    # ========================================================================
    
    def _handle_execution_error(self, error: Exception) -> Dict:
        """
        Handle critical execution errors
        
        Args:
            error: The exception that occurred
            
        Returns:
            Error result dictionary
        """
        self.end_time = datetime.now()
        duration = (self.end_time - self.start_time).total_seconds()
        
        error_report = {
            'status': 'FAILED',
            'error': str(error),
            'error_type': type(error).__name__,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'duration_seconds': duration,
            'partial_statistics': self.execution_stats,
            'version': '1.6 Max'
        }
        
        # Save error report
        report_path = Path('output') / 'error_report.json'
        report_path.parent.mkdir(parents=True, exist_ok=True)
        with open(report_path, 'w') as f:
            json.dump(error_report, f, indent=2)
        
        self.logger.info(f"Error report saved to: {report_path}")
        
        return error_report
    
    # ========================================================================
    # HELPER METHODS
    # ========================================================================
    
    def _count_data_points(self, collected_data: List[Dict]) -> int:
        """Count total data points in collection"""
        total = 0
        for data in collected_data:
            for source, source_data in data.get('sources', {}).items():
                if isinstance(source_data, dict):
                    total += len(source_data)
        return total
    
    def _count_validated_points(self, validation_result: Dict) -> int:
        """Count validated data points"""
        verified_data = validation_result.get('verification', {}).get(
            'data_points_verified', {}
        )
        return len(verified_data)
    
    def _calculate_success_rate(self) -> float:
        """Calculate success rate percentage"""
        if self.execution_stats['companies_processed'] == 0:
            return 0
        return (self.execution_stats['companies_successful'] / 
                self.execution_stats['companies_processed'] * 100)


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point for the research engine"""
    
    try:
        # Validate environment
        if not validate_environment():
            logger.error("Environment validation failed")
            sys.exit(1)
        
        # Create orchestrator
        orchestrator = ResearchEngineOrchestrator()
        
        # Execute pipeline
        result = orchestrator.execute()
        
        # Exit with appropriate code
        if result['status'] == 'SUCCESS':
            sys.exit(0)
        else:
            sys.exit(1)
    
    except KeyboardInterrupt:
        logger.info("Execution interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")
        logger.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()
