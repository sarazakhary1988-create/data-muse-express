#!/usr/bin/env python3
"""
MANUS 1.6 MAX - Data Collection Manager
Orchestrates parallel collection from multiple data sources with error handling
"""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import json

# ============================================================================
# SETUP
# ============================================================================

logger = logging.getLogger(__name__)

# ============================================================================
# DATA MODELS
# ============================================================================

@dataclass
class CollectionResult:
    """Result from a collection operation"""
    success: bool
    company_name: str
    symbol: Optional[str]
    sources_available: List[str]
    sources: Dict[str, Any]
    collected_timestamp: datetime
    duration_seconds: float
    error: Optional[str] = None
    warnings: List[str] = None
    completeness_score: float = 0.0


# ============================================================================
# BASE COLLECTOR CLASS
# ============================================================================

class BaseCollector:
    """Base class for all data collectors"""
    
    def __init__(self, source_name: str, config: Dict):
        """
        Initialize base collector
        
        Args:
            source_name: Name of the data source
            config: Configuration dictionary
        """
        self.source_name = source_name
        self.config = config
        self.logger = logging.getLogger(f"Collector.{source_name}")
        self.session = requests.Session()
        self.timeout = config.get('timeout', 30)
        self.retries = config.get('retries', 3)
        self._setup_session()
    
    def _setup_session(self):
        """Setup requests session with headers"""
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def collect(self, company_name: str, symbol: Optional[str] = None) -> Dict:
        """
        Collect data from source
        
        Args:
            company_name: Name of company to research
            symbol: Stock symbol if available
            
        Returns:
            Collected data dictionary
        """
        raise NotImplementedError()
    
    def validate_source(self) -> bool:
        """Check if source is accessible"""
        raise NotImplementedError()


# ============================================================================
# TADAWUL COLLECTOR
# ============================================================================

class TadawulCollector(BaseCollector):
    """Collector for Tadawul Saudi Exchange data"""
    
    def __init__(self, config: Dict):
        super().__init__("Tadawul", config)
        self.base_url = "https://www.tadawulgroup.sa"
        self.driver = None
    
    def collect(self, company_name: str, symbol: Optional[str] = None) -> Dict:
        """Collect Tadawul data"""
        result = {
            'source': 'tadawul',
            'success': False,
            'data': {},
            'error': None
        }
        
        try:
            self.logger.info(f"Collecting from Tadawul: {company_name}")
            
            # Initialize browser
            self._init_browser()
            
            # Search for company
            search_data = self._search_company(company_name, symbol)
            
            if search_data:
                # Extract detailed information
                detailed_data = self._extract_company_details(search_data)
                result['data'] = detailed_data
                result['success'] = True
                self.logger.info(f"  ✓ Tadawul data collected for {company_name}")
            else:
                result['error'] = f"Company not found on Tadawul: {company_name}"
                self.logger.warning(result['error'])
        
        except Exception as e:
            result['error'] = str(e)
            self.logger.error(f"Tadawul collection error: {str(e)}")
        
        finally:
            self._cleanup_browser()
        
        return result
    
    def _init_browser(self):
        """Initialize Selenium browser"""
        if self.driver is None:
            options = Options()
            options.add_argument('--start-maximized')
            options.add_argument('--disable-notifications')
            self.driver = webdriver.Chrome(options=options)
    
    def _cleanup_browser(self):
        """Cleanup browser resources"""
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
    
    def _search_company(self, company_name: str, symbol: Optional[str]) -> Dict:
        """Search for company on Tadawul"""
        try:
            # Navigate to Tadawul
            self.driver.get(f"{self.base_url}/wps/portal/saudiexchange")
            
            # Wait for search input
            search_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//input[@id='search-input']"))
            )
            
            # Search
            search_input.clear()
            search_input.send_keys(symbol or company_name)
            search_input.submit()
            
            # Wait for results
            results = WebDriverWait(self.driver, 10).until(
                EC.presence_of_all_elements_located((By.CLASS_NAME, "company-result"))
            )
            
            if results:
                # Click first result
                results[0].click()
                return {'symbol': symbol, 'company_name': company_name}
            
            return None
        
        except Exception as e:
            self.logger.error(f"Search error: {str(e)}")
            return None
    
    def _extract_company_details(self, search_data: Dict) -> Dict:
        """Extract detailed company information"""
        try:
            # Parse page content
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Extract data points
            data = {
                'symbol': search_data.get('symbol'),
                'company_name': search_data.get('company_name'),
                'current_price': self._extract_price(soup),
                'market_cap': self._extract_market_cap(soup),
                'trading_volume': self._extract_volume(soup),
                'shares_outstanding': self._extract_shares(soup),
                'sector': self._extract_sector(soup),
                'listing_date': self._extract_listing_date(soup),
                'pe_ratio': self._extract_pe_ratio(soup),
                '52week_high': self._extract_52week_high(soup),
                '52week_low': self._extract_52week_low(soup)
            }
            
            return data
        
        except Exception as e:
            self.logger.error(f"Extraction error: {str(e)}")
            return {}
    
    def _extract_price(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract current price"""
        try:
            price_elem = soup.find('span', {'class': 'current-price'})
            if price_elem:
                return float(price_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_market_cap(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract market cap"""
        try:
            market_cap_elem = soup.find('span', {'class': 'market-cap'})
            if market_cap_elem:
                text = market_cap_elem.text.replace('M SAR', '').strip()
                return float(text)
        except:
            pass
        return None
    
    def _extract_volume(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract trading volume"""
        try:
            volume_elem = soup.find('span', {'class': 'trading-volume'})
            if volume_elem:
                return float(volume_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_shares(self, soup: BeautifulSoup) -> Optional[int]:
        """Extract shares outstanding"""
        try:
            shares_elem = soup.find('span', {'class': 'shares-outstanding'})
            if shares_elem:
                return int(shares_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_sector(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract sector"""
        try:
            sector_elem = soup.find('span', {'class': 'sector'})
            if sector_elem:
                return sector_elem.text.strip()
        except:
            pass
        return None
    
    def _extract_listing_date(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract listing date"""
        try:
            date_elem = soup.find('span', {'class': 'listing-date'})
            if date_elem:
                return date_elem.text.strip()
        except:
            pass
        return None
    
    def _extract_pe_ratio(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract P/E ratio"""
        try:
            pe_elem = soup.find('span', {'class': 'pe-ratio'})
            if pe_elem:
                return float(pe_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_52week_high(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract 52-week high"""
        try:
            high_elem = soup.find('span', {'class': '52week-high'})
            if high_elem:
                return float(high_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_52week_low(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract 52-week low"""
        try:
            low_elem = soup.find('span', {'class': '52week-low'})
            if low_elem:
                return float(low_elem.text.strip())
        except:
            pass
        return None
    
    def validate_source(self) -> bool:
        """Check if Tadawul is accessible"""
        try:
            response = self.session.get(self.base_url, timeout=self.timeout)
            return response.status_code == 200
        except:
            return False


# ============================================================================
# ARGAAM COLLECTOR
# ============================================================================

class ArgaamCollector(BaseCollector):
    """Collector for Argaam financial platform data"""
    
    def __init__(self, config: Dict):
        super().__init__("Argaam", config)
        self.base_url = "https://www.argaam.com"
    
    def collect(self, company_name: str, symbol: Optional[str] = None) -> Dict:
        """Collect Argaam data"""
        result = {
            'source': 'argaam',
            'success': False,
            'data': {},
            'error': None
        }
        
        try:
            self.logger.info(f"Collecting from Argaam: {company_name}")
            
            # Search for company
            company_data = self._search_and_parse(company_name)
            
            if company_data:
                result['data'] = company_data
                result['success'] = True
                self.logger.info(f"  ✓ Argaam data collected for {company_name}")
            else:
                result['error'] = f"Company not found on Argaam: {company_name}"
                self.logger.warning(result['error'])
        
        except Exception as e:
            result['error'] = str(e)
            self.logger.error(f"Argaam collection error: {str(e)}")
        
        return result
    
    def _search_and_parse(self, company_name: str) -> Dict:
        """Search and parse Argaam data"""
        try:
            # Build search URL
            search_url = f"{self.base_url}/en/search"
            params = {'q': company_name}
            
            # Make request
            response = self.session.get(search_url, params=params, timeout=self.timeout)
            
            if response.status_code != 200:
                return None
            
            # Parse response
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract company information
            company_data = {
                'company_name': company_name,
                'executives': self._extract_executives(soup),
                'shareholders': self._extract_shareholders(soup),
                'financial_summary': self._extract_financial_summary(soup),
                'recent_news': self._extract_recent_news(soup)
            }
            
            return company_data
        
        except Exception as e:
            self.logger.error(f"Parse error: {str(e)}")
            return None
    
    def _extract_executives(self, soup: BeautifulSoup) -> Dict:
        """Extract executive information"""
        try:
            executives = {}
            
            # Find executive section
            exec_section = soup.find('div', {'class': 'executives'})
            if exec_section:
                # Extract CEO
                ceo = exec_section.find('span', {'class': 'ceo'})
                if ceo:
                    executives['ceo'] = ceo.text.strip()
                
                # Extract Chairman
                chairman = exec_section.find('span', {'class': 'chairman'})
                if chairman:
                    executives['chairman'] = chairman.text.strip()
                
                # Extract Vice Chairman
                vice_chairman = exec_section.find('span', {'class': 'vice-chairman'})
                if vice_chairman:
                    executives['vice_chairman'] = vice_chairman.text.strip()
            
            return executives
        
        except Exception as e:
            self.logger.error(f"Executive extraction error: {str(e)}")
            return {}
    
    def _extract_shareholders(self, soup: BeautifulSoup) -> List[Dict]:
        """Extract shareholder information"""
        try:
            shareholders = []
            
            # Find shareholders section
            shareholders_section = soup.find('div', {'class': 'shareholders'})
            if shareholders_section:
                rows = shareholders_section.find_all('tr', {'class': 'shareholder-row'})
                
                for row in rows:
                    try:
                        name_elem = row.find('td', {'class': 'shareholder-name'})
                        percentage_elem = row.find('td', {'class': 'percentage'})
                        
                        if name_elem and percentage_elem:
                            shareholders.append({
                                'name': name_elem.text.strip(),
                                'percentage': float(percentage_elem.text.replace('%', '').strip())
                            })
                    except:
                        pass
            
            return shareholders
        
        except Exception as e:
            self.logger.error(f"Shareholder extraction error: {str(e)}")
            return []
    
    def _extract_financial_summary(self, soup: BeautifulSoup) -> Dict:
        """Extract financial summary"""
        try:
            financials = {}
            
            # Find financial section
            fin_section = soup.find('div', {'class': 'financial-summary'})
            if fin_section:
                # Extract various financial metrics
                revenue = fin_section.find('span', {'class': 'revenue'})
                if revenue:
                    financials['revenue'] = revenue.text.strip()
                
                net_income = fin_section.find('span', {'class': 'net-income'})
                if net_income:
                    financials['net_income'] = net_income.text.strip()
            
            return financials
        
        except Exception as e:
            self.logger.error(f"Financial extraction error: {str(e)}")
            return {}
    
    def _extract_recent_news(self, soup: BeautifulSoup) -> List[Dict]:
        """Extract recent news"""
        try:
            news = []
            
            # Find news section
            news_section = soup.find('div', {'class': 'recent-news'})
            if news_section:
                articles = news_section.find_all('article', {'class': 'news-item'})
                
                for article in articles[:5]:  # Top 5 articles
                    try:
                        title = article.find('h3', {'class': 'title'})
                        date = article.find('span', {'class': 'date'})
                        
                        if title and date:
                            news.append({
                                'title': title.text.strip(),
                                'date': date.text.strip()
                            })
                    except:
                        pass
            
            return news
        
        except Exception as e:
            self.logger.error(f"News extraction error: {str(e)}")
            return []
    
    def validate_source(self) -> bool:
        """Check if Argaam is accessible"""
        try:
            response = self.session.get(self.base_url, timeout=self.timeout)
            return response.status_code == 200
        except:
            return False


# ============================================================================
# CMA COLLECTOR
# ============================================================================

class CMACollector(BaseCollector):
    """Collector for CMA (Capital Market Authority) prospectus data"""
    
    def __init__(self, config: Dict):
        super().__init__("CMA", config)
        self.base_url = "https://cma.gov.sa"
    
    def collect(self, company_name: str, symbol: Optional[str] = None) -> Dict:
        """Collect CMA prospectus data"""
        result = {
            'source': 'cma',
            'success': False,
            'data': {},
            'error': None
        }
        
        try:
            self.logger.info(f"Collecting from CMA: {company_name}")
            
            # Search for prospectus
            prospectus_data = self._search_prospectus(company_name)
            
            if prospectus_data:
                result['data'] = prospectus_data
                result['success'] = True
                self.logger.info(f"  ✓ CMA data collected for {company_name}")
            else:
                result['error'] = f"Prospectus not found on CMA: {company_name}"
                self.logger.warning(result['error'])
        
        except Exception as e:
            result['error'] = str(e)
            self.logger.error(f"CMA collection error: {str(e)}")
        
        return result
    
    def _search_prospectus(self, company_name: str) -> Dict:
        """Search for company prospectus"""
        try:
            # Build search URL
            search_url = f"{self.base_url}/en/Market/Prospectuses"
            params = {'search': company_name}
            
            # Make request
            response = self.session.get(search_url, params=params, timeout=self.timeout)
            
            if response.status_code != 200:
                return None
            
            # Parse response
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract prospectus information
            prospectus_data = {
                'company_name': company_name,
                'prospectus_found': True,
                'prospectus_url': self._extract_prospectus_url(soup),
                'offering_amount': self._extract_offering_amount(soup),
                'offering_price': self._extract_offering_price(soup),
                'underwriter': self._extract_underwriter(soup),
                'listing_date': self._extract_cma_listing_date(soup),
                'shares_offered': self._extract_shares_offered(soup)
            }
            
            return prospectus_data
        
        except Exception as e:
            self.logger.error(f"Prospectus search error: {str(e)}")
            return None
    
    def _extract_prospectus_url(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract prospectus URL"""
        try:
            prospectus_link = soup.find('a', {'class': 'prospectus-link'})
            if prospectus_link and prospectus_link.get('href'):
                url = prospectus_link['href']
                if not url.startswith('http'):
                    url = self.base_url + url
                return url
        except:
            pass
        return None
    
    def _extract_offering_amount(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract offering amount"""
        try:
            amount_elem = soup.find('span', {'class': 'offering-amount'})
            if amount_elem:
                return amount_elem.text.strip()
        except:
            pass
        return None
    
    def _extract_offering_price(self, soup: BeautifulSoup) -> Optional[float]:
        """Extract offering price"""
        try:
            price_elem = soup.find('span', {'class': 'offering-price'})
            if price_elem:
                return float(price_elem.text.strip())
        except:
            pass
        return None
    
    def _extract_underwriter(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract underwriter name"""
        try:
            underwriter_elem = soup.find('span', {'class': 'underwriter'})
            if underwriter_elem:
                return underwriter_elem.text.strip()
        except:
            pass
        return None
    
    def _extract_cma_listing_date(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract listing date from CMA"""
        try:
            date_elem = soup.find('span', {'class': 'listing-date'})
            if date_elem:
                return date_elem.text.strip()
        except:
            pass
        return None
    
    def _extract_shares_offered(self, soup: BeautifulSoup) -> Optional[int]:
        """Extract shares offered"""
        try:
            shares_elem = soup.find('span', {'class': 'shares-offered'})
            if shares_elem:
                return int(shares_elem.text.strip())
        except:
            pass
        return None
    
    def validate_source(self) -> bool:
        """Check if CMA is accessible"""
        try:
            response = self.session.get(self.base_url, timeout=self.timeout)
            return response.status_code == 200
        except:
            return False


# ============================================================================
# DATA COLLECTION MANAGER
# ============================================================================

class DataCollectionManager:
    """Manages data collection from all sources"""
    
    def __init__(self, config: Dict):
        """
        Initialize collection manager
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.logger = logging.getLogger("CollectionManager")
        
        # Initialize collectors
        self.collectors = {
            'tadawul': TadawulCollector(config.get('tadawul', {})),
            'argaam': ArgaamCollector(config.get('argaam', {})),
            'cma': CMACollector(config.get('cma', {}))
        }
        
        # Validate all sources
        self._validate_sources()
    
    def _validate_sources(self):
        """Validate all data sources"""
        self.logger.info("Validating data sources...")
        for source_name, collector in self.collectors.items():
            if collector.validate_source():
                self.logger.info(f"  ✓ {source_name.upper()} is accessible")
            else:
                self.logger.warning(f"  ⚠ {source_name.upper()} may be inaccessible")
    
    def collect_company(self, company_name: str, symbol: Optional[str] = None) -> CollectionResult:
        """
        Collect data for a single company from all sources
        
        Args:
            company_name: Name of company to collect data for
            symbol: Stock symbol if available
            
        Returns:
            CollectionResult object
        """
        start_time = time.time()
        sources_data = {}
        sources_available = []
        errors = []
        warnings = []
        
        # Collect from all sources in parallel
        with ThreadPoolExecutor(max_workers=len(self.collectors)) as executor:
            futures = {
                executor.submit(collector.collect, company_name, symbol): source_name
                for source_name, collector in self.collectors.items()
            }
            
            for future in as_completed(futures):
                source_name = futures[future]
                try:
                    result = future.result(timeout=60)
                    
                    if result['success']:
                        sources_data[source_name] = result['data']
                        sources_available.append(source_name)
                    else:
                        warnings.append(f"{source_name}: {result.get('error')}")
                
                except Exception as e:
                    errors.append(f"{source_name}: {str(e)}")
        
        # Calculate metrics
        duration = time.time() - start_time
        completeness_score = len(sources_available) / len(self.collectors) * 100
        
        # Build result
        result = CollectionResult(
            success=len(sources_available) > 0,
            company_name=company_name,
            symbol=symbol,
            sources_available=sources_available,
            sources=sources_data,
            collected_timestamp=datetime.now(),
            duration_seconds=duration,
            error='; '.join(errors) if errors else None,
            warnings=warnings,
            completeness_score=completeness_score
        )
        
        return result
