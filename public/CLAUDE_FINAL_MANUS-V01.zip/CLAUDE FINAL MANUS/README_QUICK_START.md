# MANUS 1.6 MAX - COMPLETE FULL STACK
## Quick Start Guide - Get Running in Minutes

**Status:** ✅ 100% PRODUCTION READY | **Version:** 1.6 Max | **Date:** 2025-01-01

---

## 🚀 QUICK START (5 MINUTES)

### Option 1: Docker Compose (Recommended)

```bash
# 1. Clone and navigate
git clone <repository-url>
cd manus-full-stack

# 2. Copy environment file
cp .env.example .env

# 3. Build and start
docker-compose up -d

# 4. Wait for services to be ready (~2 minutes)
docker-compose logs -f

# 5. Access the application
# Frontend: http://localhost:3000
# Backend API: http://localhost:8000
# Grafana: http://localhost:3001
# Kibana: http://localhost:5601
```

### Option 2: Local Development (Python + Node.js)

```bash
# Backend Setup
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py

# Frontend Setup (in another terminal)
cd frontend
npm install
npm start

# Access at http://localhost:3000
```

### Option 3: Kubernetes Deployment

```bash
# 1. Create namespace
kubectl apply -f k8s-manifests/01-namespace.yaml

# 2. Create secrets
kubectl create secret generic postgres-secret \
  --from-literal=username=manus_user \
  --from-literal=password=manus_password \
  -n manus

kubectl create secret generic backend-secret \
  --from-literal=database-url=postgresql://manus_user:password@postgres:5432/manus_db \
  --from-literal=jwt-secret=your-jwt-secret \
  -n manus

# 3. Deploy all services
kubectl apply -f k8s-manifests/

# 4. Check status
kubectl get pods -n manus
kubectl get svc -n manus
```

---

## 📋 WHAT'S INCLUDED

### Backend (Python/FastAPI)
```
✅ Complete API (RESTful + WebSocket)
✅ Database layer (SQLAlchemy + PostgreSQL)
✅ Unified orchestrator (v02 + Companies integration)
✅ Authentication & authorization (JWT)
✅ Async tasks (Celery)
✅ Caching (Redis)
✅ Logging & monitoring
✅ Error handling & recovery
```

### Frontend (React/TypeScript)
```
✅ Dashboard with real-time stats
✅ Research management interface
✅ Company database browser
✅ Real-time progress monitoring
✅ Report viewer & download
✅ Analytics dashboard
✅ User authentication
✅ Responsive design
```

### Infrastructure
```
✅ Docker containers (8 services)
✅ Docker Compose orchestration
✅ Kubernetes manifests
✅ PostgreSQL database
✅ Redis cache
✅ RabbitMQ queue
✅ Elasticsearch logging
✅ Prometheus monitoring
✅ Grafana dashboards
```

---

## 🔑 KEY CREDENTIALS

### Default Credentials
```
Frontend: http://localhost:3000
Backend API: http://localhost:8000/api/v1
Admin Dashboard: http://localhost:3001

Username: admin
Password: admin

Database: PostgreSQL
Host: localhost:5432
Database: manus_db
User: manus_user
Password: manus_password
```

### Change These in Production!
```bash
# Update in .env file before deployment
POSTGRES_PASSWORD=<secure-password>
JWT_SECRET_KEY=<secure-key>
REDIS_PASSWORD=<secure-password>
```

---

## 📖 DOCUMENTATION

### Architecture
- **00_COMPLETE_UNIFIED_ARCHITECTURE.md** - System design & blueprints
- **01_BACKEND_IMPLEMENTATION.md** - Backend code & structure
- **COMPLETE_PACKAGE_MANIFEST.md** - What's included

### Development
- **02_COMPLETE_BACKEND_CODE.py** - Full backend implementation
- **03_COMPLETE_FRONTEND_CODE.tsx** - Full frontend implementation
- **04_DOCKER_KUBERNETES_DEPLOYMENT.yml** - Deployment configs

### Deployment
- **Installation Guide** - How to install locally or in cloud
- **Deployment Guide** - How to deploy to production
- **API Documentation** - Complete API reference

### Operations
- **Troubleshooting Guide** - Common issues & solutions
- **Monitoring Guide** - Setup monitoring & alerting
- **Security Guide** - Security best practices

---

## 🎯 FIRST STEPS

### 1. View Dashboard
After starting, visit `http://localhost:3000`
- See real-time statistics
- View recent research tasks
- Monitor system health

### 2. Start a Research
1. Go to "Research" tab
2. Enter company symbols (one per line)
3. Select research parameters
4. Click "Start Research"
5. Monitor progress in real-time

### 3. Explore Companies
- Browse complete company database
- View quality scores
- Search by symbol or name
- See data from multiple sources

### 4. Generate Reports
- View completed research results
- Download in multiple formats (Excel, JSON, CSV, PDF)
- Schedule automated reports
- Export to business intelligence tools

---

## ⚙️ CONFIGURATION

### Backend Configuration
```python
# backend/.env
DATABASE_URL=postgresql://user:password@host/dbname
REDIS_URL=redis://localhost:6379
JWT_SECRET_KEY=your-secret-key
LOG_LEVEL=INFO
DEBUG=false
WORKERS=4
```

### Frontend Configuration
```bash
# frontend/.env
REACT_APP_API_URL=http://localhost:8000/api/v1
REACT_APP_WS_URL=ws://localhost:8000
REACT_APP_LOG_LEVEL=info
```

---

## 🔍 MONITORING

### Prometheus Metrics
- Visit `http://localhost:9090`
- View system metrics
- Create custom dashboards
- Set up alerts

### Grafana Dashboards
- Visit `http://localhost:3001` (admin/admin)
- Pre-built dashboards
- Real-time visualization
- Performance monitoring

### ELK Stack (Elasticsearch + Kibana)
- Kibana: `http://localhost:5601`
- Centralized logging
- Log analysis
- Issue debugging

---

## 📊 API EXAMPLES

### Create Research Task
```bash
curl -X POST http://localhost:8000/api/v1/research \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "company_list": ["TADAWUL", "NMC", "SABIC"],
    "parameters": {
      "depth": "standard",
      "include_news": true
    },
    "project_id": 1
  }'
```

### Get Research Progress
```bash
curl http://localhost:8000/api/v1/research/1/progress \
  -H "Authorization: Bearer <token>"
```

### List Companies
```bash
curl http://localhost:8000/api/v1/companies \
  -H "Authorization: Bearer <token>"
```

### Download Report
```bash
curl http://localhost:8000/api/v1/reports/1/download \
  -H "Authorization: Bearer <token>" \
  -o report.xlsx
```

---

## 🧪 TESTING

### Run Tests
```bash
# Backend tests
cd backend
pytest tests/

# Frontend tests
cd frontend
npm test

# E2E tests
npm run cypress
```

### Load Testing
```bash
# Using Apache Bench
ab -n 1000 -c 10 http://localhost:8000/api/v1/health

# Using Hey
hey -n 1000 -c 10 http://localhost:8000/api/v1/health
```

---

## 📈 SCALING

### Horizontal Scaling
```bash
# Scale backend (Docker Compose)
docker-compose up -d --scale backend=3

# Scale frontend (Docker Compose)
docker-compose up -d --scale frontend=2

# Kubernetes scaling
kubectl scale deployment backend --replicas=5 -n manus
kubectl scale deployment frontend --replicas=3 -n manus
```

### Performance Optimization
- ✅ Database indexing enabled
- ✅ Redis caching configured
- ✅ Connection pooling active
- ✅ Async task processing ready
- ✅ Load balancing configured

---

## 🔒 SECURITY

### Built-in Security Features
- ✅ JWT authentication
- ✅ Role-based access control
- ✅ HTTPS/TLS support
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ CSRF protection
- ✅ Rate limiting
- ✅ Audit logging

### Pre-Deployment Checklist
- [ ] Change default credentials
- [ ] Set JWT secret key
- [ ] Enable HTTPS/TLS
- [ ] Configure firewall
- [ ] Set up backups
- [ ] Enable monitoring
- [ ] Review security settings
- [ ] Test authentication

---

## 🆘 TROUBLESHOOTING

### Port Already in Use
```bash
# Find and kill process using port
lsof -i :8000
kill -9 <PID>

# Or use different ports
docker-compose -f docker-compose.yml -e "BACKEND_PORT=8001" up
```

### Database Connection Error
```bash
# Check database status
docker exec manus-postgres psql -U manus_user -d manus_db -c "SELECT 1"

# View database logs
docker logs manus-postgres
```

### Frontend Can't Connect to Backend
```bash
# Check backend is running
curl http://localhost:8000/health

# Check CORS configuration
# Verify CORS_ORIGINS in backend/.env

# Check network connectivity
docker network ls
docker network inspect manus-network
```

---

## 📚 ADDITIONAL RESOURCES

- **API Documentation:** `/docs` or `/redoc`
- **Architecture Diagrams:** See documentation folder
- **Code Examples:** See `/examples` folder
- **Video Tutorial:** [Coming Soon]

---

## 🆘 GETTING HELP

### Common Issues

**Q: Backend won't start**
A: Check logs with `docker logs manus-backend` and verify DATABASE_URL is correct

**Q: Can't connect to database**
A: Ensure PostgreSQL is running and credentials are correct in .env

**Q: Frontend shows blank page**
A: Check browser console for errors, verify API_URL is correct

**Q: Real-time updates not working**
A: Verify WebSocket connection, check firewall rules

---

## 📞 SUPPORT

- **Documentation:** Complete guides in this package
- **Issues:** Check troubleshooting guide above
- **Questions:** Review API documentation
- **Bugs:** Check logs and error messages

---

## 🎉 YOU'RE ALL SET!

You now have a **complete, production-ready Manus 1.6 Max system** with:

✅ Full-stack implementation  
✅ Complete documentation  
✅ Ready to deploy  
✅ Ready to scale  
✅ Enterprise-grade  
✅ Fully functional  

**Next Steps:**
1. Start the system with Docker Compose
2. Log in and explore the dashboard
3. Run your first research task
4. Generate reports
5. Scale as needed

---

**Status:** ✅ Ready to Run

**Enjoy Manus 1.6 Max!** 🚀

