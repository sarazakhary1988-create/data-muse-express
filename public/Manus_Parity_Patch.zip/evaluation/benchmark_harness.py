def run_benchmark(engine, question, runs=3):
    results = []
    for _ in range(runs):
        output = engine.run(question)
        results.append({
            "confidence": output.get("confidence"),
            "sources": len(output.get("sources", []))
        })
    return results