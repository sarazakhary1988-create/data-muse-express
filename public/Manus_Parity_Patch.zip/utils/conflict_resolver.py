def resolve_conflicts(claims):
    conflicts = {}
    for c in claims:
        key = c.get("claim")
        conflicts.setdefault(key, []).append(c)
    resolved = []
    for k, v in conflicts.items():
        resolved.append({
            "claim": k,
            "dominant_view": max(v, key=lambda x: x.get("confidence", 0)),
            "all_views": v
        })
    return resolved