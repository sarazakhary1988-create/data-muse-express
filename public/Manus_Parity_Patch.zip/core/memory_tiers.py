from enum import Enum

class MemoryTier(Enum):
    WORKING = "working"
    RESEARCH = "research"
    VERIFIED = "verified"