class Orchestrator:
    def __init__(self, confidence_threshold=0.75):
        self.confidence_threshold = confidence_threshold

    def decide_next_step(self, state):
        if state.get("contradictions", 0) > 0:
            return "REVERIFY"
        if state.get("confidence", 0) < self.confidence_threshold:
            return "EXPAND_RESEARCH"
        return "SYNTHESIZE"