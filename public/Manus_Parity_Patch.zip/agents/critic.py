SYSTEM_PROMPT = """
You are a skeptical Critic Agent.
Your role is to challenge assumptions, detect hallucinations,
identify weak evidence, and assign verification status.
You must not support claims by default.
"""

class CriticAgent:
    def critique(self, claims):
        reviewed = []
        for c in claims:
            status = "Verified" if c.get("confidence", 0) > 0.8 else "Unverified"
            reviewed.append({**c, "verification_status": status})
        return reviewed