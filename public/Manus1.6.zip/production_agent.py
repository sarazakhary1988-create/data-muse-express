"""
Production-Ready Manus 1.6 Style Research Agent
Integrates all advanced features for real-world lead generation
"""

import asyncio
import os
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
import json

# Import our advanced modules
from production_search import ProductionSearchEngine, CompanyLead, LeadDatabase
from advanced_scraper import AdvancedScraper, BatchScraper, ScrapedData


@dataclass
class ResearchConfig:
    """Configuration for research"""
    api_key: str
    num_leads: int = 20
    depth: str = "wide"  # "wide" or "deep"
    use_javascript_rendering: bool = True
    enrich_leads: bool = True
    validate_emails: bool = False  # Requires external service
    min_confidence: float = 0.5
    max_concurrent_scrapes: int = 5


@dataclass
class ResearchReport:
    """Complete research report"""
    query: str
    leads: List[CompanyLead]
    insights: List[str]
    statistics: Dict[str, Any]
    sources: List[str]
    timestamp: str
    config: Dict[str, Any]
    success_rate: float


class ProductionResearchAgent:
    """
    Production-ready research agent with full Manus 1.6 capabilities
    
    Features:
    - Real web search via Anthropic
    - JavaScript-rendered page scraping
    - Multi-source data validation
    - Lead deduplication
    - Confidence scoring
    - Batch processing
    - Professional reporting
    """
    
    def __init__(self, config: ResearchConfig):
        self.config = config
        self.search_engine = ProductionSearchEngine(config.api_key)
        self.lead_db = LeadDatabase()
        
        # Statistics tracking
        self.stats = {
            'total_searches': 0,
            'total_urls_scraped': 0,
            'total_leads_found': 0,
            'total_leads_validated': 0,
            'failed_scrapes': 0,
        }
    
    async def research(self, query: str) -> ResearchReport:
        """
        Execute complete research workflow
        
        Args:
            query: Research query (natural language)
            
        Returns:
            Complete research report with all findings
        """
        print(f"\n{'='*70}")
        print(f"🔬 PRODUCTION RESEARCH AGENT")
        print(f"{'='*70}")
        print(f"Query: {query}")
        print(f"Target Leads: {self.config.num_leads}")
        print(f"Depth: {self.config.depth}")
        print(f"JavaScript Rendering: {self.config.use_javascript_rendering}")
        print(f"{'='*70}\n")
        
        start_time = datetime.now()
        
        # Phase 1: Search Strategy
        print("📋 PHASE 1: Generating Search Strategy")
        search_queries = await self._generate_search_strategy(query)
        print(f"   Generated {len(search_queries)} targeted searches\n")
        
        # Phase 2: Execute Searches
        print("🔍 PHASE 2: Executing Web Searches")
        all_urls = []
        for i, sq in enumerate(search_queries, 1):
            print(f"   [{i}/{len(search_queries)}] {sq}")
            results = self.search_engine.search(sq, num_results=15)
            all_urls.extend([r.url for r in results])
            self.stats['total_searches'] += 1
        
        # Deduplicate URLs
        unique_urls = list(set(all_urls))
        print(f"   Found {len(unique_urls)} unique URLs\n")
        
        # Phase 3: Deep Scraping
        print("🌐 PHASE 3: Scraping Website Content")
        scraped_data = await self._scrape_urls(unique_urls[:50])  # Limit to 50
        print(f"   Successfully scraped {len(scraped_data)} sites\n")
        
        # Phase 4: Extract Leads
        print("💼 PHASE 4: Extracting Structured Leads")
        leads = await self._extract_leads_from_scraped_data(
            scraped_data, 
            query
        )
        print(f"   Extracted {len(leads)} initial leads\n")
        
        # Phase 5: Validate & Enrich
        print("✨ PHASE 5: Validating and Enriching Leads")
        validated_leads = self._validate_and_enrich_leads(leads)
        print(f"   Validated {len(validated_leads)} high-quality leads\n")
        
        # Phase 6: Generate Insights
        print("💡 PHASE 6: Generating Strategic Insights")
        insights = await self._generate_insights(validated_leads, query)
        print(f"   Generated {len(insights)} insights\n")
        
        # Compile report
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        report = ResearchReport(
            query=query,
            leads=validated_leads[:self.config.num_leads],
            insights=insights,
            statistics=self._compile_statistics(validated_leads, duration),
            sources=unique_urls[:50],
            timestamp=datetime.now().isoformat(),
            config=asdict(self.config),
            success_rate=len(validated_leads) / max(len(leads), 1)
        )
        
        print(f"{'='*70}")
        print(f"✅ RESEARCH COMPLETE")
        print(f"{'='*70}")
        print(f"Duration: {duration:.1f}s")
        print(f"Leads Found: {len(report.leads)}")
        print(f"Success Rate: {report.success_rate:.1%}")
        print(f"{'='*70}\n")
        
        return report
    
    async def _generate_search_strategy(self, query: str) -> List[str]:
        """Generate multiple targeted search queries"""
        
        # Use Claude to generate smart search queries
        import anthropic
        client = anthropic.Anthropic(api_key=self.config.api_key)
        
        prompt = f"""You are a B2B lead research expert. Generate 6-8 highly specific search queries to find companies matching this description:

"{query}"

Requirements:
1. Include queries targeting company directories, lists, and databases
2. Include industry-specific queries
3. Include location-based queries if relevant
4. Include technology/platform-specific queries if relevant
5. Focus on finding actual company websites, not news articles

Return ONLY a JSON array of query strings:
["query 1", "query 2", ...]

Example queries might include:
- "[industry] companies directory"
- "top [type] companies in [location]"
- "companies using [technology]"
- "[industry] vendors list"
"""

        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Extract JSON
        import re
        response_text = message.content[0].text
        json_match = re.search(r'\[.*?\]', response_text, re.DOTALL)
        
        if json_match:
            try:
                queries = json.loads(json_match.group())
                return queries[:8]
            except:
                pass
        
        # Fallback
        return [
            f"{query} companies",
            f"{query} directory",
            f"top {query} businesses",
            f"{query} vendors list"
        ]
    
    async def _scrape_urls(self, urls: List[str]) -> List[ScrapedData]:
        """Scrape URLs using advanced scraper"""
        
        if self.config.use_javascript_rendering:
            # Use Playwright for JavaScript rendering
            batch_scraper = BatchScraper(
                max_concurrent=self.config.max_concurrent_scrapes
            )
            
            def progress(current, total):
                print(f"   Scraping: {current}/{total}", end='\r')
            
            results = await batch_scraper.scrape_urls(urls, progress)
            self.stats['total_urls_scraped'] += len(urls)
            self.stats['failed_scrapes'] += len([r for r in results if not r.success])
            
            return [r for r in results if r.success]
        
        else:
            # Use simpler aiohttp scraping
            return []
    
    async def _extract_leads_from_scraped_data(
        self, 
        scraped_data: List[ScrapedData],
        query: str
    ) -> List[CompanyLead]:
        """Extract structured leads from scraped data"""
        
        leads = []
        
        for data in scraped_data:
            # Create lead from scraped data
            lead = CompanyLead(
                company_name=data.company_info.get('possible_company_name', 
                                                   self._extract_company_from_url(data.url)),
                website=data.url,
                industry=None,  # Will be inferred later
                description=data.company_info.get('about', '')[:500],
                location=data.company_info.get('address'),
                employee_count=data.company_info.get('employee_count'),
                emails=data.emails[:5],
                phones=data.phones[:3],
                linkedin=data.social_links.get('linkedin'),
                twitter=data.social_links.get('twitter'),
                technologies=data.technologies,
                confidence_score=self._calculate_confidence(data),
                data_sources=[data.url]
            )
            
            # Add to database (handles deduplication)
            self.lead_db.add_lead(lead)
            leads.append(lead)
            self.stats['total_leads_found'] += 1
        
        return leads
    
    def _validate_and_enrich_leads(self, leads: List[CompanyLead]) -> List[CompanyLead]:
        """Validate and optionally enrich leads"""
        
        validated = []
        
        for lead in leads:
            # Validate
            if not self.search_engine.validate_lead(lead):
                continue
            
            # Check confidence threshold
            if lead.confidence_score < self.config.min_confidence:
                continue
            
            # Enrich if configured
            if self.config.enrich_leads:
                lead = self.search_engine.enrich_lead(lead)
            
            validated.append(lead)
            self.stats['total_leads_validated'] += 1
        
        # Sort by confidence
        validated.sort(key=lambda x: x.confidence_score, reverse=True)
        
        return validated
    
    async def _generate_insights(self, leads: List[CompanyLead], query: str) -> List[str]:
        """Generate strategic insights from leads"""
        
        # Analyze leads
        industries = {}
        locations = {}
        technologies = {}
        
        for lead in leads:
            # Count industries
            if lead.industry:
                industries[lead.industry] = industries.get(lead.industry, 0) + 1
            
            # Count locations
            if lead.location:
                loc = lead.location.split(',')[0].strip()  # Get city
                locations[loc] = locations.get(loc, 0) + 1
            
            # Count technologies
            for tech in lead.technologies:
                technologies[tech] = technologies.get(tech, 0) + 1
        
        # Generate insights
        insights = []
        
        # Total leads
        insights.append(f"Identified {len(leads)} qualified companies matching search criteria")
        
        # Top industries
        if industries:
            top_industries = sorted(industries.items(), key=lambda x: x[1], reverse=True)[:3]
            industry_str = ", ".join([f"{ind} ({cnt})" for ind, cnt in top_industries])
            insights.append(f"Primary industries: {industry_str}")
        
        # Geographic distribution
        if locations:
            top_locations = sorted(locations.items(), key=lambda x: x[1], reverse=True)[:3]
            location_str = ", ".join([f"{loc} ({cnt})" for loc, cnt in top_locations])
            insights.append(f"Geographic concentration: {location_str}")
        
        # Technology adoption
        if technologies:
            top_tech = sorted(technologies.items(), key=lambda x: x[1], reverse=True)[:5]
            tech_str = ", ".join([f"{tech} ({cnt})" for tech, cnt in top_tech])
            insights.append(f"Common technologies: {tech_str}")
        
        # Contact availability
        with_email = len([l for l in leads if l.emails])
        email_pct = with_email / len(leads) * 100 if leads else 0
        insights.append(f"Contact information available for {email_pct:.0f}% of leads")
        
        # LinkedIn presence
        with_linkedin = len([l for l in leads if l.linkedin])
        linkedin_pct = with_linkedin / len(leads) * 100 if leads else 0
        insights.append(f"{linkedin_pct:.0f}% have identified LinkedIn profiles")
        
        return insights
    
    def _compile_statistics(self, leads: List[CompanyLead], duration: float) -> Dict[str, Any]:
        """Compile research statistics"""
        
        return {
            'total_leads': len(leads),
            'with_email': len([l for l in leads if l.emails]),
            'with_phone': len([l for l in leads if l.phones]),
            'with_linkedin': len([l for l in leads if l.linkedin]),
            'with_location': len([l for l in leads if l.location]),
            'avg_confidence': sum(l.confidence_score for l in leads) / len(leads) if leads else 0,
            'duration_seconds': duration,
            'searches_executed': self.stats['total_searches'],
            'urls_scraped': self.stats['total_urls_scraped'],
            'scrape_failures': self.stats['failed_scrapes'],
        }
    
    def _extract_company_from_url(self, url: str) -> str:
        """Extract company name from URL"""
        from urllib.parse import urlparse
        
        domain = urlparse(url).netloc
        domain = domain.replace('www.', '')
        name = domain.split('.')[0]
        
        return name.replace('-', ' ').replace('_', ' ').title()
    
    def _calculate_confidence(self, data: ScrapedData) -> float:
        """Calculate confidence score for scraped data"""
        score = 0.0
        
        # Has company info
        if data.company_info:
            score += 0.3
        
        # Has emails
        if data.emails:
            score += 0.2
        
        # Has phones
        if data.phones:
            score += 0.1
        
        # Has social links
        if data.social_links:
            score += 0.1
        
        # Has technologies
        if data.technologies:
            score += 0.1
        
        # Has structured data
        if data.structured_data:
            score += 0.2
        
        return min(score, 1.0)


# Example usage
async def main():
    """Example production usage"""
    
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: Set ANTHROPIC_API_KEY environment variable")
        return
    
    # Configure research
    config = ResearchConfig(
        api_key=api_key,
        num_leads=15,
        depth="wide",
        use_javascript_rendering=True,
        enrich_leads=True,
        min_confidence=0.5
    )
    
    # Create agent
    agent = ProductionResearchAgent(config)
    
    # Execute research
    report = await agent.research(
        query="B2B SaaS companies in healthcare with 50-200 employees"
    )
    
    # Display results
    print("\n" + "="*70)
    print("RESEARCH RESULTS")
    print("="*70 + "\n")
    
    print(f"Query: {report.query}")
    print(f"Total Leads: {len(report.leads)}")
    print(f"Success Rate: {report.success_rate:.1%}\n")
    
    print("TOP LEADS:")
    for i, lead in enumerate(report.leads[:10], 1):
        print(f"\n{i}. {lead.company_name}")
        print(f"   Website: {lead.website}")
        print(f"   Industry: {lead.industry or 'N/A'}")
        print(f"   Location: {lead.location or 'N/A'}")
        print(f"   Employees: {lead.employee_count or 'N/A'}")
        if lead.emails:
            print(f"   Emails: {', '.join(lead.emails[:2])}")
        if lead.technologies:
            print(f"   Tech: {', '.join(lead.technologies[:3])}")
        print(f"   Confidence: {lead.confidence_score:.0%}")
    
    print(f"\n{'='*70}")
    print("KEY INSIGHTS:")
    print("="*70 + "\n")
    for i, insight in enumerate(report.insights, 1):
        print(f"{i}. {insight}")
    
    print(f"\n{'='*70}")
    print("STATISTICS:")
    print("="*70 + "\n")
    for key, value in report.statistics.items():
        print(f"{key.replace('_', ' ').title()}: {value}")
    
    # Save report
    output_file = f"/mnt/user-data/outputs/research_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w') as f:
        json.dump({
            'query': report.query,
            'leads': [asdict(lead) for lead in report.leads],
            'insights': report.insights,
            'statistics': report.statistics,
            'timestamp': report.timestamp
        }, f, indent=2)
    
    print(f"\n✅ Report saved to: {output_file}")


if __name__ == "__main__":
    asyncio.run(main())
