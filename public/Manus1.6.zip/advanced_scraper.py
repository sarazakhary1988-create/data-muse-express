"""
Advanced Web Scraper with JavaScript Rendering
Handles modern SPAs, dynamic content, and anti-bot measures
"""

import asyncio
import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse
import aiohttp
from bs4 import BeautifulSoup
import json

try:
    from playwright.async_api import async_playwright, Browser, Page
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    print("Warning: Playwright not available. Install with: pip install playwright && playwright install")


@dataclass
class ScrapedData:
    """Structured scraped data"""
    url: str
    title: str
    text_content: str
    emails: List[str]
    phones: List[str]
    social_links: Dict[str, str]
    company_info: Dict[str, Any]
    technologies: List[str]
    metadata: Dict[str, str]
    links: List[str]
    images: List[str]
    structured_data: Dict[str, Any]
    success: bool
    error: Optional[str] = None


class AdvancedScraper:
    """
    Production-grade web scraper with:
    - JavaScript rendering (Playwright)
    - Smart content extraction
    - Email/phone pattern matching
    - Technology detection
    - Social profile extraction
    - Structured data parsing
    """
    
    def __init__(self, headless: bool = True, timeout: int = 30000):
        self.headless = headless
        self.timeout = timeout
        self.browser: Optional[Browser] = None
        
        # Regex patterns
        self.email_pattern = re.compile(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        )
        self.phone_pattern = re.compile(
            r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
        )
        
        # Technology signatures
        self.tech_signatures = {
            'React': ['react', '_react', 'reactjs'],
            'Vue.js': ['vue', '__vue__'],
            'Angular': ['ng-', 'angular'],
            'WordPress': ['wp-content', 'wordpress'],
            'Shopify': ['shopify', 'cdn.shopify.com'],
            'Salesforce': ['salesforce', 'force.com'],
            'HubSpot': ['hubspot', 'hs-scripts'],
            'Google Analytics': ['google-analytics', 'gtag'],
            'Stripe': ['stripe', 'js.stripe.com'],
            'Intercom': ['intercom'],
            'Segment': ['segment.com/analytics'],
            'Hotjar': ['hotjar'],
            'Zendesk': ['zendesk'],
            'Cloudflare': ['cloudflare'],
            'AWS': ['amazonaws.com'],
            'Vercel': ['vercel'],
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()
    
    async def start(self):
        """Initialize browser"""
        if not PLAYWRIGHT_AVAILABLE:
            return
        
        playwright = await async_playwright().start()
        self.browser = await playwright.chromium.launch(
            headless=self.headless,
            args=['--no-sandbox', '--disable-dev-shm-usage']
        )
    
    async def close(self):
        """Close browser"""
        if self.browser:
            await self.browser.close()
    
    async def scrape_url(self, url: str, wait_for_selector: str = None) -> ScrapedData:
        """
        Scrape a URL with JavaScript rendering
        
        Args:
            url: URL to scrape
            wait_for_selector: Optional CSS selector to wait for before scraping
        """
        try:
            if PLAYWRIGHT_AVAILABLE and self.browser:
                return await self._scrape_with_playwright(url, wait_for_selector)
            else:
                return await self._scrape_with_aiohttp(url)
        except Exception as e:
            return ScrapedData(
                url=url,
                title="",
                text_content="",
                emails=[],
                phones=[],
                social_links={},
                company_info={},
                technologies=[],
                metadata={},
                links=[],
                images=[],
                structured_data={},
                success=False,
                error=str(e)
            )
    
    async def _scrape_with_playwright(self, url: str, wait_for_selector: str = None) -> ScrapedData:
        """Scrape using Playwright (handles JavaScript)"""
        page = await self.browser.new_page()
        
        try:
            # Navigate to page
            await page.goto(url, timeout=self.timeout, wait_until='networkidle')
            
            # Wait for specific selector if provided
            if wait_for_selector:
                await page.wait_for_selector(wait_for_selector, timeout=10000)
            
            # Get page content
            html = await page.content()
            
            # Extract additional data
            title = await page.title()
            
            # Parse with BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            
            # Extract all data
            data = self._extract_all_data(soup, html, url)
            data.title = title
            data.success = True
            
            return data
            
        finally:
            await page.close()
    
    async def _scrape_with_aiohttp(self, url: str) -> ScrapedData:
        """Scrape using aiohttp (static HTML only)"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=30) as response:
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                data = self._extract_all_data(soup, html, url)
                data.title = soup.title.string if soup.title else ""
                data.success = True
                
                return data
    
    def _extract_all_data(self, soup: BeautifulSoup, html: str, url: str) -> ScrapedData:
        """Extract all possible data from page"""
        
        return ScrapedData(
            url=url,
            title="",  # Will be set by caller
            text_content=self._extract_text(soup),
            emails=self._extract_emails(html),
            phones=self._extract_phones(html),
            social_links=self._extract_social_links(soup),
            company_info=self._extract_company_info(soup, html),
            technologies=self._detect_technologies(html),
            metadata=self._extract_metadata(soup),
            links=self._extract_links(soup, url),
            images=self._extract_images(soup, url),
            structured_data=self._extract_structured_data(soup),
            success=True
        )
    
    def _extract_text(self, soup: BeautifulSoup) -> str:
        """Extract clean text content"""
        # Remove unwanted elements
        for element in soup(['script', 'style', 'nav', 'footer', 'header', 'aside']):
            element.decompose()
        
        # Get text
        text = soup.get_text(separator=' ', strip=True)
        
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text)
        
        return text[:10000]  # Limit to 10k chars
    
    def _extract_emails(self, html: str) -> List[str]:
        """Extract and validate email addresses"""
        emails = self.email_pattern.findall(html)
        
        # Filter out common false positives
        filtered = []
        blacklist = ['example.com', 'test.com', 'domain.com', 'yoursite.com', 
                     'placeholder', 'email.com', 'mail.com']
        
        for email in set(emails):
            email_lower = email.lower()
            if not any(bl in email_lower for bl in blacklist):
                # Basic validation
                if '@' in email and '.' in email.split('@')[1]:
                    filtered.append(email)
        
        return filtered[:20]  # Limit to 20 emails
    
    def _extract_phones(self, html: str) -> List[str]:
        """Extract phone numbers"""
        phones = self.phone_pattern.findall(html)
        
        # Clean and deduplicate
        cleaned = []
        for phone in phones:
            # Remove extra spaces, dashes
            phone_clean = re.sub(r'[^\d+()]', '', phone)
            if len(phone_clean) >= 10:  # Minimum valid phone length
                cleaned.append(phone)
        
        return list(set(cleaned))[:10]  # Limit to 10
    
    def _extract_social_links(self, soup: BeautifulSoup) -> Dict[str, str]:
        """Extract social media profile links"""
        social_patterns = {
            'linkedin': r'linkedin\.com/(company|in)/([^/"\s]+)',
            'twitter': r'twitter\.com/([^/"\s]+)',
            'facebook': r'facebook\.com/([^/"\s]+)',
            'instagram': r'instagram\.com/([^/"\s]+)',
            'youtube': r'youtube\.com/(c|channel|user)/([^/"\s]+)',
            'github': r'github\.com/([^/"\s]+)',
        }
        
        social_links = {}
        
        # Get all links
        for link in soup.find_all('a', href=True):
            href = link['href']
            
            for platform, pattern in social_patterns.items():
                match = re.search(pattern, href, re.IGNORECASE)
                if match and platform not in social_links:
                    social_links[platform] = href
        
        return social_links
    
    def _extract_company_info(self, soup: BeautifulSoup, html: str) -> Dict[str, Any]:
        """Extract company information"""
        info = {}
        
        # Look for common patterns
        # Company name from title or h1
        h1 = soup.find('h1')
        if h1:
            info['possible_company_name'] = h1.get_text(strip=True)
        
        # Look for "About" section
        about_section = soup.find(['section', 'div'], 
                                  class_=re.compile(r'about', re.I))
        if about_section:
            info['about'] = about_section.get_text(strip=True)[:500]
        
        # Look for address
        address = soup.find(['address', 'div'], 
                           class_=re.compile(r'address|location', re.I))
        if address:
            info['address'] = address.get_text(strip=True)
        
        # Look for employee count
        employee_patterns = [
            r'(\d+[\+]?)\s+employees?',
            r'team\s+of\s+(\d+)',
            r'(\d+[\+]?)\s+people'
        ]
        for pattern in employee_patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                info['employee_count'] = match.group(1)
                break
        
        return info
    
    def _detect_technologies(self, html: str) -> List[str]:
        """Detect technologies used on the website"""
        detected = []
        
        html_lower = html.lower()
        
        for tech, signatures in self.tech_signatures.items():
            for signature in signatures:
                if signature.lower() in html_lower:
                    detected.append(tech)
                    break
        
        return detected
    
    def _extract_metadata(self, soup: BeautifulSoup) -> Dict[str, str]:
        """Extract meta tags"""
        metadata = {}
        
        # Standard meta tags
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property', '')
            content = meta.get('content', '')
            
            if name and content:
                # Clean the name
                name_clean = name.replace('og:', '').replace('twitter:', '')
                metadata[name_clean] = content
        
        return metadata
    
    def _extract_links(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Extract all links from page"""
        links = []
        
        for link in soup.find_all('a', href=True):
            href = link['href']
            
            # Convert to absolute URL
            absolute_url = urljoin(base_url, href)
            
            # Filter out anchors and javascript
            if not absolute_url.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                links.append(absolute_url)
        
        # Deduplicate and limit
        return list(set(links))[:100]
    
    def _extract_images(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Extract image URLs"""
        images = []
        
        for img in soup.find_all('img', src=True):
            src = img['src']
            absolute_url = urljoin(base_url, src)
            images.append(absolute_url)
        
        return list(set(images))[:50]
    
    def _extract_structured_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """Extract JSON-LD and other structured data"""
        structured = {}
        
        # JSON-LD
        for script in soup.find_all('script', type='application/ld+json'):
            try:
                data = json.loads(script.string)
                
                # Extract useful fields
                if isinstance(data, dict):
                    if '@type' in data:
                        structured['type'] = data['@type']
                    if 'name' in data:
                        structured['name'] = data['name']
                    if 'description' in data:
                        structured['description'] = data['description']
                    if 'address' in data:
                        structured['address'] = data['address']
                    if 'telephone' in data:
                        structured['telephone'] = data['telephone']
                    if 'email' in data:
                        structured['email'] = data['email']
            except:
                continue
        
        return structured


class BatchScraper:
    """Batch scraping with concurrency control"""
    
    def __init__(self, max_concurrent: int = 5):
        self.max_concurrent = max_concurrent
        self.scraper = AdvancedScraper()
    
    async def scrape_urls(self, urls: List[str], 
                         progress_callback=None) -> List[ScrapedData]:
        """
        Scrape multiple URLs concurrently
        
        Args:
            urls: List of URLs to scrape
            progress_callback: Optional callback function(current, total)
        """
        await self.scraper.start()
        
        try:
            results = []
            semaphore = asyncio.Semaphore(self.max_concurrent)
            
            async def scrape_with_semaphore(url: str, index: int):
                async with semaphore:
                    if progress_callback:
                        progress_callback(index + 1, len(urls))
                    return await self.scraper.scrape_url(url)
            
            tasks = [
                scrape_with_semaphore(url, i) 
                for i, url in enumerate(urls)
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Filter out exceptions
            valid_results = [
                r for r in results 
                if isinstance(r, ScrapedData)
            ]
            
            return valid_results
            
        finally:
            await self.scraper.close()


# Example usage
async def example_usage():
    """Example of how to use the advanced scraper"""
    
    # Single URL scraping
    async with AdvancedScraper() as scraper:
        result = await scraper.scrape_url("https://example.com")
        
        print(f"Title: {result.title}")
        print(f"Emails: {result.emails}")
        print(f"Phones: {result.phones}")
        print(f"Technologies: {result.technologies}")
        print(f"Social Links: {result.social_links}")
    
    # Batch scraping
    urls = [
        "https://example.com",
        "https://another-site.com",
    ]
    
    batch_scraper = BatchScraper(max_concurrent=3)
    
    def progress(current, total):
        print(f"Progress: {current}/{total}")
    
    results = await batch_scraper.scrape_urls(urls, progress_callback=progress)
    
    for result in results:
        if result.success:
            print(f"\n{result.url}")
            print(f"  Emails: {len(result.emails)}")
            print(f"  Technologies: {result.technologies}")


if __name__ == "__main__":
    asyncio.run(example_usage())
